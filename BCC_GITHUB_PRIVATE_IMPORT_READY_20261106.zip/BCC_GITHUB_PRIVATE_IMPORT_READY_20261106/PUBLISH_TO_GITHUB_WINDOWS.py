"""One-time explicit transfer of a sealed, sanitized BCC source tree to the private development repo.

This script never runs as part of the application, CI or an AI cycle.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
REPO = 'https://github.com/antonyugay020-alt/Bot-Control-Center-Pro.git'
REPO_NAME = 'antonyugay020-alt/Bot-Control-Center-Pro'


def run(*args, cwd=None, capture=False):
    result = subprocess.run(args, cwd=cwd, text=True, encoding='utf-8', errors='replace',
                            stdout=subprocess.PIPE if capture else None,
                            stderr=subprocess.PIPE if capture else None,
                            check=False)
    if result.returncode:
        print('ERROR:', ' '.join(args), file=sys.stderr)
        if capture:
            print(result.stdout, result.stderr, file=sys.stderr)
        raise RuntimeError('Command failed (exit %s)' % result.returncode)
    return result.stdout if capture else ''


def main():
    from tools.verify_package import verify
    verified = verify(ROOT)
    print('SOURCE INTEGRITY PASS:', verified['verified_files'], 'files')
    entries = json.loads((ROOT / 'SHA256_MANIFEST.json').read_text(encoding='utf-8'))['files']
    # A new repository may contain a bootstrap README.md, but all imported source
    # paths MUST be taken exclusively from the verified package manifest.
    if len(entries) < 100:
        raise RuntimeError('Manifest incomplete')
    if shutil.which('git') is None:
        raise RuntimeError('Git for Windows is not installed')
    if not shutil.which('gh'):
        print('NOTE: gh CLI not installed; relying on Git Credential Manager for private repo authentication')
    else:
        visibility = run('gh', 'repo', 'view', REPO_NAME, '--json', 'visibility', '--jq', '.visibility', capture=True).strip()
        if visibility.upper() != 'PRIVATE':
            raise RuntimeError('Refusing to upload: repository visibility is not PRIVATE')
    with tempfile.TemporaryDirectory(prefix='bcc_private_git_upload_') as tmp:
        checkout = Path(tmp) / 'checkout'
        run('git', '-c', 'core.autocrlf=false', 'clone', '--depth', '1', REPO, str(checkout))
        run('git', 'config', 'core.autocrlf', 'false', cwd=checkout)
        for raw, expected in sorted(entries.items()):
            rel = PurePosixPath(raw)
            if rel.is_absolute() or '..' in rel.parts or '\\' in raw or raw.startswith('.ai_work/'):
                raise RuntimeError('Unsafe manifest path: '+raw)
            p = ROOT.joinpath(*rel.parts)
            if p.is_symlink() or not p.is_file():
                raise RuntimeError('Missing or symlink source: '+raw)
            data = p.read_bytes()
            if hashlib.sha256(data).hexdigest() != expected:
                raise RuntimeError('Source changed: '+raw)
            destination = checkout.joinpath(*rel.parts)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
        (checkout / 'SHA256_MANIFEST.json').write_bytes((ROOT / 'SHA256_MANIFEST.json').read_bytes())
        run('git', 'add', '-A', cwd=checkout)
        staged = run('git', 'diff', '--cached', '--name-only', '-z', cwd=checkout, capture=True).split('\x00')
        allow = set(entries) | {'SHA256_MANIFEST.json'}
        unexpected = sorted(x for x in staged if x and x not in allow)
        if unexpected:
            raise RuntimeError('Unexpected files staged: '+', '.join(unexpected))
        if not any(staged):
            print('Already up to date. Nothing to publish.')
            return 0
        run('git', '-c', 'user.name=BCC Import', '-c', 'user.email=bcc-import@users.noreply.github.com',
            'commit', '-m', 'Import sealed BCC source snapshot for cloud development (NOT RELEASE)', cwd=checkout)
        run('git', 'push', 'origin', 'HEAD:main', cwd=checkout)
        sha = run('git', 'rev-parse', 'HEAD', cwd=checkout, capture=True).strip()
        print('UPLOAD COMPLETE:', sha)
        print('CI: https://github.com/antonyugay020-alt/Bot-Control-Center-Pro/actions')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as exc:
        print('UPLOAD BLOCKED:', exc, file=sys.stderr)
        sys.exit(1)
