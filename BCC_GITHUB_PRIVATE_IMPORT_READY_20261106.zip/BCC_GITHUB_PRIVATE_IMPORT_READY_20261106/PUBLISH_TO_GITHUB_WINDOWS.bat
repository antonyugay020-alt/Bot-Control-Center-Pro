@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
where python >nul 2>&1
if errorlevel 1 (
  echo Python not found. Install Python and retry.
  pause
  exit /b 1
)
python PUBLISH_TO_GITHUB_WINDOWS.py
set "code=%errorlevel%"
if not "%code%"=="0" echo GitHub upload did not complete. No success claimed.
pause
exit /b %code%
