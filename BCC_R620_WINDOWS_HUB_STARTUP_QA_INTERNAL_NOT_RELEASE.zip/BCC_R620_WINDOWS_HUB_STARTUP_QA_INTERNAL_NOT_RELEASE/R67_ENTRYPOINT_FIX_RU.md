# R6.7 — исправление Windows-проверки, не релиз

Отчёт Windows 2026-10-31 22:01 показал `ModuleNotFoundError: No module named tools` в `tools/windows_check.py`.

Причина: Python при прямом запуске файла добавляет в sys.path каталог `tools`, а не корень пакета.

Исправление: корень извлекается из `__file__` и добавляется в import path до обращения к `tools.verify_package`.

Реальная проверка из чистой копии запускает `python -I <absolute path>/tools/windows_check.py --preflight-only` из чужего cwd. Должна завершаться статусом `SOURCE_INTEGRITY_PASS_ONLY`.

`--preflight-only` проверяет исключительно целостность файлов и импорт из реального entrypoint, а не Windows Qt, PAPER-торги или релиз.

Релиз запрещён до успешных нативных Windows Qt E2E и подтверждённых PAPER-циклов на актуальных публичных данных.
