"""Start and reuse one market-data producer per repository; fail closed.

A short OS file lock protects check-and-spawn across shell instances. The hub
is deliberately independent of the GUI lifetime and is recovered at next start.
"""
import errno
import json
import math
import os
import sqlite3
import subprocess
from subprocess import Popen as _spawn_hub
import sys
import time
from pathlib import Path

import psutil

from .storage import atomic_json


class HubUnavailable(RuntimeError):
    pass


def _locked(path, *, timeout=8.0):
    """Bounded cross-platform spawn lock; always close the file on failure.

    Waiting for a crashed or stalled sibling's filesystem lock must never
    freeze the dashboard indefinitely. Both Windows and POSIX use a
    nonblocking attempt and a monotonic deadline.
    """
    if type(timeout) not in (int, float) or not math.isfinite(timeout) or timeout <= 0:
        raise ValueError("Market Data Hub lock timeout must be positive and finite")

    class Lock:
        def __enter__(self):
            self.f = open(path, "a+b")
            try:
                if self.f.seek(0, 2) == 0:
                    self.f.write(b"0")
                    self.f.flush()
                deadline = time.monotonic() + timeout
                while True:
                    self.f.seek(0)
                    try:
                        if os.name == "nt":
                            import msvcrt
                            msvcrt.locking(self.f.fileno(), msvcrt.LK_NBLCK, 1)
                        else:
                            import fcntl
                            fcntl.flock(self.f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                        return self
                    except OSError as exc:
                        if exc.errno not in (errno.EACCES, errno.EAGAIN):
                            raise
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            raise HubUnavailable("Market Data Hub spawn lock timed out") from exc
                        time.sleep(min(0.05, remaining))
            except BaseException:
                self.f.close()
                raise

        def __exit__(self, *_):
            try:
                if os.name == "nt":
                    import msvcrt
                    self.f.seek(0)
                    msvcrt.locking(self.f.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(self.f.fileno(), fcntl.LOCK_UN)
            finally:
                self.f.close()
    return Lock()


def _matches(record, cache):
    try:
        p = psutil.Process(record['pid'])
        cmd = p.cmdline()
        return (p.is_running() and p.status() != psutil.STATUS_ZOMBIE
                and abs(p.create_time() - record['created']) < .05
                and '--cache' in cmd
                and Path(cmd[cmd.index('--cache') + 1]).resolve() == cache
                and 'tools.market_hub_service' in cmd)
    except (OSError, ValueError, KeyError, IndexError, TypeError, psutil.Error):
        return False


def _hub_startup_details(root, proc):
    """Bounded diagnostic from *this* spawned public-data producer only."""
    path = root / 'market_hub.log'
    try:
        # Never attach a whole log or unrelated user files to a failure.
        with path.open('rb') as stream:
            stream.seek(0, os.SEEK_END)
            stream.seek(max(0, stream.tell() - 3072))
            tail = stream.read().decode('utf-8', errors='replace')
    except OSError:
        tail = '<hub log unavailable>'
    return 'pid={} exit={} last_log={}'.format(proc.pid, proc.poll(), repr(tail[-2000:]))


def ensure_hub(repo_root, *, timeout=8):
    root = Path(repo_root).resolve()
    cache = root / 'market_cache.sqlite'
    lock = root / '.market_hub_spawn.lock'
    record_path = root / 'market_hub_process.json'
    from .market_hub import HubRegistry
    with _locked(lock, timeout=timeout):
        try:
            record = json.loads(record_path.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            record = {}
        # A syntactically valid JSON document is not necessarily a process
        # record. Treat broken metadata as untrusted and recover from the
        # actual leader lease, rather than crashing on record.get().
        if not isinstance(record, dict):
            record = {}
        if _matches(record, cache):
            # A matching PID only proves process identity, not that the
            # producer still owns a fresh leader lease or serves data. Never
            # silently hand a worker a dead/hung hub endpoint.
            try:
                registry = HubRegistry(cache)
                with registry._connect() as db:
                    leader = db.execute(
                        'SELECT owner, expires FROM hub_leader WHERE singleton=1'
                    ).fetchone()
                if (leader and type(leader[0]) is str and
                        leader[0].split(':', 1)[0] == str(record['pid']) and
                        type(leader[1]) in (int, float) and
                        math.isfinite(leader[1]) and leader[1] > time.time()):
                    return record['pid']
            except (OSError, ValueError) as exc:
                raise HubUnavailable('Market Data Hub leadership check failed') from exc
            raise HubUnavailable(
                'Market Data Hub process exists but has no valid leadership lease'
            )
        # A crashed producer may leave a 120-second database lease. Revoke it
        # only if its recorded PID and creation time no longer identify a live
        # producer. Never revoke a live but slow Hub's lease.
        if record.get('pid') and not _matches(record, cache):
            try:
                old = psutil.Process(record['pid'])
                dead = old.status() == psutil.STATUS_ZOMBIE or abs(old.create_time() - record['created']) >= .05
            except (psutil.NoSuchProcess, psutil.ZombieProcess):
                dead = True
            except (psutil.AccessDenied, KeyError, TypeError, ValueError):
                dead = False
            if dead:
                registry = HubRegistry(cache)
                with registry._connect() as db:
                    db.execute('DELETE FROM hub_leader WHERE owner LIKE ?', (str(record['pid']) + ':%',))
        # If the PID file was lost/corrupted while an old producer still
        # holds leadership, do not overwrite its identity with a speculative
        # second Hub. A live database lease is not enough to authorize using
        # that process: its creation time and command must also be proven.
        # A dead verified predecessor's lease was revoked above.
        registry = HubRegistry(cache)
        with registry._connect() as db:
            leader = db.execute(
                'SELECT owner, expires FROM hub_leader WHERE singleton=1'
            ).fetchone()
        if (leader and isinstance(leader[0], str)
                and type(leader[1]) in (int, float)
                and math.isfinite(leader[1]) and leader[1] > time.time()):
            raise HubUnavailable(
                'Market Data Hub has an active leader but its process identity '
                'cannot be verified; refusing to replace it'
            )
        app_root = Path(__file__).resolve().parent.parent
        env = os.environ.copy()
        env['PYTHONPATH'] = str(app_root)
        # The hub is the *producer*. Never inherit a worker's opt-in
        # client mode or another cache path via a parent GUI/test shell.
        env.pop('BCC_MARKET_HUB_MODE', None)
        env.pop('BCC_PUBLIC_CACHE', None)
        flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
        with (root / 'market_hub.log').open('ab') as log:
            proc = _spawn_hub([sys.executable, '-m', 'tools.market_hub_service',
                                     '--cache', str(cache)], cwd=app_root, env=env,
                                    stdout=log, stderr=subprocess.STDOUT,
                                    creationflags=flags,
                                    start_new_session=os.name != 'nt')
        try:
            created = psutil.Process(proc.pid).create_time()
            atomic_json(record_path, {'pid': proc.pid, 'created': created})
            # Windows cold startup (antivirus, .venv, SQLite WAL creation)
            # may take longer than the spawn-lock acquisition budget. Keep
            # both waits bounded, but do not confuse them into one deadline.
            startup_budget = max(timeout, 18) if os.name == 'nt' else timeout
            deadline = time.monotonic() + startup_budget
            # Reuse the registry opened before spawn: repeatedly creating it
            # while the child opens the same WAL database was an unnecessary
            # cross-process schema contention point on Windows.
            while time.monotonic() < deadline:
                if proc.poll() is not None:
                    raise HubUnavailable('Market Data Hub stopped during startup: ' + _hub_startup_details(root, proc))
                # Service initializes its database and acquires leadership.
                try:
                    with registry._connect() as db:
                        leader = db.execute('SELECT owner,expires FROM hub_leader WHERE singleton=1').fetchone()
                    if (leader and isinstance(leader[0], str)
                            and type(leader[1]) in (int, float)
                            and math.isfinite(leader[1])
                            and leader[1] > time.time()
                            and str(proc.pid) == leader[0].split(':', 1)[0]):
                        return proc.pid
                except (OSError, ValueError, sqlite3.Error) as exc:
                    last_error = str(exc)
                time.sleep(.1)
            raise HubUnavailable('Market Data Hub did not become ready: ' +
                                 _hub_startup_details(root, proc) +
                                 (f' last_probe={last_error}' if 'last_error' in locals() else ''))
        except BaseException:
            if proc.poll() is None:
                try:
                    proc.terminate()
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=3)
                except ProcessLookupError:
                    pass
            record_path.unlink(missing_ok=True)
            raise
