"""Read-only public market transport. Only GET endpoints are available."""

import json
import logging
import math
import os
import re
import threading
import time
from datetime import datetime, timezone
from urllib.parse import urlparse

import requests

from .data_cache import CacheBusy
from .market_clock import book_is_fresh, clock, market_now, observed_quote, utc_bounds


class DataUnavailable(RuntimeError):
    pass


def executable_quote(book):
    """Use only positive-depth levels for marks, signals and liquidation.

    A zero-size best-price row is not an executable quote. The execution engine
    already skips zero-size levels; valuation and admission must agree with it.
    """
    if not isinstance(book, dict):
        raise DataUnavailable("Нет достоверного стакана")
    best = []
    for field in ("bids", "asks"):
        levels = book.get(field)
        if not isinstance(levels, list) or not levels:
            raise DataUnavailable("Нет исполнимой котировки для PAPER-решения")
        selected = None
        previous_price = None
        descending = field == "bids"
        for level in levels:
            if (not isinstance(level, (list, tuple)) or len(level) != 2 or
                    any(type(x) not in (int, float) or not math.isfinite(x)
                        for x in level) or level[0] <= 0 or level[1] < 0):
                raise DataUnavailable("Повреждена котировка: цены или объёмы стакана")
            price = level[0]
            # Validate the executable price ladder independently of upstream
            # adapters. Zero-size rows are not executable, and may be ignored
            # in valuation (including synthetic legacy snapshots).
            if level[1] > 0:
                if previous_price is not None and (
                    price >= previous_price if descending else price <= previous_price
                ):
                    raise DataUnavailable("Нарушен порядок исполнимых уровней стакана")
                previous_price = price
                if selected is None:
                    selected = price
        if selected is None:
            raise DataUnavailable("Нет положительной глубины стакана")
        best.append(selected)
    if best[0] > best[1]:
        raise DataUnavailable("Повреждена котировка: пересечённые исполнимые уровни стакана")
    return best[0], best[1]



def canonical_up_down_tokens(tokens):
    """Require exactly one distinct token for each binary outcome.

    This is checked both when decoding Gamma metadata and at PAPER admission:
    external fixtures or future data adapters must not bypass discovery checks.
    No decision is made about which outcome wins here.
    """
    if not isinstance(tokens, dict) or set(tokens) != {"UP", "DOWN"}:
        raise DataUnavailable("Неоднозначное соответствие токенов UP/DOWN")
    up, down = tokens["UP"], tokens["DOWN"]
    if (type(up) is not str or type(down) is not str
        or not up or not down or up == down
        or any(ch.isspace() for token in (up, down) for ch in token)):
        raise DataUnavailable("Некорректные или совпадающие токены UP/DOWN")
    return {"UP": up, "DOWN": down}


def verified_paper_market(market):
    """Reject malformed discovered markets before requesting quotes or changing PAPER state."""
    if not isinstance(market, dict):
        raise DataUnavailable("Не подтверждены данные рынка Polymarket")
    for field in ("condition", "slug"):
        value = market.get(field)
        if type(value) is not str or not value.strip() or value != value.strip():
            raise DataUnavailable("Не подтверждён идентификатор рынка Polymarket")
    start, end = market.get("start"), market.get("end")
    if (type(start) not in (float, int) or type(end) not in (float, int)
        or not math.isfinite(start) or not math.isfinite(end) or start >= end):
        raise DataUnavailable("Не подтверждены временные границы рынка Polymarket")
    return canonical_up_down_tokens(market.get("tokens"))

def check_book_time(stamp, source, details=None):
    now = time.time()
    low, high = utc_bounds()
    age = low - stamp
    if not book_is_fresh(stamp):
        hint = (
            "Снимок опережает сверенное UTC; PAPER-исполнение отложено"
            if age < -0.5
            else "Снимок старше допуска; ожидается свежий снимок источника"
        )
        raise DataUnavailable(
            f"Устаревший стакан {source}: возраст=[{age:+.3f}, {high - stamp:+.3f}] с; допуск=[-0.500, +3.000] с; локальное UTC={now:.3f}; время стакана UTC={stamp:.3f}; сверенное UTC=[{low:.3f}, {high:.3f}]. {hint}"
            + (
                "; получение=" + json.dumps(details, ensure_ascii=False)
                if details
                else ""
            )
        )


class PublicData:
    HOSTS = {
        "api.bybit.com",
        "gamma-api.polymarket.com",
        "clob.polymarket.com",
        "data-api.polymarket.com",
        "api.binance.com",
    }

    def __init__(self):
        self._thread = threading.local()
        self._sessions = []
        self._lock = threading.RLock()
        self.stop_event = threading.Event()
        self.cooldowns = {}
        self.cache = {}
        self.shared = None
        self._cache_warning_at = -math.inf
        path = os.environ.get("BCC_PUBLIC_CACHE")
        if path:
            from .data_cache import PublicCache

            self.shared = PublicCache(path)

    @property
    def session(self):
        if not hasattr(self._thread, "session"):
            self._thread.session = requests.Session()
            with self._lock:
                self._sessions.append(self._thread.session)
        return self._thread.session

    def close(self):
        self.stop_event.set()
        for session in self._sessions:
            session.close()
        if self.shared:
            self.shared.close()

    def _finish_shared(self, *args, **kwargs):
        try:
            self.shared.finish(*args, **kwargs)
        except CacheBusy as exc:
            # The request already owns a committed budget reservation. A failure
            # to cache its result does not invalidate the actual HTTP response.
            # A lease we could not release expires normally; no new request may
            # bypass begin(), the host budget, or a provider cooldown.
            with self._lock:
                if time.monotonic() >= self._cache_warning_at:
                    logging.warning("PUBLIC_CACHE: %s", exc)
                    self._cache_warning_at = time.monotonic() + 30

    def get(self, url, params=None, ttl=0):
        began = time.monotonic()

        def received(data, via):
            self._thread.last_read = dict(
                url=url,
                via=via,
                elapsed_seconds=time.monotonic() - began,
                received_pc=time.time(),
            )
            return data

        if self.stop_event.is_set():
            raise DataUnavailable("Получение данных остановлено")
        host = urlparse(url).hostname
        if host not in self.HOSTS or urlparse(url).scheme != "https":
            raise ValueError("Непубличный источник")
        # Optional hub consumer: this worker NEVER falls back to direct HTTP.
        # Registration is refreshed by actual demand, not by a synthetic scan.
        if os.environ.get("BCC_MARKET_HUB_MODE") == "client":
            if self.shared is None:
                raise DataUnavailable("Market Data Hub requires BCC_PUBLIC_CACHE")
            from .market_hub import HubRegistry
            registry = HubRegistry(self.shared.path)
            registry.subscribe(url, params)
            deadline = time.monotonic() + 2.0
            while not self.stop_event.is_set():
                try:
                    cached = self.shared.read_fresh(url, params, host)
                except CacheBusy as exc:
                    raise DataUnavailable(str(exc)) from exc
                if cached is not None:
                    return received(cached, "market_hub")
                if time.monotonic() >= deadline:
                    raise DataUnavailable("Market Data Hub: нет свежего снимка")
                self.stop_event.wait(0.05)
            raise DataUnavailable("Получение данных остановлено")
        now = time.time()
        key = (url, json.dumps(params, sort_keys=True))
        with self._lock:
            if ttl > 0 and key in self.cache and 0 <= now - self.cache[key][0] <= ttl:
                return received(self.cache[key][1], "memory_cache")
        if now < self.cooldowns.get(host, 0):
            # A local exchange cooldown must deny NEW requests, not a fresh
            # shared cache hit. Use a read-only lookup so a miss cannot
            # reserve a new provider request behind the cooldown.
            if self.shared:
                try:
                    cached = self.shared.read_fresh(url, params, host)
                except CacheBusy as exc:
                    raise DataUnavailable(str(exc)) from exc
                if cached is not None:
                    return received(cached, "shared_cache")
            raise DataUnavailable("Источник временно ограничил запросы: " + host)
        owner = None
        shared_key = None
        if self.shared:
            # A lease means another worker is already fetching this *same*
            # public response. Wait briefly for its committed shared result
            # instead of discarding the symbol's entire scheduler tick.
            # Other cache failures (host budget/cooldown, SQLite busy) must
            # remain hard denials; never bypass the cross-process limiter.
            lease_deadline = time.monotonic() + 13.0
            while True:
                if self.stop_event.is_set():
                    raise DataUnavailable("Получение данных остановлено")
                try:
                    shared_key, owner, cached = self.shared.begin(url, params, host)
                    break
                except CacheBusy as e:
                    if (str(e) != "Данные уже запрашиваются другим ботом"
                            or time.monotonic() >= lease_deadline):
                        raise DataUnavailable(str(e)) from e
                    if self.stop_event.wait(0.075):
                        raise DataUnavailable("Получение данных остановлено")
            if owner is None:
                return received(cached, "shared_cache")
        try:
            response = self.session.get(url, params=params, timeout=(3, 8))
            if response.status_code in (403, 418, 429):
                try:
                    delay = max(
                        90, min(3600, float(response.headers.get("Retry-After", 90)))
                    )
                except ValueError:
                    delay = 90
                self.cooldowns[host] = now + delay
            response.raise_for_status()
            try:
                data = response.json()
            except ValueError as e:
                raise ValueError(
                    f"Источник вернул не JSON (HTTP {response.status_code}, "
                    + response.headers.get("Content-Type", "неизвестный формат")
                    + ")"
                ) from e
        except (requests.RequestException, ValueError) as e:
            delay = max(10, self.cooldowns.get(host, now) - now)
            self.cooldowns[host] = max(self.cooldowns.get(host, 0), time.time() + delay)
            if self.shared:
                self._finish_shared(shared_key, owner, host, cooldown=delay)
            raise DataUnavailable(f"{host}: {e}") from e
        if self.shared:
            cache_ttl = ttl or (
                0.35
                if "orderbook" in url or "/book" in url
                else 1
                if "kline" in url
                else 60
                if "funding" in url
                else 3600
                if "instruments" in url
                else 0.5
            )
            self._finish_shared(shared_key, owner, host, data, cache_ttl)
        with self._lock:
            self.cache[key] = (now, data)
            if len(self.cache) > 1000:
                self.cache = {
                    k: v
                    for k, v in self.cache.items()
                    if now - v[0] < 600 or k[0] == "bars"
                }
        return received(data, "http")

    def bybit(self, route, params):
        data = self.get(
            "https://api.bybit.com/v5/market/" + route, {"category": "linear", **params}
        )
        if data.get("retCode") != 0:
            raise DataUnavailable("Bybit: " + str(data.get("retMsg")))
        return data

    def quote(self, symbol):
        clock.ensure()
        data = self.bybit("tickers", {"symbol": symbol})
        try:
            rows = data["result"]["list"]
            if not isinstance(rows, list) or len(rows) != 1:
                raise DataUnavailable("Bybit: неоднозначный ответ котировки")
            item = rows[0]
            if not isinstance(item, dict) or item.get("symbol") != symbol:
                raise DataUnavailable("Bybit: котировка другой торговой пары")
            bid = float(item["bid1Price"])
            ask = float(item["ask1Price"])
        except (TypeError, KeyError, IndexError, ValueError, OverflowError) as exc:
            raise DataUnavailable("Bybit: повреждена котировка торговой пары") from exc
        if not all(math.isfinite(x) and x > 0 for x in (bid, ask)) or bid > ask:
            raise DataUnavailable("Невалидная котировка")
        remote = float(data["time"]) / 1000
        if not -5 <= market_now() - remote <= 15:
            raise DataUnavailable("Устаревшая котировка Bybit")
        return bid, ask, remote

    def list_symbols(self):
        from .config import valid_symbol

        cursor = None
        symbols = set()
        for _ in range(30):
            args = {"limit": 1000}
            if cursor:
                args["cursor"] = cursor
            result = self.bybit("instruments-info", args)["result"]
            symbols.update(
                x["symbol"]
                for x in result["list"]
                if x.get("status") == "Trading"
                and x.get("quoteCoin") == "USDT"
                and x.get("contractType") == "LinearPerpetual"
                and valid_symbol(x["symbol"], "VELES")
            )
            next_cursor = result.get("nextPageCursor")
            if not next_cursor:
                break
            if cursor == next_cursor:
                raise DataUnavailable("Не удалось получить полный список пар")
            cursor = next_cursor
        else:
            # Reaching the pagination cap is not proof of a complete catalog.
            # Explicitly reject instead of silently presenting a partial list.
            raise DataUnavailable("Не получен полный список пар Bybit (лимит страниц)")
        return sorted(symbols)

    def candles(self, symbol, required=500):
        clock.ensure()
        required = max(100, int(required))
        with self._lock:
            previous = self.cache.get(("bars", symbol), (0, []))[1]
        # Re-fetch the unfinished tail; its OHLCV must replace the older sample.
        recent_tail = previous and market_now() * 1000 - previous[-1]["t"] <= 9 * 60000
        count = 10 if len(previous) >= required and recent_tail else required
        found = {b["t"]: b for b in previous}
        end = None
        for _ in range((count + 999) // 1000):
            args = {"symbol": symbol, "interval": "1", "limit": min(1000, count)}
            if end is not None:
                args["end"] = end
            data = self.bybit("kline", args)
            rows = data["result"]["list"]
            if not rows:
                break
            for row in rows:
                found[int(row[0])] = dict(
                    t=int(row[0]),
                    open=float(row[1]),
                    high=float(row[2]),
                    low=float(row[3]),
                    close=float(row[4]),
                    volume=float(row[5]),
                )
            end = min(int(row[0]) for row in rows) - 1
            count -= len(rows)
            if count <= 0:
                break
        bars = [found[t] for t in sorted(found)][-required:]
        if not bars or any(b["t"] - a["t"] != 60000 for a, b in zip(bars, bars[1:])):
            raise DataUnavailable("Разрывы в истории свечей")
        if not 0 <= market_now() - bars[-1]["t"] / 1000 < 120:
            raise DataUnavailable("Устаревшие свечи")
        from .indicators import aggregate

        aggregate(bars, 1, int(market_now() * 1000), "intrabar")
        with self._lock:
            self.cache[("bars", symbol)] = (time.time(), bars)
        return bars

    def orderbook(self, symbol):
        clock.ensure()
        instrument = self.get(
            "https://api.bybit.com/v5/market/instruments-info",
            {"category": "linear", "symbol": symbol},
            ttl=3600,
        )["result"]["list"][0]
        if (
            instrument.get("symbol") != symbol
            or instrument.get("status") != "Trading"
            or instrument.get("contractType") != "LinearPerpetual"
            or instrument.get("quoteCoin") != "USDT"
        ):
            raise DataUnavailable(
                "Метаданные не подтверждают доступный бессрочный USDT-контракт "
                + symbol
            )
        # Metadata may require a separate network round trip on the first read.
        # Fetch the executable snapshot only after that round trip has finished.
        response = self.bybit("orderbook", {"symbol": symbol, "limit": 200})
        data = response["result"]
        if data.get("s") != symbol:
            raise DataUnavailable("Стакан другой монеты")
        lots = instrument["lotSizeFilter"]
        stamp = float(data["ts"]) / 1000
        bids = [[float(p), float(q)] for p, q in data["b"]]
        asks = [[float(p), float(q)] for p, q in data["a"]]
        for levels, descending in ((bids, True), (asks, False)):
            if not levels or any(
                not math.isfinite(p) or not math.isfinite(q) or p <= 0 or q < 0
                for p, q in levels
            ):
                raise DataUnavailable("Повреждён стакан")
            if any(
                (a[0] <= b[0] if descending else a[0] >= b[0])
                for a, b in zip(levels, levels[1:])
            ):
                raise DataUnavailable("Порядок уровней стакана")
        executable_quote({"bids": bids, "asks": asks})
        transport = getattr(self._thread, "last_read", {})
        response_at = float(response["time"]) / 1000
        check_book_time(
            stamp,
            "Bybit",
            {**transport, "response_minus_book_seconds": response_at - stamp},
        )
        result = dict(
            bids=bids,
            asks=asks,
            at=stamp,
            qty_step=float(lots["qtyStep"]),
            min_qty=float(lots["minOrderQty"]),
            min_notional=float(lots.get("minNotionalValue", 5)),
            tick_size=float(instrument["priceFilter"]["tickSize"]),
            max_qty=float(lots["maxMktOrderQty"]),
            response_at=response_at,
            transport=transport,
            engine_at=float(data["cts"]) / 1000
            if data.get("cts") is not None
            else None,
            update_id=data.get("u"),
            sequence=data.get("seq"),
        )
        if any(
            not math.isfinite(result[key]) or result[key] <= 0
            for key in ("qty_step", "min_qty", "min_notional", "tick_size", "max_qty")
        ):
            raise DataUnavailable("Некорректные биржевые ограничения объёма / цены")
        return result

    def funding(self, symbol):
        data = self.get(
            "https://api.bybit.com/v5/market/funding/history",
            {"category": "linear", "symbol": symbol, "limit": 50},
            ttl=60,
        )
        if data.get("retCode") != 0:
            raise DataUnavailable("Нет истории funding")
        return [
            {
                "at": int(x["fundingRateTimestamp"]) / 1000,
                "rate": float(x["fundingRate"]),
            }
            for x in data["result"]["list"]
        ]

    def funding_mark(self, symbol, at):
        data = self.get(
            "https://api.bybit.com/v5/market/mark-price-kline",
            {
                "category": "linear",
                "symbol": symbol,
                "interval": "1",
                "start": int(at * 1000),
                "limit": 1,
            },
            ttl=3600,
        )
        rows = data.get("result", {}).get("list", [])
        if data.get("retCode") != 0 or not rows or int(rows[0][0]) != int(at * 1000):
            raise DataUnavailable("Нет mark-price на время funding")
        price = float(rows[0][1])
        if not math.isfinite(price) or price <= 0:
            raise DataUnavailable("Некорректная mark-price funding")
        return price


def iso_time(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()


COIN_NAMES = {
    "BTC": "bitcoin",
    "ETH": "ethereum",
    "SOL": "solana",
    "XRP": "xrp",
    "DOGE": "dogecoin",
    "HYPE": "hyperliquid",
    "ZEC": "zcash",
}


class PolymarketData(PublicData):
    """Gamma discovery + CLOB executable depth + official resolved payouts.

    References: docs.polymarket.com/market-data/discover-markets and
    docs.polymarket.com/market-data/public-analytics (GET /v2/tokens).
    """

    def list_symbols(self):
        """Return the strategy's selectable coin catalog, NOT live market availability.

        The Gamma markets endpoint lists markets, not supported coin symbols.
        Paging a small arbitrary window of active markets silently returns no
        matching coins when the catalogue is dominated by unrelated events.
        A concrete coin/duration market is verified by discover() on demand,
        and again at PAPER entry. No catalog entry promises a live orderbook.
        """
        return sorted(COIN_NAMES)

    def discover(self, coin, duration, now=None):
        clock.ensure()
        now = market_now(now)
        if duration in (300, 900):
            slug = f"{coin.lower()}-updown-{duration // 60}m-{int(now) // duration * duration}"
            rows = self.get(
                "https://gamma-api.polymarket.com/markets", {"slug": slug}, ttl=3
            )
        else:
            # Hourly slugs use local-language dates; discover them from metadata.
            rows = []
            for offset in range(0, 1000, 100):
                batch = self.get(
                    "https://gamma-api.polymarket.com/markets",
                    {
                        "active": "true",
                        "closed": "false",
                        "limit": 100,
                        "offset": offset,
                        "end_date_min": datetime.fromtimestamp(
                            now, timezone.utc
                        ).isoformat(),
                        "end_date_max": datetime.fromtimestamp(
                            now + 3700, timezone.utc
                        ).isoformat(),
                    },
                    ttl=20,
                )
                rows.extend(batch)
                if len(batch) < 100:
                    break
        candidates = []
        for row in rows:
            try:
                slug = row["slug"]
                title = row["question"].lower()
                if "up or down" not in title:
                    continue
                name = COIN_NAMES.get(coin, coin.lower())
                if not (
                    title.startswith(name + " ")
                    or slug.startswith(coin.lower() + "-")
                    or slug.startswith(name + "-")
                ):
                    continue
                end = iso_time(row["endDate"])
                matched = re.search(r"-updown-(5|15)m-(\d+)$", slug)
                if matched:
                    start = float(matched.group(2))
                    actual = int(matched.group(1)) * 60
                else:
                    event = (row.get("events") or [{}])[0]
                    start = iso_time(
                        row.get("eventStartTime")
                        or event.get("startTime")
                        or row.get("gameStartTime")
                        or ""
                    )
                    actual = int(round(end - start))
                if (
                    actual != duration
                    or abs(end - start - duration) > 1
                    or not start <= now < end
                    or row.get("closed")
                    or row.get("acceptingOrders") is not True
                ):
                    continue
                outcomes = row["outcomes"]
                tokens = row["clobTokenIds"]
                if isinstance(outcomes, str):
                    outcomes = json.loads(outcomes)
                if isinstance(tokens, str):
                    tokens = json.loads(tokens)
                # A truncated zip or duplicate outcome must not silently turn
                # ambiguous metadata into an apparently tradable UP/DOWN pair.
                if (not isinstance(outcomes, list) or not isinstance(tokens, list)
                    or len(outcomes) != 2 or len(tokens) != 2
                    or any(not isinstance(x, str) for x in outcomes + tokens)):
                    continue
                names = [name.strip().upper() for name in outcomes]
                ids = [token.strip() for token in tokens]
                if set(names) != {"UP", "DOWN"}:
                    continue
                try:
                    mapping = canonical_up_down_tokens(dict(zip(names, ids)))
                except DataUnavailable:
                    continue
                candidates.append(
                    dict(
                        id=str(row["id"]),
                        condition=row["conditionId"],
                        slug=slug,
                        start=start,
                        end=end,
                        tokens=mapping,
                        fees_enabled=row.get("feesEnabled"),
                        fee_schedule=row.get("feeSchedule")
                        if row.get("feesEnabled") is not False
                        else {"rate": 0.0, "exponent": 1},
                        min_size=row.get("orderMinSize"),
                        tick_size=row.get("orderPriceMinTickSize"),
                    )
                )
            except (KeyError, ValueError, TypeError):
                continue
        if len(candidates) != 1:
            raise DataUnavailable(
                "Не найден единственный активный UP/DOWN рынок "
                + coin
                + f" {duration // 60}m"
            )
        return candidates[0]

    def impulse(self, coin, start, now):
        # Signal source is Binance spot; settlement never uses this price.
        rows = self.get(
            "https://api.binance.com/api/v3/klines",
            {
                "symbol": coin + "USDT",
                "interval": "1m",
                "startTime": int(start * 1000),
                "limit": 1,
            },
            ttl=60,
        )
        if not rows or int(rows[0][0]) != int(start * 1000):
            raise DataUnavailable("Нет цены начала рынка")
        first = float(rows[0][1])
        ticker = self.get(
            "https://api.binance.com/api/v3/ticker/price",
            {"symbol": coin + "USDT"},
            ttl=0.5,
        )
        # A response belonging to a different symbol must not invert the
        # impulse direction and purchase the wrong UP/DOWN PAPER outcome.
        if not isinstance(ticker, dict) or ticker.get("symbol") != coin + "USDT":
            raise DataUnavailable("Котировка другой торговой пары Binance")
        last = float(ticker["price"])
        if not all(math.isfinite(x) and x > 0 for x in (first, last)):
            raise DataUnavailable("Некорректная цена импульса")
        return last - first, 100 * (last / first - 1)

    def indicator_bars(self, coin, required, now):
        """Verified closed Binance 1m OHLCV for optional indicator conditions.

        Public endpoint only. Never use incomplete current-minute candles,
        shifted timestamps, gaps, or data that may belong to another market.
        """
        from .poly_indicators import MAX_BARS
        from .indicators import aggregate
        if type(required) is not int or not 2 <= required <= MAX_BARS:
            raise DataUnavailable("Недопустимая длина истории для фильтра")
        if type(now) not in (float, int) or not math.isfinite(now):
            raise DataUnavailable("Некорректное время фильтра")
        minute_start = int(now // 60) * 60000
        rows = self.get("https://api.binance.com/api/v3/klines", {
            "symbol": coin + "USDT", "interval": "1m",
            "endTime": minute_start - 1, "limit": required,
        }, ttl=0)
        if not isinstance(rows, list) or len(rows) < required:
            raise DataUnavailable("Недостаточно свечей для фильтра")
        candles = []
        for row in rows[-required:]:
            try:
                t = int(row[0])
                close_at = int(row[6])
                values = [float(row[x]) for x in (1, 2, 3, 4, 5)]
            except (IndexError, TypeError, ValueError, OverflowError) as exc:
                raise DataUnavailable("Повреждён ответ свечей Binance") from exc
            if t % 60000 or close_at != t + 59999 or close_at >= minute_start:
                raise DataUnavailable("Незакрытая или смещённая свеча Binance")
            candles.append(dict(t=t, open=values[0], high=values[1], low=values[2],
                                close=values[3], volume=values[4]))
        if candles[-1]["t"] != minute_start - 60000:
            raise DataUnavailable("Нет последней закрытой свечи Binance")
        if any(b["t"] - a["t"] != 60000 for a, b in zip(candles, candles[1:])):
            raise DataUnavailable("Пропуск минутных свечей Binance")
        try:
            aggregate(candles, 1, minute_start, "bar_close")
        except (TypeError, ValueError, KeyError) as exc:
            raise DataUnavailable("Недостоверные данные OHLCV Binance") from exc
        return candles

    def book(self, token):
        clock.ensure()
        data = self.get("https://clob.polymarket.com/book", {"token_id": token})
        if str(data.get("asset_id")) != token:
            raise DataUnavailable("Стакан другого токена")
        stamp = float(data["timestamp"]) / 1000
        check_book_time(stamp, "Polymarket")
        return data["asks"], stamp

    def execution_terms(self, market, require_fees=True):
        schedule = market.get("fee_schedule")
        if (
            not schedule
            and require_fees
            or market.get("min_size") is None
            or market.get("tick_size") is None
        ):
            data = self.get(
                "https://clob.polymarket.com/clob-markets/" + market["condition"],
                ttl=60,
            )
            details = data.get("fd", {})
            if not schedule:
                schedule = {"rate": details.get("r"), "exponent": details.get("e")}
            market["min_size"] = data.get("mos")
            market["tick_size"] = data.get("mts")
        minimum = float(market["min_size"])
        tick = float(market["tick_size"])
        if (
            not math.isfinite(minimum)
            or minimum <= 0
            or not math.isfinite(tick)
            or not 0 < tick < 1
        ):
            raise DataUnavailable("Не подтверждены ограничения ордеров рынка")
        if not require_fees:
            return {"fee_schedule": None, "min_size": minimum, "tick_size": tick}
        rate = schedule.get("rate")
        exponent = schedule.get("exponent")
        if (
            any(
                type(x) not in (int, float) or not math.isfinite(x)
                for x in (rate, exponent)
            )
            or not 0 <= rate <= 1
            or not 0 <= exponent <= 4
        ):
            raise DataUnavailable("Не подтверждены публичные параметры комиссии")
        return {
            "fee_schedule": {"rate": rate, "exponent": exponent},
            "min_size": minimum,
            "tick_size": tick,
        }

    def payout(self, token):
        data = self.get(
            "https://data-api.polymarket.com/v2/tokens", {"token_id": token}, ttl=5
        )
        rows = data.get("data", []) if isinstance(data, dict) else []
        if isinstance(rows, dict):
            rows = rows.get("items", [])
        if not isinstance(rows, list):
            raise DataUnavailable("Неверная структура официальных исходов")
        matches = []
        for row in rows:
            if not isinstance(row, dict):
                raise DataUnavailable("Повреждён ответ официальных исходов")
            asset = str(
                row.get("asset_id", row.get("assetId", row.get("token_id", "")))
            )
            if asset != token:
                continue
            # Any unresolved or invalid duplicate makes the official result
            # ambiguous. Never choose the first record or settle twice.
            if row.get("resolved") is not True:
                return None
            value = row.get("final_price", row.get("finalPrice"))
            try:
                payout = float(value) if value is not None else float("nan")
            except (ValueError, TypeError, OverflowError):
                return None
            if not math.isfinite(payout) or not 0 <= payout <= 1:
                return None
            matches.append(payout)
        if not matches:
            return None
        if any(payout != matches[0] for payout in matches[1:]):
            raise DataUnavailable("Противоречивые официальные исходы рынка")
        return matches[0]

    def outcome_quote(self, token):
        clock.ensure()
        data = self.get("https://clob.polymarket.com/book", {"token_id": token})
        if str(data.get("asset_id")) != token:
            raise DataUnavailable("Стакан другого исхода")
        at = float(data["timestamp"]) / 1000
        if not book_is_fresh(at):
            raise DataUnavailable("Устаревшая оценка позиции")
        # Validate *every* level before choosing executable bid/ask depth.
        # Ignoring a negative, NaN or infinite size can make a damaged CLOB
        # response look like a trustworthy PAPER collateral mark.
        def executable_prices(side):
            rows = data.get(side)
            if not isinstance(rows, list):
                raise DataUnavailable("Повреждён стакан оценки позиции")
            prices = []
            for row in rows:
                if not isinstance(row, dict):
                    raise DataUnavailable("Повреждён стакан оценки позиции")
                try:
                    price, size = float(row["price"]), float(row["size"])
                except (KeyError, TypeError, ValueError, OverflowError) as exc:
                    raise DataUnavailable("Повреждён стакан оценки позиции") from exc
                if (not math.isfinite(price) or not math.isfinite(size)
                        or not 0 < price < 1 or size < 0):
                    raise DataUnavailable("Повреждён стакан оценки позиции")
                if size > 0:
                    prices.append(price)
            return prices

        bids = executable_prices("bids")
        asks = executable_prices("asks")
        if not bids or not asks or max(bids) > min(asks):
            raise DataUnavailable("Нет достоверной оценки позиции")
        return observed_quote({"bid": max(bids), "ask": min(asks), "at": at})


def estimate_buy(asks, budget, max_ask, fee_rate, fee_schedule=None):
    clean = []
    for row in asks:
        price = float(row["price"])
        size = float(row["size"])
        if (
            not math.isfinite(price)
            or not math.isfinite(size)
            or not 0 < price < 1
            or size < 0
        ):
            raise DataUnavailable("Повреждён стакан")
        if price <= max_ask:
            clean.append((price, size))
    clean.sort()
    left = budget
    cost = shares = fee = 0
    for price, size in clean:
        per_share = (
            fee_schedule["rate"] * (price * (1 - price)) ** fee_schedule["exponent"]
            if fee_schedule is not None
            else price * fee_rate
        )
        qty = min(size, left / (price + per_share))
        cost += price * qty
        fee += per_share * qty
        shares += qty
        left -= (price + per_share) * qty
        if left <= 1e-8:
            break
    if left > 1e-7 or shares <= 0:
        raise DataUnavailable("Недостаточная глубина стакана")
    return cost, shares, fee
