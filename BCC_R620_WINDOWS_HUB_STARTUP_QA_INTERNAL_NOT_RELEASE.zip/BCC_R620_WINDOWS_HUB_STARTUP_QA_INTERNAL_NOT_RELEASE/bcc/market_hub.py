"""Optional cross-process public-data hub transport (PAPER; no account writes).

Workers register validated public GET requests.  Only the hub producer performs
HTTP; results pass through PublicCache's existing TTL/budget/lease controls.
The mode is explicitly opt-in until native Windows lifecycle E2E is accepted.
"""
import json
import math
import os
import uuid
import sqlite3
import time
import threading
from pathlib import Path
from urllib.parse import urlparse

from .data_cache import PublicCache, CacheBusy


class HubRegistry:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init()

    def _connect(self):
        db = sqlite3.connect(self.path, timeout=1.0, isolation_level=None)
        db.execute('PRAGMA busy_timeout=1000')
        return db

    def _init(self):
        with self._connect() as db:
            # A journal-mode *change* needs exclusive access on Windows. The
            # supervisor also reads this schema while the producer starts:
            # do not try to reconfigure WAL on every readiness poll.
            mode = db.execute('PRAGMA journal_mode').fetchone()[0]
            if mode.lower() != 'wal':
                mode = db.execute('PRAGMA journal_mode=WAL').fetchone()[0]
                if mode.lower() != 'wal':
                    raise sqlite3.OperationalError('Market Hub requires SQLite WAL mode')
            db.execute('''CREATE TABLE IF NOT EXISTS hub_subscriptions(
              k TEXT PRIMARY KEY, url TEXT NOT NULL, params TEXT NOT NULL,
              active_until REAL NOT NULL, next_due REAL NOT NULL DEFAULT 0,
              last_error TEXT NOT NULL DEFAULT '')''')
            db.execute('CREATE INDEX IF NOT EXISTS hub_due ON hub_subscriptions(next_due,active_until)')
            db.execute("CREATE TABLE IF NOT EXISTS hub_leader(singleton INTEGER PRIMARY KEY CHECK(singleton=1), owner TEXT NOT NULL, expires REAL NOT NULL)")

    def claim_leader(self, owner, *, lifetime=15):
        if not owner or not 1 <= lifetime <= 120:
            raise ValueError('Invalid hub lease')
        now = time.time()
        with self._connect() as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute("""INSERT INTO hub_leader(singleton,owner,expires) VALUES(1,?,?)
              ON CONFLICT(singleton) DO UPDATE SET owner=excluded.owner,expires=excluded.expires
              WHERE hub_leader.expires < ? OR hub_leader.owner = ?""",
              (owner, now + lifetime, now, owner))
            claimed = db.execute('SELECT owner FROM hub_leader WHERE singleton=1').fetchone()
            db.commit()
        return bool(claimed and claimed[0] == owner)

    def renew_leader(self, owner, *, lifetime=120):
        if not owner or not 1 <= lifetime <= 120:
            raise ValueError('Invalid hub lease')
        now = time.time()
        with self._connect() as db:
            cursor = db.execute("UPDATE hub_leader SET expires=? WHERE singleton=1 AND owner=? AND expires>=?", (now+lifetime,owner,now))
            return cursor.rowcount == 1

    def release_leader(self, owner):
        with self._connect() as db:
            db.execute('DELETE FROM hub_leader WHERE singleton=1 AND owner=?', (owner,))

    def finish_owned(self, key, delay, owner, error=''):
        """Acknowledge only while this producer still holds an unexpired lease.

        The ownership check and subscription update share one SQLite writer
        transaction so a replacement producer cannot be raced by an old one.
        """
        now = time.time()
        with self._connect() as db:
            db.execute('BEGIN IMMEDIATE')
            valid = db.execute(
                'SELECT 1 FROM hub_leader WHERE singleton=1 AND owner=? AND expires>=?',
                (owner, now),
            ).fetchone()
            if not valid:
                db.rollback()
                return False
            db.execute('UPDATE hub_subscriptions SET next_due=?,last_error=? WHERE k=?',
                       (now + delay, str(error)[:300], key))
            db.commit()
        return True

    @staticmethod
    def identity(url, params):
        import hashlib
        # Nonfinite values are not legal JSON; allowing NaN/Infinity into a
        # durable subscription can make two processes disagree on its identity.
        try:
            params_text = json.dumps(params, sort_keys=True, separators=(',', ':'), allow_nan=False)
            identity_text = json.dumps([url, params], sort_keys=True, allow_nan=False)
        except (TypeError, ValueError) as exc:
            raise ValueError('Hub params must contain finite JSON values') from exc
        key = hashlib.sha256(identity_text.encode()).hexdigest()
        return key, params_text

    def subscribe(self, url, params, *, lifetime=60):
        if (type(lifetime) not in (int, float) or not math.isfinite(lifetime)
                or not 0 < lifetime <= 3600):
            raise ValueError('Hub subscription lifetime must be finite and positive')
        from .market import PublicData
        parsed = urlparse(url)
        if parsed.scheme != 'https' or parsed.hostname not in PublicData.HOSTS:
            raise ValueError('Hub accepts only supported public HTTPS sources')
        if not isinstance(params, (dict, type(None))):
            raise ValueError('Hub params must be a JSON object')
        key, encoded = self.identity(url, params)
        now = time.time()
        with self._connect() as db:
            db.execute('''INSERT INTO hub_subscriptions(k,url,params,active_until,next_due)
              VALUES(?,?,?,?,0) ON CONFLICT(k) DO UPDATE SET
              active_until=excluded.active_until''', (key, url, encoded, now + lifetime))
        return key

    def has_active_subscriptions(self):
        """Read-only liveness probe for the independent producer lifecycle.

        Workers renew subscriptions during active reads. Stopped workers no
        longer renew, so the hub may retire after their leases expire.
        """
        with self._connect() as db:
            return db.execute(
                'SELECT 1 FROM hub_subscriptions WHERE active_until>? LIMIT 1',
                (time.time(),),
            ).fetchone() is not None

    def due(self, limit=32):
        with self._connect() as db:
            rows = db.execute('''SELECT k,url,params FROM hub_subscriptions
               WHERE active_until>? AND next_due<=? ORDER BY next_due,k LIMIT ?''',
               (time.time(), time.time(), limit)).fetchall()
        return [(key, url, json.loads(params)) for key, url, params in rows]

    def finish(self, key, delay, error=''):
        with self._connect() as db:
            db.execute('UPDATE hub_subscriptions SET next_due=?,last_error=? WHERE k=?',
                       (time.time() + delay, str(error)[:300], key))


class MarketDataHub:
    """Single producer intended to run as one managed service process."""
    def __init__(self, cache_path, source=None):
        from .market import PublicData
        self.registry = HubRegistry(cache_path)
        self.owner = f"{os.getpid()}:{uuid.uuid4().hex}"
        self.lease_renew_interval = 5.0
        self.source = source or PublicData()
        if self.source.shared is None:
            self.source.shared = PublicCache(cache_path)

    def run_once(self, limit=32):
        if not self.registry.claim_leader(self.owner, lifetime=120):
            return []
        results = []
        for key, url, params in self.registry.due(limit):
            if not self.registry.renew_leader(self.owner, lifetime=120):
                break
            delay = .25 if 'orderbook' in url or '/book' in url else 1.0
            stop_renewal = threading.Event()
            lease_lost = threading.Event()

            def keep_lease():
                # The producer is not idle while an HTTP request is in flight.
                # Another hub must not take ownership just because HTTP is slow.
                while not stop_renewal.wait(self.lease_renew_interval):
                    try:
                        if not self.registry.renew_leader(self.owner, lifetime=120):
                            lease_lost.set()
                            return
                    except sqlite3.Error:
                        # Failure to renew means we can no longer prove ownership.
                        lease_lost.set()
                        return

            heartbeat = threading.Thread(target=keep_lease, name='hub-lease-renewal', daemon=True)
            heartbeat.start()
            error = None
            try:
                self.source.get(url, params=params)
            except Exception as exc:
                error = exc
            finally:
                stop_renewal.set()
                heartbeat.join(timeout=2)
            # A stale producer must not publish subscription completion after
            # ownership transfer. Cache writes inside source.get are protected
            # separately by PublicCache's per-request ownership lease.
            if lease_lost.is_set() or not self.registry.renew_leader(self.owner, lifetime=120):
                break
            if error is None:
                if not self.registry.finish_owned(key, delay, self.owner):
                    break
                results.append((key, True))
            else:
                if not self.registry.finish_owned(key, 2.0, self.owner, str(error)):
                    break
                results.append((key, False))
        return results

    def close(self):
        self.registry.release_leader(self.owner)
        self.source.close()
