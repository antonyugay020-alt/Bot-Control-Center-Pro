"""The worker event loop: parallel reads, serial decisions, atomic commits."""

import json
import logging
import time

from .control import claim_command, finish_requested, finished
from .funding import apply_funding
from .market import DataUnavailable, executable_quote
from .market_clock import book_is_fresh, market_now, observed_quote, quote_is_recent
from .scheduler import MarketScheduler
from .strategies import record_completed_exit
from .storage import atomic_json, load_json
from .trading import (exit_position, fill_price, liquidations,
                      update_equity_metrics, valid_position_mark, protective_exit)


def log_events(events):
    for e in events:
        logging.info(
            "%s %s %s %s qty=%s price=%s fee=%s pnl=%s %s",
            e["symbol"],
            e["section"],
            e["action"],
            e.get("side", ""),
            e.get("qty", ""),
            e.get("price", ""),
            e.get("fee", ""),
            e.get("net_pnl", ""),
            e.get("reason", ""),
        )


def process_tick(cfg, store, engine, tick):
    now = market_now()
    symbol = tick.symbol
    book = tick.book
    if book is None:
        # Published funding is still valid accounting evidence when the book is
        # unavailable, or the coin was removed after its last trade was closed.
        with store.transaction(include_charts=False) as (state, events):
            # A rejected refresh revokes the prior mark immediately. A mark
            # that remains younger than the generic TTL must not authorize
            # another section's PAPER collateral after its source has failed.
            state["marks"].pop(symbol, None)
            apply_funding(state, events, symbol, tick.rates, tick.funding_marks, now)
            # Preserve both independent market failures. With no book we
            # cannot trade, but losing the history error makes a multi-bot
            # outage look like an unexplained lack of RSI signals.
            failures = []
            if tick.quote_error:
                failures.append({"section": "Стакан", "reason": tick.quote_error})
            if tick.history_error:
                failures.append({"section": "Свечи", "reason": tick.history_error})
            if failures:
                state["diagnostics"][symbol] = failures
            elif not tick.bars:
                state["diagnostics"][symbol] = [
                    {"section": "Рынок", "reason": "Нет стакана и пригодной истории свечей"}
                ]
            else:
                state["diagnostics"][symbol] = [
                    {"section": "Стакан", "reason": "Нет исполнимого стакана"}
                ]
            if tick.bars:
                state.setdefault("charts", {})[symbol] = tick.bars[-120:]
            update_equity_metrics(state)
        log_events(events)
        return
    if not book_is_fresh(book["at"]):
        raise DataUnavailable("Стакан устарел до торгового решения")
    bid, ask = executable_quote(book)
    with store.transaction(include_charts=False) as (state, events):
        state["marks"][symbol] = observed_quote(
            {"bid": bid, "ask": ask, "at": book["at"]}
        )
        state["_books"] = {symbol: book}
        apply_funding(state, events, symbol, tick.rates, tick.funding_marks, now)
        had_manual_pending = any(
            p.get("exit_pending", {}).get("reason") == "MANUAL_PAPER_CLOSE"
            for p in state["positions"].values()
        )
        for key, p in list(state["positions"].items()):
            if p["symbol"] == symbol and p.get("exit_pending"):
                pending = p["exit_pending"]
                exit_position(
                    state,
                    events,
                    key,
                    fill_price(p["side"], "EXIT", bid, ask, p["settings"]),
                    pending["reason"],
                    pending["ratio"],
                    limit=pending.get("limit"),
                    target_index=pending.get("target_index"),
                )
                record_completed_exit(cfg, state, key, p, int(now * 1000))
        liquidation_breach = liquidations(state, events)
        stale = [
            p["symbol"]
            for p in state["positions"].values()
            if (not valid_position_mark(p, state["marks"].get(p["symbol"]))
                or not quote_is_recent(state["marks"].get(p["symbol"])))
        ]
        if stale:
            state["_entry_blocked"] = (
                "Нет свежих котировок открытых позиций: "
                + ", ".join(sorted(set(stale)))
            )
        if symbol not in cfg["symbols"]:
            state["_entry_blocked"] = (
                "Монета удалена из настроек; разрешены только выходы и учёт"
            )
        pending_manual = had_manual_pending or any(
            p.get("exit_pending", {}).get("reason") == "MANUAL_PAPER_CLOSE"
            for p in state["positions"].values()
        )
        if pending_manual:
            state["_entry_blocked"] = "Выполняется ручное закрытие PAPER-позиций"
        liquidating = any(
            p.get("exit_pending", {}).get("reason")
            in ("PAPER_LIQUIDATION", "PAPER_CROSS_LIQUIDATION")
            for p in state["positions"].values()
        )
        if liquidating or liquidation_breach:
            state["diagnostics"][symbol] = [
                {
                    "section": "Маржа",
                    "reason": "Ликвидация или нарушение поддерживающей маржи; новые входы и DCA приостановлены",
                }
            ]
        elif not tick.bars or tick.history_error:
            # Indicator-based entries and exits require closed candles, but
            # quote-driven protection of EXISTING positions must remain live.
            # Do not evaluate the strategy on empty bars: that could also
            # submit new grids/DCA or alter indicator clocks.
            for key, position in list(state["positions"].items()):
                if position["symbol"] != symbol or position.get("exit_pending"):
                    continue
                if protective_exit(state, events, key, bid, ask):
                    if key not in state["positions"]:
                        record_completed_exit(cfg, state, key, position, int(now * 1000))
            state["diagnostics"][symbol] = [{
                "section": "Свечи",
                "reason": tick.history_error or "Нет пригодной истории закрытых свечей",
            }]
        else:
            engine.process(
                cfg, state, events, symbol, tick.bars, bid, ask, int(now * 1000)
            )
        if tick.history_error and (liquidating or liquidation_breach):
            state["diagnostics"].setdefault(symbol, []).append(
                {"section": "Свечи", "reason": tick.history_error}
            )
        state.pop("_books", None)
        state.pop("_entry_blocked", None)
        if tick.bars:
            state.setdefault("charts", {})[symbol] = tick.bars[-120:]
        update_equity_metrics(state)
    log_events(events)


def close_requested_positions(folder, store, books):
    command = claim_command(folder, "close.request")
    if command is None:
        return
    cmd = load_json(command)
    if not isinstance(cmd, dict) or not isinstance(cmd.get("id"), str) or not cmd["id"]:
        raise ValueError("Повреждена команда закрытия PAPER-позиций")
    with store.transaction(include_charts=False) as (state, events):
        if state["strategy"].get("last_close_command") != cmd["id"]:
            state["_books"] = {s: b for s, b in books.items() if book_is_fresh(b["at"])}
            for key, p in list(state["positions"].items()):
                q = state["marks"].get(p["symbol"], {})
                price = q.get("bid" if p["side"] == "LONG" else "ask", p["average"])
                # Missing liquidity creates a durable pending exit; it can never
                # silently consume the command while leaving an untracked deal.
                exit_position(state, events, key, price, "MANUAL_PAPER_CLOSE")
            state["pending"].clear()
            state["strategy"]["last_close_command"] = cmd["id"]
            state.pop("_books", None)
    command.unlink()
    log_events(events)


def run_loop(
    folder,
    cfg,
    store,
    source,
    engine,
    status,
    should_stop,
    history_size,
    polymarket,
    once=False,
):
    scheduler = (
        MarketScheduler(source, cfg, history_size) if engine is not None else None
    )
    books = {}
    seen = set()
    next_heartbeat = 0
    next_poly = 0
    errors = {}
    next_perf = 0
    perf = {"processed": 0, "refreshed": 0, "data_errors": 0, "last_tick_ms": 0.0}
    market_health = {"completed_ticks": 0, "valid_history_ticks": 0,
                     "market_errors": 0, "last_error": "", "last_symbol": "",
                     "last_completed_utc": None, "last_valid_history_utc": None}

    def heartbeat(force=False):
        nonlocal next_heartbeat
        if force or time.monotonic() >= next_heartbeat:
            status["heartbeat"] = time.time()
            # Durable read-only telemetry: distinguish a live worker from a
            # worker that has never received usable closed-candle history.
            status["market_health"] = dict(market_health)
            status["draining"] = store.read(include_charts=False)["strategy"].get(
                "draining", False
            )
            atomic_json(folder / "process.json", status)
            next_heartbeat = time.monotonic() + 1

    try:
        while not should_stop():
            finish_requested(folder, store)
            if finished(store.read(include_charts=False)):
                break
            if scheduler:
                close_requested_positions(folder, store, books)
                completed = scheduler.collect(store.read(include_charts=False))
                for symbol, tick, error in completed:
                    if should_stop():
                        break
                    seen.add(symbol)
                    tick_start = time.monotonic()
                    try:
                        finish_requested(folder, store)
                        if error:
                            raise error
                        heartbeat()
                        if tick.book is not None and not book_is_fresh(tick.book["at"]):
                            # Refresh a quote that aged in the decision queue.
                            # The original exchange timestamp is never changed.
                            perf["refreshed"] += 1
                            tick.book = source.orderbook(symbol)
                        process_tick(cfg, store, engine, tick)
                        market_health["completed_ticks"] += 1
                        market_health["last_completed_utc"] = time.time()
                        market_health["last_symbol"] = symbol
                        if tick.bars and not tick.history_error:
                            market_health["valid_history_ticks"] += 1
                            market_health["last_valid_history_utc"] = time.time()
                        if tick.book is not None:
                            perf["processed"] += 1
                            books[symbol] = tick.book
                        else:
                            books.pop(symbol, None)
                            if tick.quote_error:
                                raise DataUnavailable(tick.quote_error)
                    except (
                        DataUnavailable,
                        ValueError,
                        KeyError,
                        IndexError,
                        TypeError,
                    ) as exc:
                        perf["data_errors"] += 1
                        market_health["market_errors"] += 1
                        market_health["last_symbol"] = symbol
                        market_health["last_error"] = str(exc)[:500]
                        # Do not reuse even a recently accepted book for a
                        # manual close after a failed market refresh.
                        books.pop(symbol, None)
                        with store.transaction(include_charts=False) as (state, events):
                            state["marks"].pop(symbol, None)
                            state["diagnostics"][symbol] = [
                                {"section": "Данные", "reason": str(exc)}
                            ]
                        old = errors.get(symbol, ("", 0))
                        if old[0] != str(exc) or time.time() - old[1] > 60:
                            logging.warning("%s data: %s", symbol, exc)
                            errors[symbol] = (str(exc), time.time())
                    perf["last_tick_ms"] = round(
                        (time.monotonic() - tick_start) * 1000, 3
                    )
                    heartbeat(force=bool(error or (tick is not None and tick.history_error)))
                close_requested_positions(folder, store, books)
            elif time.monotonic() >= next_poly:
                with store.transaction(include_charts=False) as (state, events):
                    polymarket(
                        cfg,
                        state,
                        events,
                        source,
                        time.time(),
                        lambda: should_stop() or (folder / "finish.request").exists(),
                    )
                    update_equity_metrics(state)
                log_events(events)
                seen.update(cfg["symbols"])
                next_poly = time.monotonic() + 2
            else:
                time.sleep(0.1)
            heartbeat()
            if time.monotonic() >= next_perf:
                shared = getattr(source, "shared", None)
                logging.info(
                    "RUNTIME_PERF %s",
                    json.dumps({**perf, "cache": getattr(shared, "stats", None)}),
                )
                next_perf = time.monotonic() + 30
            if once and seen >= set(cfg["symbols"]):
                break
            if finished(store.read(include_charts=False)):
                break
    finally:
        if scheduler:
            scheduler.close()
