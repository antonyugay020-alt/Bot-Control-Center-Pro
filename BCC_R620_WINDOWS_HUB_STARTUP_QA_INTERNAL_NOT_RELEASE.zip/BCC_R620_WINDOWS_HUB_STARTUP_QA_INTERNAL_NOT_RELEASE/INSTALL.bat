@echo off
setlocal
cd /d "%~dp0"
rem Production runtime is private to this installation; do not modify global Python.
py -3 -m venv "%~dp0.venv"
if errorlevel 1 goto failed
"%~dp0.venv\Scripts\python.exe" -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 goto failed
"%~dp0.venv\Scripts\python.exe" -c "import PySide6, requests, psutil"
if errorlevel 1 goto failed
echo Bot Control Center Pro: dependencies installed successfully.
pause
exit /b 0
:failed
echo [ERROR] Installation failed. Verify Python 3, Internet access and pip output.
echo Existing MY_BOTS data was not changed.
pause
exit /b 1
