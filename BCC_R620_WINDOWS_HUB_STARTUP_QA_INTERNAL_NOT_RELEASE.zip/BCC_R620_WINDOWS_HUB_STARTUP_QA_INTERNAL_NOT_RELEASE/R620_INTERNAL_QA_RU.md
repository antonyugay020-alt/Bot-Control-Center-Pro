# R6.20 — Windows Hub startup audit (INTERNAL, NOT RELEASE)

Native report `BCC_VALIDATION_RESULTS_20261102_133858_963817.zip` actually checked R6.18 (source integrity 206 files), not R6.19. Native result: 918 tests, 902 PASS, 11 FAIL, 5 platform-specific skips. Nine failures arose at `Market Data Hub did not become ready`; the report did NOT contain the hub child process log, so the underlying Windows startup cause cannot be established from the archive. Two remaining tests timed out on the blocking modal error of R6.18, a separate issue corrected in R6.19.

R6.20 applies a single source change set to mitigate avoidable SQLite startup contention: the supervisor uses one registry instance while polling; the registry avoids requesting journal-mode changes if WAL is already enabled; the producer cannot inherit a worker's client environment. Cold Windows startup remains bounded, with a separate timer from lock acquisition. Hub subprocess startup diagnostics are copied into the Windows QA report on test failure and included in a bounded `HubUnavailable` message. Neither a timeout nor an unknown leader is treated as success.

The original Windows failure must be rechecked on real Windows. Python tests on Linux do not establish native Qt acceptance or fresh public data validation. LIVE remains disabled; do not operate with real funds.

## QA performed in this turn

- R6.20 Linux headless: 867 collected, 867 unique JUnit testcase records, four complete independent groups, 0 failed/error/skipped.
- `tests/test_r620_windows_hub_startup.py` added failure-path, WAL, environment-isolation and bounded-log tests.
- Native Windows R6.20 Qt and market checks: **NOT RUN**. Previous R6.18 native Hub cause is unproven because its report did not include child startup logs.
- Windows R6.18 had 5 explicit platform-only skips; not five Qt failures.
- Real-money trading is NOT authorized.
