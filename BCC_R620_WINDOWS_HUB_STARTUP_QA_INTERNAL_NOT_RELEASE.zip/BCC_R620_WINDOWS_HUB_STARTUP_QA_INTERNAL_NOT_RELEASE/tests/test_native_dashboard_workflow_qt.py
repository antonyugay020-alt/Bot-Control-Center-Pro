"""Native GUI -> controller -> independent PAPER worker -> monitor -> Stop/Restart.

Only the public transport is replayed. The actual Qt widgets, controller's
stop path, worker engine, SQLite ledger and monitor are exercised. This is not
proof of live-market operation or an independent Windows GUI acceptance run.
"""
import os

if os.name != 'nt' and not os.environ.get('DISPLAY'):
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

import pytest
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QMessageBox, QPushButton

from bcc.ui import MainWindow, apply_style
from bcc.storage import Store
from test_process import RUNNER, launch, setup_bot, wait_for


def click_action(app, win, caption):
    matches = [b for b in win.findChildren(QPushButton)
               if b.text() == caption and b.isVisible() and b.isEnabled()]
    assert len(matches) == 1, f'Expected one visible {caption!r} button, got {len(matches)}'
    QTest.mouseClick(matches[0], Qt.MouseButton.LeftButton)
    app.processEvents()


def test_dashboard_buttons_drive_real_paper_worker_monitor_and_restart(tmp_path, monkeypatch):
    app = QApplication.instance() or QApplication([])
    apply_style(app, {'scale': 100, 'theme': 'dark'})
    # Surface internal GUI errors immediately instead of hanging in a modal.
    def unexpected_warning(*args, **kwargs):
        pytest.fail('Dashboard displayed an unexpected warning: ' + repr(args[2:]))
    monkeypatch.setattr(QMessageBox, 'warning', unexpected_warning)
    win = MainWindow(tmp_path / 'isolated_qa_workspace')
    runner = tmp_path / 'controlled_public_data_worker.py'
    runner.write_text(RUNNER, encoding='utf-8')
    folder, _ = setup_bot(win.repo, runner, 'Native Dashboard PAPER cycle')
    # Only startup transport is redirected to an independently running replay
    # worker. Stop, process identity, state and GUI are the production paths.
    children = []
    def start_with_replayed_public_feed(actual_folder):
        assert actual_folder == folder
        child = launch(win.life, folder, runner)
        children.append(child)
        return child.pid
    monkeypatch.setattr(win.life, 'start', start_with_replayed_public_feed)
    try:
        win.show()
        win.current = folder
        win.refresh()
        app.processEvents()
        assert win.selected() == folder
        assert win.bots_table.rowCount() == 1
        click_action(app, win, '▶ Запуск')
        assert len(children) == 1 and children[0].poll() is None
        wait_for(lambda: Store(folder).read()['positions'], seconds=20)
        win.refresh()
        assert win.positions.rowCount() == 1
        assert len(Store(folder).history()) == 1
        # Filtering the dashboard must not hide running bots in the global monitor.
        win.search.setText('definitely-no-match')
        click_action(app, win, 'Монитор всех ботов')
        monitor = win.running_monitor
        monitor.refresh()
        assert monitor.isVisible()
        assert any(r['path'] == str(folder) and r['status'] in ('Работает', 'Запуск')
                   for r in monitor.records)
        assert monitor.positions.rowCount() == 1
        monitor.close()
        win.search.clear()
        win.current = folder
        win.refresh()
        click_action(app, win, '■ Стоп')
        children[-1].wait(timeout=12)
        assert win.life.status(folder) == 'Остановлен'
        before = Store(folder).read()
        before_history = Store(folder).history()
        assert len(before['positions']) == len(before_history) == 1
        click_action(app, win, '▶ Запуск')
        assert len(children) == 2 and children[-1].poll() is None
        wait_for(lambda: win.life.active_snapshot(folder), seconds=20)
        assert len(Store(folder).history()) == len(before_history), 'Duplicate entry on restart'
        click_action(app, win, '■ Стоп')
        children[-1].wait(timeout=12)
        state = Store(folder).read()
        assert state['positions'] == before['positions']
        assert state['cash'] == before['cash']
        Store(folder).audit()
        win.refresh()
        assert win.positions.rowCount() == 1, 'Stop must preserve existing PAPER position'
        assert win.history.rowCount() == 1
    finally:
        if win.running_monitor is not None:
            win.running_monitor.close()
        for child in children:
            if child.poll() is None:
                # Owned test subprocess only, never a user bot.
                try:
                    win.life.stop(folder, force=True)
                    child.wait(timeout=7)
                except Exception:
                    child.kill()
                    child.wait(timeout=7)
        win.close()
        win.deleteLater()
        app.processEvents()
