"""Native Windows Qt check of actual indicator-filter controls (no mock UI)."""
import os
if os.name != 'nt' and not os.environ.get('DISPLAY'):
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

import pytest
from PySide6.QtWidgets import QApplication
from bcc.config import defaults, validate
from bcc.wizard import BotWizard


@pytest.fixture(scope='module')
def app():
    return QApplication.instance() or QApplication([])


def test_filter_turned_on_saved_reopened_and_disabled(app):
    cfg = defaults('POLYMARKET')
    cfg['name'] = 'Composite widget test'
    w = BotWizard(cfg)
    w.steps.setCurrentRow(2)
    assert w.poly_indicator_enabled.isChecked() is False
    assert w.data()['polymarket']['indicator_filter'] is None
    w.poly_indicator_enabled.setChecked(True)
    assert w.poly_indicator_editor.isEnabled()
    value = validate(w.data())
    assert value['polymarket']['indicator_filter']['conditions'][0]['indicator'] == 'RSI'
    w.close()
    reopened = BotWizard(value)
    assert reopened.poly_indicator_enabled.isChecked()
    assert reopened.data()['polymarket']['indicator_filter'] == value['polymarket']['indicator_filter']
    reopened.poly_indicator_enabled.setChecked(False)
    assert validate(reopened.data())['polymarket']['indicator_filter'] is None
    reopened.close()
