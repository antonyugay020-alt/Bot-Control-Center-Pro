"""Fail-closed verification of the exact source snapshot before native QA.

The manifest intentionally excludes itself to avoid circular hashes. Generated
venvs, logs and test workspaces are not part of the verified source snapshot.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
SHA256 = re.compile(r"^[0-9a-f]{64}$")

# Every entry point and every core trading/storage subsystem must be sealed.
# Requiring only the checker itself can falsely pass a package from which a
# launcher or an essential engine module was removed along with its manifest row.
REQUIRED_FILES = (
    "app.py", "launch.pyw", "BUILD_INFO.json", "requirements.txt",
    "requirements-dev.txt", "START.bat", "INSTALL.bat",
    "VALIDATE_WINDOWS.bat", "CHECK_WINDOWS.bat",
    "tools/start_windows_check.ps1", "tools/windows_check.py",
    "tools/verify_windows.py", "tools/verify_package.py",
    "tools/process_guard.py", "tools/qa_budgets.py", "tools/repeat_full_qa.py",
    "tools/collect_test_inventory.py",
    "bcc/__init__.py", "bcc/storage.py", "bcc/runtime.py",
    "bcc/trading.py", "bcc/worker.py", "bcc/market.py",
    "bcc/config.py", "bcc/transfer.py", "bcc/lifecycle.py",
    "bcc/ui.py", "bcc/gui_check.py", "bcc/health.py",
)



class SourceIntegrityError(ValueError):
    pass


def verify(root=ROOT):
    root = Path(root).resolve()
    manifest_path = root / "SHA256_MANIFEST.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, ValueError, UnicodeError) as exc:
        raise SourceIntegrityError("Невозможно прочитать SHA256_MANIFEST.json") from exc
    files = manifest.get("files") if isinstance(manifest, dict) else None
    if not isinstance(files, dict) or len(files) < 30:
        raise SourceIntegrityError("Пустой или повреждённый манифест исходников")
    checked = set()
    for key, digest in files.items():
        if not isinstance(key, str) or not isinstance(digest, str) or not SHA256.fullmatch(digest):
            raise SourceIntegrityError("Некорректная строка манифеста")
        rel = PurePosixPath(key)
        if rel.is_absolute() or ".." in rel.parts or "\\" in key or key != rel.as_posix():
            raise SourceIntegrityError("Недопустимый путь манифеста")
        path = root.joinpath(*rel.parts)
        if path.is_symlink() or not path.is_file():
            raise SourceIntegrityError("Отсутствует файл или обнаружена ссылка: " + key)
        # Checking only resolve().is_relative_to(root) is insufficient: a
        # symlinked parent could redirect to another file INSIDE the package
        # and silently change an executable after verification.
        if any(parent.is_symlink() for parent in (path, *path.parents) if parent != root
               and parent.is_relative_to(root)):
            raise SourceIntegrityError("Ссылка в пути исходника: " + key)
        if not path.resolve().is_relative_to(root):
            raise SourceIntegrityError("Файл выходит за корень пакета: " + key)
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != digest:
            raise SourceIntegrityError("Не совпадает SHA-256: " + key)
        checked.add(key)
    # Every executable Python source is part of the sealed snapshot. Log files,
    # generated check workspaces and dependencies are intentionally excluded.
    for folder in ("bcc", "tests", "tools"):
        for path in (root / folder).rglob("*.py"):
            if any(part.startswith(".") or part in {"__pycache__", "check_workspaces"}
                   for part in path.relative_to(root).parts):
                continue
            if path.relative_to(root).as_posix() not in checked:
                raise SourceIntegrityError("Незарегистрированный модуль: " + str(path.relative_to(root)))
    for required in REQUIRED_FILES:
        if required not in checked:
            raise SourceIntegrityError("Неучтён обязательный файл: " + required)
    return {"status": "PASS", "verified_files": len(checked), "checkpoint": manifest.get("checkpoint")}


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    args = parser.parse_args(argv)
    try:
        result = verify(args.root)
    except SourceIntegrityError as exc:
        print("SOURCE INTEGRITY FAIL:", exc, flush=True)
        return 1
    print("SOURCE INTEGRITY PASS:", result, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
