"""Explicit experimental public-data producer. Does not trade or load keys."""
import argparse
import os
import sys
import traceback
import signal
import threading
import time
from bcc.market_hub import MarketDataHub


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--cache', required=True)
    p.add_argument('--poll', type=float, default=.1)
    p.add_argument('--idle-exit', type=float, default=90.0,
                   help='Exit after this many seconds without active clients; 0 disables')
    args = p.parse_args()
    if not 0 <= args.idle_exit <= 86400:
        p.error('--idle-exit must be 0..86400 seconds')
    if not .02 <= args.poll <= 5:
        p.error('--poll must be 0.02..5 seconds')
    stop = threading.Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, lambda *_: stop.set())
        except (OSError, ValueError):
            pass
    # Startup telemetry belongs to this public-data worker's dedicated
    # market_hub.log. No credentials or market payloads are logged.
    print(f'Market Hub starting: pid={os.getpid()} '
          f'python={sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}',
          flush=True)
    hub = MarketDataHub(args.cache)
    print('Market Hub cache initialized', flush=True)
    last_client = time.monotonic()
    ready_logged = False
    try:
        while not stop.is_set():
            hub.run_once()
            if not ready_logged:
                with hub.registry._connect() as db:
                    owned = db.execute(
                        'SELECT owner FROM hub_leader WHERE singleton=1'
                    ).fetchone()
                if owned and owned[0] == hub.owner:
                    print('Market Hub leader lease acquired', flush=True)
                    ready_logged = True
            # Do not couple the producer to the Qt shell lifetime: active
            # PAPER workers keep their leases renewed without the GUI.
            # Retire abandoned services after all subscriptions expire.
            if args.idle_exit:
                if hub.registry.has_active_subscriptions():
                    last_client = time.monotonic()
                elif time.monotonic() - last_client >= args.idle_exit:
                    break
            stop.wait(args.poll)
    except BaseException:
        traceback.print_exc()
        raise
    finally:
        hub.close()


if __name__ == '__main__':
    main()
