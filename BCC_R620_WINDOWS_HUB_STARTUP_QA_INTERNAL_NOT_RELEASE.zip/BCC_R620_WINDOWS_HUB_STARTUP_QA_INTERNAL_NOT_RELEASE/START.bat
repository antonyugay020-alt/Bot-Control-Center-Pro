@echo off
setlocal
cd /d "%~dp0"
rem Use the private production environment installed by INSTALL.bat.
if exist "%~dp0.venv\Scripts\python.exe" (
    "%~dp0.venv\Scripts\python.exe" -c "import PySide6, requests, psutil" >nul 2>&1
    if errorlevel 1 goto dependencies
    if not exist "%~dp0.venv\Scripts\pythonw.exe" goto dependencies
    start "" "%~dp0.venv\Scripts\pythonw.exe" "%~dp0launch.pyw"
    exit /b 0
)
rem Compatibility with existing verified Windows QA installations.
if exist "%~dp0.check_venv\Scripts\python.exe" (
    "%~dp0.check_venv\Scripts\python.exe" -c "import PySide6, requests, psutil" >nul 2>&1
    if not errorlevel 1 (
        if exist "%~dp0.check_venv\Scripts\pythonw.exe" (
            start "" "%~dp0.check_venv\Scripts\pythonw.exe" "%~dp0launch.pyw"
            exit /b 0
        )
    )
)
rem Legacy global installation: check before starting a consoleless process.
py -3 -c "import PySide6, requests, psutil" >nul 2>&1
if errorlevel 1 goto dependencies
where pyw >nul 2>&1
if errorlevel 1 goto dependencies
start "" pyw -3 "%~dp0launch.pyw"
exit /b 0
:dependencies
echo [ERROR] Bot Control Center Pro cannot start: Python or Qt dependencies are missing.
echo Run INSTALL.bat in this folder, then START.bat again.
echo Existing MY_BOTS accounts have not been reset.
pause
exit /b 1
