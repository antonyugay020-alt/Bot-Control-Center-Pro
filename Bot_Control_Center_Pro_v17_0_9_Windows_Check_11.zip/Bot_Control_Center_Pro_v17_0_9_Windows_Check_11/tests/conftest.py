"""Retain bounded process evidence for the single Windows validation report."""

import hashlib
import json
import os
from pathlib import Path

import pytest


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    destination = os.environ.get("BCC_TEST_ARTIFACTS")
    temp = item.funcargs.get("tmp_path")
    if report.when != "call" or not destination or temp is None:
        return
    names = {
        "test_launch.json",
        "test-console.log",
        "engine.log",
        "console.log",
        "process.json",
    }
    files = [
        p
        for p in Path(temp).rglob("*")
        if p.is_file() and not p.is_symlink() and p.name in names
    ]
    if not files:
        return
    target = Path(destination) / hashlib.sha256(item.nodeid.encode()).hexdigest()[:16]
    target.mkdir(parents=True, exist_ok=True)
    metadata = {"test": item.nodeid, "outcome": report.outcome, "errors": []}
    for source in files:
        try:
            path = target / source.relative_to(temp)
            path.parent.mkdir(parents=True, exist_ok=True)
            with source.open("rb") as stream:
                stream.seek(max(0, source.stat().st_size - 1_000_000))
                path.write_bytes(stream.read())
        except OSError as exc:
            metadata["errors"].append(str(exc))
    (target / "test.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
