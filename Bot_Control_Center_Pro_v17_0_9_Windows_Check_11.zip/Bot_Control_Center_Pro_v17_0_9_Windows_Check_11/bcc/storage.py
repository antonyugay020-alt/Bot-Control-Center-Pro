"""Durable bot storage. Trading state and executions share one SQLite commit."""

import hashlib
import json
import math
import os
import sqlite3
import tempfile
import time
import uuid
from contextlib import contextmanager
from pathlib import Path

from .config import reject_private_data, validate


def json_bytes(value):
    return json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False).encode(
        "utf-8"
    )


def load_json(path):
    return json.loads(
        Path(path).read_text(encoding="utf-8-sig"),
        parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)),
    )


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".pending-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(json_bytes(value))
            f.flush()
            os.fsync(f.fileno())
        for attempt in range(20):
            try:
                os.replace(name, path)
                break
            except PermissionError:
                if attempt == 19:
                    raise
                time.sleep(0.05)
    finally:
        Path(name).unlink(missing_ok=True)


class BotBusy(RuntimeError):
    pass


class AccountingError(RuntimeError):
    """A broken persisted ledger or invariant stops the worker immediately."""


class BotLock:
    """OS releases the exclusive lease after normal exit, crash, or force stop."""

    def __init__(self, folder):
        self.path = Path(folder) / "engine.lock"
        self.handle = None

    def __enter__(self):
        self.handle = self.path.open("a+b")
        self.handle.seek(0)
        if self.path.stat().st_size == 0:
            self.handle.write(b"0")
            self.handle.flush()
            self.handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, IOError) as e:
            self.handle.close()
            self.handle = None
            raise BotBusy("Бот работает или выполняется другая операция") from e
        return self

    def __exit__(self, *args):
        if self.handle:
            if os.name == "nt":
                import msvcrt

                self.handle.seek(0)
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
            self.handle.close()
            self.handle = None


def initial_state(capital):
    return dict(
        initial=capital,
        cash=capital,
        realized=0.0,
        positions={},
        pending={},
        clocks={},
        marks={},
        diagnostics={},
        stats={},
        done={},
        daily={},
        strategy={},
        created=time.time(),
    )


class Store:
    def __init__(self, folder, capital=None):
        self.path = Path(folder) / "paper.sqlite"
        if capital is not None:
            with self.connect() as db:
                db.executescript(
                    "CREATE TABLE IF NOT EXISTS state(id INTEGER PRIMARY KEY CHECK(id=1), document TEXT NOT NULL); CREATE TABLE IF NOT EXISTS executions(id TEXT PRIMARY KEY, at REAL NOT NULL, symbol TEXT NOT NULL, section TEXT NOT NULL, action TEXT NOT NULL, data TEXT NOT NULL);"
                )
                if db.execute("SELECT 1 FROM state").fetchone() is None:
                    db.execute(
                        "INSERT INTO state VALUES(1,?)",
                        (json_bytes(initial_state(capital)).decode(),),
                    )

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        try:
            db.execute("PRAGMA busy_timeout=10000")
            db.execute("PRAGMA synchronous=FULL")
            yield db
        finally:
            db.close()

    def read(self, include_charts=True):
        with self.connect() as db:
            row = db.execute("SELECT document FROM state WHERE id=1").fetchone()
            if not row:
                raise RuntimeError("Отсутствует сохранённое PAPER-состояние")
            state = json.loads(row[0])
            separate = state.pop("_chart_table", False)
            if separate:
                state["charts"] = (
                    {
                        symbol: json.loads(data)
                        for symbol, data in db.execute(
                            "SELECT symbol,document FROM charts"
                        )
                    }
                    if include_charts
                    else {}
                )
            elif not include_charts:
                self.validate_state(
                    state
                )  # Legacy chart data is validated before migration.
                state["charts"] = {}
            self.validate_state(state)
            return state

    def chart_symbols(self):
        with self.connect() as db:
            state = json.loads(
                db.execute("SELECT document FROM state WHERE id=1").fetchone()[0]
            )
            if not state.get("_chart_table"):
                return list(state.get("charts", {}))
            return [
                r[0] for r in db.execute("SELECT symbol FROM charts ORDER BY symbol")
            ]

    def chart(self, symbol):
        with self.connect() as db:
            state = json.loads(
                db.execute("SELECT document FROM state WHERE id=1").fetchone()[0]
            )
            if state.get("_chart_table"):
                row = db.execute(
                    "SELECT document FROM charts WHERE symbol=?", (symbol,)
                ).fetchone()
                bars = json.loads(row[0]) if row else []
            else:
                bars = state.get("charts", {}).get(symbol, [])
            # A chart is public data, but imported values must still be finite
            # and free of private fields before rendering.
            check = initial_state(0)
            check["charts"] = {symbol: bars}
            self.validate_state(check)
            return bars

    @staticmethod
    def validate_state(state):
        try:
            reject_private_data(state)
        except ValueError as e:
            raise AccountingError(str(e)) from e
        if not isinstance(state, dict) or not isinstance(state.get("positions"), dict):
            raise AccountingError("Повреждена структура PAPER-счёта")
        for key in ("initial", "cash", "realized"):
            if type(state.get(key)) not in (int, float) or not math.isfinite(
                state[key]
            ):
                raise AccountingError("Повреждён PAPER-баланс")
        for key, p in state["positions"].items():
            if not isinstance(p, dict):
                raise AccountingError("Повреждена PAPER-позиция")
            sides = (
                ("UP", "DOWN") if p.get("kind") == "POLYMARKET" else ("LONG", "SHORT")
            )
            if p.get("side") not in sides:
                raise AccountingError("Повреждено направление PAPER-позиции")
            for field in ("qty", "average", "margin", "order_margin"):
                if field == "order_margin" and field not in p:
                    continue
                value = p.get(field)
                if (
                    type(value) not in (int, float)
                    or not math.isfinite(value)
                    or (value <= 0 if field in ("qty", "average") else value < 0)
                ):
                    raise AccountingError("Повреждена позиция: " + field)

        def finite(node, depth=0):
            if depth > 40:
                raise AccountingError("Повреждена вложенность PAPER-состояния")
            if isinstance(node, float) and not math.isfinite(node):
                raise AccountingError("Неконечное число в PAPER-состоянии")
            if isinstance(node, dict):
                for v in node.values():
                    finite(v, depth + 1)
            elif isinstance(node, list):
                for v in node:
                    finite(v, depth + 1)

        finite(state)

    def audit(self):
        state = self.read()
        with self.connect() as db:
            events = [
                json.loads(row[0]) for row in db.execute("SELECT data FROM executions")
            ]
            delta = sum(e["cash_delta"] for e in events)
            realized = sum(e.get("net_pnl", 0) for e in events)
        if not math.isclose(
            state["initial"] + delta, state["cash"], rel_tol=1e-10, abs_tol=1e-7
        ):
            raise AccountingError(
                "Баланс не согласуется с журналом исполнений; запуск заблокирован"
            )
        if not math.isclose(realized, state["realized"], rel_tol=1e-10, abs_tol=1e-7):
            raise AccountingError("Результат не согласуется с журналом исполнений")

    @contextmanager
    def transaction(self, include_charts=True):
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                state = json.loads(
                    db.execute("SELECT document FROM state WHERE id=1").fetchone()[0]
                )
                separate = state.pop("_chart_table", False)
                legacy_charts = state.pop("charts", {})
                if not separate and legacy_charts:
                    check = initial_state(0)
                    check["charts"] = legacy_charts
                    self.validate_state(check)
                if separate and include_charts:
                    state["charts"] = {
                        symbol: json.loads(data)
                        for symbol, data in db.execute(
                            "SELECT symbol,document FROM charts"
                        )
                    }
                else:
                    state["charts"] = legacy_charts if include_charts else {}
                self.validate_state(state)
                before_cash = state["cash"]
                before_realized = state["realized"]
                events = []
                yield state, events
                # Reject non-finite accounting; never reset a damaged ledger.
                self.validate_state(state)
                if not math.isclose(
                    before_cash + sum(e.get("cash_delta", 0) for e in events),
                    state["cash"],
                    rel_tol=1e-10,
                    abs_tol=1e-7,
                ):
                    raise AccountingError(
                        "Денежное изменение без соответствующего исполнения"
                    )
                if state["realized"] != before_realized:
                    raise AccountingError(
                        "Результат изменён в обход журнала исполнений"
                    )
                state["realized"] = before_realized + sum(
                    e.get("net_pnl", 0) for e in events
                )
                self.validate_state(state)
                db.execute(
                    "CREATE TABLE IF NOT EXISTS charts(symbol TEXT PRIMARY KEY,document TEXT NOT NULL)"
                )
                charts = state.get("charts", {})
                if include_charts:
                    db.execute("DELETE FROM charts")
                elif not separate:
                    # Upgrade an old account in the same atomic commit. Legacy
                    # chart history is preserved, while new deltas take priority.
                    charts = {**legacy_charts, **charts}
                for symbol, bars in charts.items():
                    encoded = json.dumps(
                        bars, ensure_ascii=False, allow_nan=False, separators=(",", ":")
                    )
                    db.execute(
                        "INSERT OR REPLACE INTO charts VALUES(?,?)", (symbol, encoded)
                    )
                document = {k: v for k, v in state.items() if k != "charts"}
                document["_chart_table"] = 1
                data = json.dumps(
                    document, ensure_ascii=False, allow_nan=False, separators=(",", ":")
                )
                for event in events:
                    db.execute(
                        "INSERT INTO executions VALUES(?,?,?,?,?,?)",
                        (
                            event["id"],
                            event["at"],
                            event["symbol"],
                            event["section"],
                            event["action"],
                            json_bytes(event).decode(),
                        ),
                    )
                db.execute("UPDATE state SET document=? WHERE id=1", (data,))
                db.commit()
            except BaseException:
                db.rollback()
                raise

    def history(self, limit=500):
        with self.connect() as db:
            return [
                json.loads(row[0])
                for row in db.execute(
                    "SELECT data FROM executions ORDER BY rowid DESC LIMIT ?", (limit,)
                )
            ]

    def backup(self, destination):
        with self.connect() as source:
            target = sqlite3.connect(destination)
            try:
                source.backup(target)
            finally:
                target.close()


class Repository:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.bots = self.root / "MY_BOTS"
        self.bots.mkdir(parents=True, exist_ok=True)

    def resolve(self, folder):
        lexical = Path(os.path.abspath(folder))
        path = lexical.resolve(strict=True)
        if lexical != path or not path.is_relative_to(self.bots) or path == self.bots:
            raise ValueError("Папка бота за пределами MY_BOTS")
        if any(p.is_symlink() for p in path.rglob("*")):
            raise ValueError("Ссылки в папке бота запрещены")
        return path

    def list(self):
        results = []
        for file in sorted(self.bots.glob("*/*/config.json")):
            try:
                folder = self.resolve(file.parent)
                cfg = validate(load_json(file))
                results.append((folder, cfg))
            except (ValueError, OSError, KeyError, TypeError) as e:
                results.append(
                    (
                        file.parent,
                        {
                            "name": file.parent.name,
                            "strategy": file.parent.parent.name,
                            "invalid": str(e),
                        },
                    )
                )
        return results

    def create(self, cfg):
        cfg = validate(cfg)
        strategy = cfg["strategy"]
        folder = self.bots / strategy / uuid.uuid4().hex[:12]
        folder.parent.mkdir(exist_ok=True)
        staging = Path(tempfile.mkdtemp(prefix=".creating-", dir=folder.parent))
        try:
            atomic_json(staging / "config.json", cfg)
            # A bot's engine entry point travels with its configuration.
            (staging / "engine.py").write_text(
                "from bcc.worker import main\nif __name__ == '__main__': main()\n",
                encoding="utf-8",
            )
            staging.rename(folder)
        finally:
            if staging.exists():
                import shutil

                shutil.rmtree(staging)
        return folder

    def load(self, folder):
        folder = self.resolve(folder)
        raw = (folder / "config.json").read_bytes()
        return validate(json.loads(raw)), hashlib.sha256(raw).hexdigest()

    def save(self, folder, cfg, expected):
        folder = self.resolve(folder)
        cfg = validate(cfg)
        with BotLock(folder):
            old, digest = self.load(folder)
            if digest != expected:
                raise RuntimeError("Настройки изменились; откройте редактор повторно")
            if cfg["strategy"] != old["strategy"]:
                raise ValueError("Стратегия существующего бота не меняется")
            if (folder / "paper.sqlite").exists():
                state = Store(folder).read()
                if cfg["capital"] != old["capital"]:
                    raise ValueError(
                        "У действующего PAPER-счёта депозит сохраняется; создайте копию для нового депозита"
                    )
                live = {
                    f"{s}:{sec['id']}"
                    for s in cfg["symbols"]
                    for sec in cfg["sections"]
                }
                for key, p in {**state["positions"], **state["pending"]}.items():
                    if (
                        p["symbol"] not in cfg["symbols"]
                        or cfg["strategy"]
                        in ("VELES", "EMA", "MACD", "BOLLINGER", "EMA_RSI_VOLUME")
                        and key not in live
                    ):
                        raise ValueError(
                            "Открытая позиция или ожидающая сетка требует сохранения монеты и секции"
                        )
            atomic_json(folder / "config.json", cfg)

    def copy(self, folder, *, history=False, name=None):
        import shutil

        folder = self.resolve(folder)
        with BotLock(folder):
            cfg, _ = self.load(folder)
            suffix = " — копия"
            cfg["name"] = (
                name if name is not None else cfg["name"][: 80 - len(suffix)] + suffix
            )
            target = self.create(cfg)
            try:
                if history and (folder / "paper.sqlite").exists():
                    Store(folder).audit()
                    Store(folder).backup(target / "paper.sqlite")
                if history:
                    for name in ("engine.log", "console.log"):
                        if (folder / name).is_file():
                            shutil.copy2(folder / name, target / name)
            except BaseException:
                shutil.rmtree(target)
                raise
            return target

    def delete(self, folder):
        import shutil

        folder = self.resolve(folder)
        # Rename under the lease so another launcher cannot acquire the old path.
        # Windows permits the rename only after closing engine.lock.
        with BotLock(folder):
            if (folder / "paper.sqlite").exists() and Store(folder).read()["positions"]:
                raise ValueError(
                    "Сначала закройте PAPER-позиции; удаление потеряет их историю"
                )
        tomb = folder.with_name(".deleted-" + uuid.uuid4().hex)
        folder.rename(tomb)
        try:
            with BotLock(tomb):
                pass
        except BotBusy:
            tomb.rename(folder)
            raise
        shutil.rmtree(tomb)
