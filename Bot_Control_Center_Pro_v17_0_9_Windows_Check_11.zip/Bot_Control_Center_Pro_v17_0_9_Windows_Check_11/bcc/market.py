"""Read-only public market transport. Only GET endpoints are available."""

import json
import logging
import math
import os
import re
import threading
import time
from datetime import datetime, timezone
from urllib.parse import urlparse

import requests

from .data_cache import CacheBusy
from .market_clock import book_is_fresh, clock, market_now, observed_quote, utc_bounds


class DataUnavailable(RuntimeError):
    pass


def check_book_time(stamp, source, details=None):
    now = time.time()
    low, high = utc_bounds()
    age = low - stamp
    if not book_is_fresh(stamp):
        hint = (
            "Снимок опережает сверенное UTC; PAPER-исполнение отложено"
            if age < -0.5
            else "Снимок старше допуска; ожидается свежий снимок источника"
        )
        raise DataUnavailable(
            f"Устаревший стакан {source}: возраст=[{age:+.3f}, {high - stamp:+.3f}] с; допуск=[-0.500, +3.000] с; локальное UTC={now:.3f}; время стакана UTC={stamp:.3f}; сверенное UTC=[{low:.3f}, {high:.3f}]. {hint}"
            + (
                "; получение=" + json.dumps(details, ensure_ascii=False)
                if details
                else ""
            )
        )


class PublicData:
    HOSTS = {
        "api.bybit.com",
        "gamma-api.polymarket.com",
        "clob.polymarket.com",
        "data-api.polymarket.com",
        "api.binance.com",
    }

    def __init__(self):
        self._thread = threading.local()
        self._sessions = []
        self._lock = threading.RLock()
        self.stop_event = threading.Event()
        self.cooldowns = {}
        self.cache = {}
        self.shared = None
        self._cache_warning_at = -math.inf
        path = os.environ.get("BCC_PUBLIC_CACHE")
        if path:
            from .data_cache import PublicCache

            self.shared = PublicCache(path)

    @property
    def session(self):
        if not hasattr(self._thread, "session"):
            self._thread.session = requests.Session()
            with self._lock:
                self._sessions.append(self._thread.session)
        return self._thread.session

    def close(self):
        self.stop_event.set()
        for session in self._sessions:
            session.close()
        if self.shared:
            self.shared.close()

    def _finish_shared(self, *args, **kwargs):
        try:
            self.shared.finish(*args, **kwargs)
        except CacheBusy as exc:
            # The request already owns a committed budget reservation. A failure
            # to cache its result does not invalidate the actual HTTP response.
            # A lease we could not release expires normally; no new request may
            # bypass begin(), the host budget, or a provider cooldown.
            with self._lock:
                if time.monotonic() >= self._cache_warning_at:
                    logging.warning("PUBLIC_CACHE: %s", exc)
                    self._cache_warning_at = time.monotonic() + 30

    def get(self, url, params=None, ttl=0):
        began = time.monotonic()

        def received(data, via):
            self._thread.last_read = dict(
                url=url,
                via=via,
                elapsed_seconds=time.monotonic() - began,
                received_pc=time.time(),
            )
            return data

        if self.stop_event.is_set():
            raise DataUnavailable("Получение данных остановлено")
        host = urlparse(url).hostname
        if host not in self.HOSTS or urlparse(url).scheme != "https":
            raise ValueError("Непубличный источник")
        now = time.time()
        key = (url, json.dumps(params, sort_keys=True))
        if now < self.cooldowns.get(host, 0):
            raise DataUnavailable("Источник временно ограничил запросы: " + host)
        with self._lock:
            if ttl > 0 and key in self.cache and 0 <= now - self.cache[key][0] <= ttl:
                return received(self.cache[key][1], "memory_cache")
        owner = None
        shared_key = None
        if self.shared:
            try:
                shared_key, owner, cached = self.shared.begin(url, params, host)
            except CacheBusy as e:
                raise DataUnavailable(str(e)) from e
            if owner is None:
                return received(cached, "shared_cache")
        try:
            response = self.session.get(url, params=params, timeout=(3, 8))
            if response.status_code in (403, 418, 429):
                try:
                    delay = max(
                        90, min(3600, float(response.headers.get("Retry-After", 90)))
                    )
                except ValueError:
                    delay = 90
                self.cooldowns[host] = now + delay
            response.raise_for_status()
            try:
                data = response.json()
            except ValueError as e:
                raise ValueError(
                    f"Источник вернул не JSON (HTTP {response.status_code}, "
                    + response.headers.get("Content-Type", "неизвестный формат")
                    + ")"
                ) from e
        except (requests.RequestException, ValueError) as e:
            delay = max(10, self.cooldowns.get(host, now) - now)
            self.cooldowns[host] = max(self.cooldowns.get(host, 0), time.time() + delay)
            if self.shared:
                self._finish_shared(shared_key, owner, host, cooldown=delay)
            raise DataUnavailable(f"{host}: {e}") from e
        if self.shared:
            cache_ttl = ttl or (
                0.35
                if "orderbook" in url or "/book" in url
                else 1
                if "kline" in url
                else 60
                if "funding" in url
                else 3600
                if "instruments" in url
                else 0.5
            )
            self._finish_shared(shared_key, owner, host, data, cache_ttl)
        with self._lock:
            self.cache[key] = (now, data)
            if len(self.cache) > 1000:
                self.cache = {
                    k: v
                    for k, v in self.cache.items()
                    if now - v[0] < 600 or k[0] == "bars"
                }
        return received(data, "http")

    def bybit(self, route, params):
        data = self.get(
            "https://api.bybit.com/v5/market/" + route, {"category": "linear", **params}
        )
        if data.get("retCode") != 0:
            raise DataUnavailable("Bybit: " + str(data.get("retMsg")))
        return data

    def quote(self, symbol):
        clock.ensure()
        data = self.bybit("tickers", {"symbol": symbol})
        item = data["result"]["list"][0]
        bid = float(item["bid1Price"])
        ask = float(item["ask1Price"])
        if not all(math.isfinite(x) and x > 0 for x in (bid, ask)) or bid > ask:
            raise DataUnavailable("Невалидная котировка")
        remote = float(data["time"]) / 1000
        if not -5 <= market_now() - remote <= 15:
            raise DataUnavailable("Устаревшая котировка Bybit")
        return bid, ask, remote

    def list_symbols(self):
        from .config import valid_symbol

        cursor = None
        symbols = set()
        for _ in range(30):
            args = {"limit": 1000}
            if cursor:
                args["cursor"] = cursor
            result = self.bybit("instruments-info", args)["result"]
            symbols.update(
                x["symbol"]
                for x in result["list"]
                if x.get("status") == "Trading"
                and x.get("quoteCoin") == "USDT"
                and x.get("contractType") == "LinearPerpetual"
                and valid_symbol(x["symbol"], "VELES")
            )
            next_cursor = result.get("nextPageCursor")
            if not next_cursor:
                break
            if cursor == next_cursor:
                raise DataUnavailable("Не удалось получить полный список пар")
            cursor = next_cursor
        return sorted(symbols)

    def candles(self, symbol, required=500):
        clock.ensure()
        required = max(100, int(required))
        with self._lock:
            previous = self.cache.get(("bars", symbol), (0, []))[1]
        # Re-fetch the unfinished tail; its OHLCV must replace the older sample.
        recent_tail = previous and market_now() * 1000 - previous[-1]["t"] <= 9 * 60000
        count = 10 if len(previous) >= required and recent_tail else required
        found = {b["t"]: b for b in previous}
        end = None
        for _ in range((count + 999) // 1000):
            args = {"symbol": symbol, "interval": "1", "limit": min(1000, count)}
            if end is not None:
                args["end"] = end
            data = self.bybit("kline", args)
            rows = data["result"]["list"]
            if not rows:
                break
            for row in rows:
                found[int(row[0])] = dict(
                    t=int(row[0]),
                    open=float(row[1]),
                    high=float(row[2]),
                    low=float(row[3]),
                    close=float(row[4]),
                    volume=float(row[5]),
                )
            end = min(int(row[0]) for row in rows) - 1
            count -= len(rows)
            if count <= 0:
                break
        bars = [found[t] for t in sorted(found)][-required:]
        if not bars or any(b["t"] - a["t"] != 60000 for a, b in zip(bars, bars[1:])):
            raise DataUnavailable("Разрывы в истории свечей")
        if not 0 <= market_now() - bars[-1]["t"] / 1000 < 120:
            raise DataUnavailable("Устаревшие свечи")
        from .indicators import aggregate

        aggregate(bars, 1, int(market_now() * 1000), "intrabar")
        with self._lock:
            self.cache[("bars", symbol)] = (time.time(), bars)
        return bars

    def orderbook(self, symbol):
        clock.ensure()
        instrument = self.get(
            "https://api.bybit.com/v5/market/instruments-info",
            {"category": "linear", "symbol": symbol},
            ttl=3600,
        )["result"]["list"][0]
        if (
            instrument.get("symbol") != symbol
            or instrument.get("status") != "Trading"
            or instrument.get("contractType") != "LinearPerpetual"
            or instrument.get("quoteCoin") != "USDT"
        ):
            raise DataUnavailable(
                "Метаданные не подтверждают доступный бессрочный USDT-контракт "
                + symbol
            )
        # Metadata may require a separate network round trip on the first read.
        # Fetch the executable snapshot only after that round trip has finished.
        response = self.bybit("orderbook", {"symbol": symbol, "limit": 200})
        data = response["result"]
        if data.get("s") != symbol:
            raise DataUnavailable("Стакан другой монеты")
        lots = instrument["lotSizeFilter"]
        stamp = float(data["ts"]) / 1000
        bids = [[float(p), float(q)] for p, q in data["b"]]
        asks = [[float(p), float(q)] for p, q in data["a"]]
        for levels, descending in ((bids, True), (asks, False)):
            if not levels or any(
                not math.isfinite(p) or not math.isfinite(q) or p <= 0 or q < 0
                for p, q in levels
            ):
                raise DataUnavailable("Повреждён стакан")
            if any(
                (a[0] <= b[0] if descending else a[0] >= b[0])
                for a, b in zip(levels, levels[1:])
            ):
                raise DataUnavailable("Порядок уровней стакана")
        if bids[0][0] > asks[0][0]:
            raise DataUnavailable(
                f"Пересечённый стакан Bybit: bid={bids[0][0]:g}, ask={asks[0][0]:g}"
            )
        transport = getattr(self._thread, "last_read", {})
        response_at = float(response["time"]) / 1000
        check_book_time(
            stamp,
            "Bybit",
            {**transport, "response_minus_book_seconds": response_at - stamp},
        )
        result = dict(
            bids=bids,
            asks=asks,
            at=stamp,
            qty_step=float(lots["qtyStep"]),
            min_qty=float(lots["minOrderQty"]),
            min_notional=float(lots.get("minNotionalValue", 5)),
            tick_size=float(instrument["priceFilter"]["tickSize"]),
            max_qty=float(lots["maxMktOrderQty"]),
            response_at=response_at,
            transport=transport,
            engine_at=float(data["cts"]) / 1000
            if data.get("cts") is not None
            else None,
            update_id=data.get("u"),
            sequence=data.get("seq"),
        )
        if any(
            not math.isfinite(result[key]) or result[key] <= 0
            for key in ("qty_step", "min_qty", "min_notional", "tick_size", "max_qty")
        ):
            raise DataUnavailable("Некорректные биржевые ограничения объёма / цены")
        return result

    def funding(self, symbol):
        data = self.get(
            "https://api.bybit.com/v5/market/funding/history",
            {"category": "linear", "symbol": symbol, "limit": 50},
            ttl=60,
        )
        if data.get("retCode") != 0:
            raise DataUnavailable("Нет истории funding")
        return [
            {
                "at": int(x["fundingRateTimestamp"]) / 1000,
                "rate": float(x["fundingRate"]),
            }
            for x in data["result"]["list"]
        ]

    def funding_mark(self, symbol, at):
        data = self.get(
            "https://api.bybit.com/v5/market/mark-price-kline",
            {
                "category": "linear",
                "symbol": symbol,
                "interval": "1",
                "start": int(at * 1000),
                "limit": 1,
            },
            ttl=3600,
        )
        rows = data.get("result", {}).get("list", [])
        if data.get("retCode") != 0 or not rows or int(rows[0][0]) != int(at * 1000):
            raise DataUnavailable("Нет mark-price на время funding")
        price = float(rows[0][1])
        if not math.isfinite(price) or price <= 0:
            raise DataUnavailable("Некорректная mark-price funding")
        return price


def iso_time(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()


COIN_NAMES = {
    "BTC": "bitcoin",
    "ETH": "ethereum",
    "SOL": "solana",
    "XRP": "xrp",
    "DOGE": "dogecoin",
    "HYPE": "hyperliquid",
    "ZEC": "zcash",
}


class PolymarketData(PublicData):
    """Gamma discovery + CLOB executable depth + official resolved payouts.

    References: docs.polymarket.com/market-data/discover-markets and
    docs.polymarket.com/market-data/public-analytics (GET /v2/tokens).
    """

    def list_symbols(self):
        symbols = set()
        now = time.time()
        for offset in range(0, 2000, 100):
            rows = self.get(
                "https://gamma-api.polymarket.com/markets",
                {
                    "active": "true",
                    "closed": "false",
                    "limit": 100,
                    "offset": offset,
                    "end_date_min": datetime.fromtimestamp(
                        now, timezone.utc
                    ).isoformat(),
                    "end_date_max": datetime.fromtimestamp(
                        now + 7200, timezone.utc
                    ).isoformat(),
                },
                ttl=20,
            )
            for row in rows:
                if "up or down" not in row.get("question", "").lower():
                    continue
                match = re.match(r"([a-z0-9]+)-updown-", row.get("slug", ""))
                if match:
                    symbols.add(match.group(1).upper())
                else:
                    for coin, name in COIN_NAMES.items():
                        if row.get("question", "").lower().startswith(name + " "):
                            symbols.add(coin)
            if len(rows) < 100:
                break
        return sorted(symbols)

    def discover(self, coin, duration, now=None):
        clock.ensure()
        now = market_now(now)
        if duration in (300, 900):
            slug = f"{coin.lower()}-updown-{duration // 60}m-{int(now) // duration * duration}"
            rows = self.get(
                "https://gamma-api.polymarket.com/markets", {"slug": slug}, ttl=3
            )
        else:
            # Hourly slugs use local-language dates; discover them from metadata.
            rows = []
            for offset in range(0, 1000, 100):
                batch = self.get(
                    "https://gamma-api.polymarket.com/markets",
                    {
                        "active": "true",
                        "closed": "false",
                        "limit": 100,
                        "offset": offset,
                        "end_date_min": datetime.fromtimestamp(
                            now, timezone.utc
                        ).isoformat(),
                        "end_date_max": datetime.fromtimestamp(
                            now + 3700, timezone.utc
                        ).isoformat(),
                    },
                    ttl=20,
                )
                rows.extend(batch)
                if len(batch) < 100:
                    break
        candidates = []
        for row in rows:
            try:
                slug = row["slug"]
                title = row["question"].lower()
                if "up or down" not in title:
                    continue
                name = COIN_NAMES.get(coin, coin.lower())
                if not (
                    title.startswith(name + " ")
                    or slug.startswith(coin.lower() + "-")
                    or slug.startswith(name + "-")
                ):
                    continue
                end = iso_time(row["endDate"])
                matched = re.search(r"-updown-(5|15)m-(\d+)$", slug)
                if matched:
                    start = float(matched.group(2))
                    actual = int(matched.group(1)) * 60
                else:
                    event = (row.get("events") or [{}])[0]
                    start = iso_time(
                        row.get("eventStartTime")
                        or event.get("startTime")
                        or row.get("gameStartTime")
                        or ""
                    )
                    actual = int(round(end - start))
                if (
                    actual != duration
                    or abs(end - start - duration) > 1
                    or not start <= now < end
                    or row.get("closed")
                    or row.get("acceptingOrders") is not True
                ):
                    continue
                outcomes = row["outcomes"]
                tokens = row["clobTokenIds"]
                if isinstance(outcomes, str):
                    outcomes = json.loads(outcomes)
                if isinstance(tokens, str):
                    tokens = json.loads(tokens)
                mapping = {str(a).upper(): str(b) for a, b in zip(outcomes, tokens)}
                if set(mapping) != {"UP", "DOWN"}:
                    continue
                candidates.append(
                    dict(
                        id=str(row["id"]),
                        condition=row["conditionId"],
                        slug=slug,
                        start=start,
                        end=end,
                        tokens=mapping,
                        fees_enabled=row.get("feesEnabled"),
                        fee_schedule=row.get("feeSchedule")
                        if row.get("feesEnabled") is not False
                        else {"rate": 0.0, "exponent": 1},
                        min_size=row.get("orderMinSize"),
                        tick_size=row.get("orderPriceMinTickSize"),
                    )
                )
            except (KeyError, ValueError, TypeError):
                continue
        if len(candidates) != 1:
            raise DataUnavailable(
                "Не найден единственный активный UP/DOWN рынок "
                + coin
                + f" {duration // 60}m"
            )
        return candidates[0]

    def impulse(self, coin, start, now):
        # Signal source is Binance spot; settlement never uses this price.
        rows = self.get(
            "https://api.binance.com/api/v3/klines",
            {
                "symbol": coin + "USDT",
                "interval": "1m",
                "startTime": int(start * 1000),
                "limit": 1,
            },
            ttl=60,
        )
        if not rows or int(rows[0][0]) != int(start * 1000):
            raise DataUnavailable("Нет цены начала рынка")
        first = float(rows[0][1])
        last = float(
            self.get(
                "https://api.binance.com/api/v3/ticker/price",
                {"symbol": coin + "USDT"},
                ttl=0.5,
            )["price"]
        )
        if not all(math.isfinite(x) and x > 0 for x in (first, last)):
            raise DataUnavailable("Некорректная цена импульса")
        return last - first, 100 * (last / first - 1)

    def book(self, token):
        clock.ensure()
        data = self.get("https://clob.polymarket.com/book", {"token_id": token})
        if str(data.get("asset_id")) != token:
            raise DataUnavailable("Стакан другого токена")
        stamp = float(data["timestamp"]) / 1000
        check_book_time(stamp, "Polymarket")
        return data["asks"], stamp

    def execution_terms(self, market, require_fees=True):
        schedule = market.get("fee_schedule")
        if (
            not schedule
            and require_fees
            or market.get("min_size") is None
            or market.get("tick_size") is None
        ):
            data = self.get(
                "https://clob.polymarket.com/clob-markets/" + market["condition"],
                ttl=60,
            )
            details = data.get("fd", {})
            if not schedule:
                schedule = {"rate": details.get("r"), "exponent": details.get("e")}
            market["min_size"] = data.get("mos")
            market["tick_size"] = data.get("mts")
        minimum = float(market["min_size"])
        tick = float(market["tick_size"])
        if (
            not math.isfinite(minimum)
            or minimum <= 0
            or not math.isfinite(tick)
            or not 0 < tick < 1
        ):
            raise DataUnavailable("Не подтверждены ограничения ордеров рынка")
        if not require_fees:
            return {"fee_schedule": None, "min_size": minimum, "tick_size": tick}
        rate = schedule.get("rate")
        exponent = schedule.get("exponent")
        if (
            any(
                type(x) not in (int, float) or not math.isfinite(x)
                for x in (rate, exponent)
            )
            or not 0 <= rate <= 1
            or not 0 <= exponent <= 4
        ):
            raise DataUnavailable("Не подтверждены публичные параметры комиссии")
        return {
            "fee_schedule": {"rate": rate, "exponent": exponent},
            "min_size": minimum,
            "tick_size": tick,
        }

    def payout(self, token):
        data = self.get(
            "https://data-api.polymarket.com/v2/tokens", {"token_id": token}, ttl=5
        )
        rows = data.get("data", []) if isinstance(data, dict) else []
        if isinstance(rows, dict):
            rows = rows.get("items", [])
        for row in rows:
            asset = str(
                row.get("asset_id", row.get("assetId", row.get("token_id", "")))
            )
            resolved = row.get("resolved")
            value = row.get("final_price", row.get("finalPrice"))
            if asset == token and resolved is True and value is not None:
                payout = float(value)
                if math.isfinite(payout) and 0 <= payout <= 1:
                    return payout
        return None

    def outcome_quote(self, token):
        clock.ensure()
        data = self.get("https://clob.polymarket.com/book", {"token_id": token})
        if str(data.get("asset_id")) != token:
            raise DataUnavailable("Стакан другого исхода")
        at = float(data["timestamp"]) / 1000
        if not book_is_fresh(at):
            raise DataUnavailable("Устаревшая оценка позиции")
        bids = [float(x["price"]) for x in data["bids"] if float(x["size"]) > 0]
        asks = [float(x["price"]) for x in data["asks"] if float(x["size"]) > 0]
        if (
            not bids
            or not asks
            or any(not math.isfinite(x) or not 0 < x < 1 for x in bids + asks)
            or max(bids) > min(asks)
        ):
            raise DataUnavailable("Нет достоверной оценки позиции")
        return observed_quote({"bid": max(bids), "ask": min(asks), "at": at})


def estimate_buy(asks, budget, max_ask, fee_rate, fee_schedule=None):
    clean = []
    for row in asks:
        price = float(row["price"])
        size = float(row["size"])
        if (
            not math.isfinite(price)
            or not math.isfinite(size)
            or not 0 < price < 1
            or size < 0
        ):
            raise DataUnavailable("Повреждён стакан")
        if price <= max_ask:
            clean.append((price, size))
    clean.sort()
    left = budget
    cost = shares = fee = 0
    for price, size in clean:
        per_share = (
            fee_schedule["rate"] * (price * (1 - price)) ** fee_schedule["exponent"]
            if fee_schedule is not None
            else price * fee_rate
        )
        qty = min(size, left / (price + per_share))
        cost += price * qty
        fee += per_share * qty
        shares += qty
        left -= (price + per_share) * qty
        if left <= 1e-8:
            break
    if left > 1e-7 or shares <= 0:
        raise DataUnavailable("Недостаточная глубина стакана")
    return cost, shares, fee
