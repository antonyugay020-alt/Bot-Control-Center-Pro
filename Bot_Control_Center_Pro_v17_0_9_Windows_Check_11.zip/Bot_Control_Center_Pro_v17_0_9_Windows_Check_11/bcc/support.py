"""Collect only the dedicated check workspace; never discover other bot roots."""

import argparse
import math
import os
import platform
import shutil
import tempfile
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from . import VERSION
from .lifecycle import Lifecycle
from .storage import Repository, Store, atomic_json, load_json


def execution_freshness(events):
    fills = [e for e in events if e["action"] in ("OPEN", "DCA", "CLOSE", "PARTIAL")]
    proven = [
        e
        for e in fills
        if all(k in e for k in ("book_at", "book_age_lower", "book_age_upper"))
    ]
    invalid = [
        e["id"]
        for e in proven
        if not (
            all(
                type(e[k]) in (int, float) and math.isfinite(e[k])
                for k in ("book_at", "book_age_lower", "book_age_upper")
            )
            and e["book_at"] > 0
            and -0.5 <= e["book_age_lower"] <= e["book_age_upper"] <= 3
        )
    ]
    return dict(
        status="FAIL"
        if invalid
        else "PARTIAL_EVIDENCE"
        if len(proven) < len(fills)
        else "PASS"
        if fills
        else "NO_FILLS",
        examined_fills=len(fills),
        with_age_evidence=len(proven),
        without_age_evidence=len(fills) - len(proven),
        invalid_event_ids=invalid,
        maximum_age_upper=max(
            (e["book_age_upper"] for e in proven if e["id"] not in invalid),
            default=None,
        ),
    )


def collect(root, output, *, stop_workers=True, life=None):
    repo = Repository(root)
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    life = life or Lifecycle(repo)
    if life.repo.root != repo.root:
        raise ValueError("Контроллер относится к другой папке ботов")
    report = {
        "bots": [],
        "errors": [],
        "release_ready": False,
        "workers_stopped_for_report": stop_workers,
    }
    rows = repo.list()
    stopping = set()
    for folder, cfg in rows if stop_workers else []:
        try:
            if life.process(folder):
                life.stop(folder)
                stopping.add(folder)
        except Exception as exc:
            report["errors"].append({"bot": folder.name, "stop": str(exc)})
    deadline = time.monotonic() + 15
    while stopping and time.monotonic() < deadline:
        for folder in list(stopping):
            try:
                if life.process(folder) is None:
                    stopping.remove(folder)
            except Exception as exc:
                report["errors"].append({"bot": folder.name, "stop": str(exc)})
                stopping.remove(folder)
        time.sleep(0.1)
    for folder, cfg in rows:
        item = {
            "bot": folder.name,
            "name": cfg.get("name"),
            "strategy": cfg.get("strategy"),
        }
        report["bots"].append(item)
        try:
            cfg, _ = repo.load(folder)
            target = output / cfg["strategy"] / folder.name
            target.mkdir(parents=True)
            atomic_json(target / "config.json", cfg)
            item["process_status"] = life.status(folder)
            active = life.active_snapshot(folder)
            item["active_process_confirmed"] = active is not None
            if active and active.get("active_config"):
                from .config import validate

                try:
                    atomic_json(
                        target / "active_config.json", validate(active["active_config"])
                    )
                except ValueError as exc:
                    item["active_config_error"] = str(exc)
            process_file = folder / "process.json"
            if process_file.is_file():
                process = load_json(process_file)
                item["worker_status"] = process.get("status")
                item["worker_app_version"] = process.get("app_version")
                if process.get("status") == "ERROR" and (
                    item["process_status"] == "Остановлен" or active
                ):
                    message = process.get("last_error", "Worker stopped with an error")
                    item["worker_error"] = message
                    report["errors"].append(
                        {"bot": folder.name, "worker_error": message}
                    )
            if stop_workers and item["process_status"] != "Остановлен":
                report["errors"].append(
                    {"bot": folder.name, "error": "Process stop could not be confirmed"}
                )
            if (folder / "paper.sqlite").exists():
                with tempfile.TemporaryDirectory(prefix="bcc-report-") as temp:
                    snapshot_path = Path(temp)
                    Store(folder).backup(snapshot_path / "paper.sqlite")
                    snapshot = Store(snapshot_path)
                    snapshot.audit()
                    state = snapshot.read()
                    item["open_positions"] = len(state["positions"])
                    item["pending_manual_close"] = sum(
                        p.get("exit_pending", {}).get("reason") == "MANUAL_PAPER_CLOSE"
                        for p in state["positions"].values()
                    )
                    if item["pending_manual_close"]:
                        report["errors"].append(
                            {
                                "bot": folder.name,
                                "pending_manual_close": item["pending_manual_close"],
                            }
                        )
                    atomic_json(target / "state.json", state)
                    history = snapshot.history(100_000)
                    item["execution_freshness"] = execution_freshness(history)
                    if item["execution_freshness"]["status"] == "FAIL":
                        report["errors"].append(
                            {
                                "bot": folder.name,
                                "execution_freshness": item["execution_freshness"],
                            }
                        )
                    atomic_json(target / "executions.json", history)
                    shutil.copy2(snapshot.path, target / "paper.sqlite")
                item["ledger"] = "AUDIT_PASS"
            for name in ("engine.log", "console.log"):
                path = folder / name
                if path.is_file():
                    with path.open("rb") as stream:
                        stream.seek(max(0, path.stat().st_size - 1_000_000))
                        (target / name).write_bytes(stream.read())
        except Exception as exc:
            item["error"] = str(exc)
            report["errors"].append({"bot": folder.name, "error": str(exc)})
    atomic_json(output / "collection.json", report)
    return report


def export_current_report(root, target, *, life=None):
    """Snapshot the explicitly selected app root; never stop/restart its workers."""
    root = Path(root).resolve(strict=True)
    if not (root / "MY_BOTS").is_dir() or (root / "MY_BOTS").is_symlink():
        raise ValueError("Выберите папку программы, в которой находится MY_BOTS")
    target = Path(target).resolve()
    if target.suffix.lower() != ".zip" or target.is_relative_to(
        Path(root).resolve() / "MY_BOTS"
    ):
        raise ValueError("Сохраните ZIP отчёта вне папки MY_BOTS")
    with tempfile.TemporaryDirectory(
        prefix=".bcc-current-report-", dir=target.parent
    ) as temp:
        folder = Path(temp) / "current_bots_report"
        report = collect(root, folder / "paper_bots", stop_workers=False, life=life)
        if not report["bots"]:
            raise ValueError(
                "В выбранной папке нет ботов. Для проверочного запуска выберите его папку внутри check_workspaces, содержащую MY_BOTS"
            )
        summary = {
            "app_version": VERSION,
            "at": datetime.now(timezone.utc).isoformat(),
            "platform": platform.platform(),
            "data_root": str(Path(root).resolve()),
            "read_only": True,
            "workers_stopped_for_report": False,
            "bot_count": len(report["bots"]),
            "errors": report["errors"],
            "release_ready": False,
        }
        atomic_json(folder / "report_summary.json", summary)
        pending = Path(temp) / "report.zip"
        with zipfile.ZipFile(pending, "w", zipfile.ZIP_DEFLATED) as archive:
            for file in sorted(folder.rglob("*")):
                if file.is_file():
                    archive.write(
                        file, Path("current_bots_report") / file.relative_to(folder)
                    )
        os.replace(pending, target)
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = collect(args.root, args.output)
    return 1 if report["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
