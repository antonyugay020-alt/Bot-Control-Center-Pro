"""Searchable multi-coin selection using public exchange inventories."""

from PySide6.QtCore import QObject, QRunnable, QThreadPool, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QLineEdit,
    QListWidget,
    QVBoxLayout,
)

from .widgets import button, dialog_size, label


class InventorySignals(QObject):
    loaded = Signal(list, str)


class InventoryJob(QRunnable):
    def __init__(self, strategy):
        super().__init__()
        self.strategy = strategy
        self.signals = InventorySignals()

    def run(self):
        from .market import PolymarketData, PublicData

        source = PolymarketData() if self.strategy == "POLYMARKET" else PublicData()
        try:
            self.signals.loaded.emit(source.list_symbols(), "")
        except Exception as e:
            self.signals.loaded.emit([], str(e))
        finally:
            source.close()


class CoinPicker(QDialog):
    def __init__(self, strategy, symbols, parent=None):
        super().__init__(parent)
        self.strategy = strategy
        self.result_symbols = list(symbols)
        self.setWindowTitle("Выбор монет")
        dialog_size(self, 1000, 700)
        layout = QVBoxLayout(self)
        self.notice = label(
            "Загрузите доступные монеты с публичного API. Выбранные ранее монеты сохраняются.",
            "muted",
        )
        layout.addWidget(self.notice)
        top = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Поиск монеты")
        self.search.textChanged.connect(self.filter)
        top.addWidget(self.search)
        self.load_button = button("Загрузить доступные", self.load, "primary")
        top.addWidget(self.load_button)
        layout.addLayout(top)
        columns = QHBoxLayout()
        left = QVBoxLayout()
        right = QVBoxLayout()
        columns.addLayout(left, 1)
        columns.addLayout(right, 1)
        layout.addLayout(columns, 1)
        left.addWidget(label("Доступные на бирже", "title"))
        right.addWidget(label("Добавлены в бота", "title"))
        self.available = QListWidget()
        self.chosen = QListWidget()
        for view in (self.available, self.chosen):
            view.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        left.addWidget(self.available)
        right.addWidget(self.chosen)
        self.chosen.addItems(list(dict.fromkeys(symbols)))
        select = QHBoxLayout()
        select.addWidget(button("Выбрать все", self.select_visible))
        select.addWidget(button("Снять все", self.available.clearSelection))
        left.addLayout(select)
        left.addWidget(button("Добавить выбранные", self.add_selected))
        left.addWidget(button("Добавить все доступные", self.add_all))
        right.addWidget(button("Удалить выбранные", self.remove_selected))
        right.addWidget(button("Удалить все", self.clear_chosen))
        self.count = label("")
        layout.addWidget(self.count)
        self.update_count()
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save
            | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.commit)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def load(self):
        self.load_button.setEnabled(False)
        self.notice.setText("Получение доступных торговых пар…")
        self.job = InventoryJob(self.strategy)
        self.job.signals.loaded.connect(self.loaded)
        QThreadPool.globalInstance().start(self.job)

    def loaded(self, symbols, error):
        self.load_button.setEnabled(True)
        if error:
            self.notice.setText("Список монет сейчас недоступен: " + error)
            return
        self.available.clear()
        self.available.addItems(sorted(set(symbols)))
        self.notice.setText(
            f"Получено доступных монет: {len(symbols)}. Длительности Polymarket проверяются отдельно для каждого рынка."
            if self.strategy == "POLYMARKET"
            else f"Получено бессрочных USDT-пар: {len(symbols)}"
        )
        self.filter()

    def filter(self, *args):
        needle = self.search.text().upper().strip()
        for i in range(self.available.count()):
            self.available.item(i).setHidden(
                needle not in self.available.item(i).text()
            )

    def select_visible(self):
        self.available.clearSelection()
        for i in range(self.available.count()):
            self.available.item(i).setSelected(not self.available.item(i).isHidden())

    def add(self, symbols):
        existing = {self.chosen.item(i).text() for i in range(self.chosen.count())}
        for symbol in symbols:
            if symbol not in existing:
                self.chosen.addItem(symbol)
                existing.add(symbol)
        self.update_count()

    def add_selected(self):
        self.add([i.text() for i in self.available.selectedItems() if not i.isHidden()])

    def add_all(self):
        self.add([self.available.item(i).text() for i in range(self.available.count())])

    def remove_selected(self):
        for item in self.chosen.selectedItems():
            self.chosen.takeItem(self.chosen.row(item))
        self.update_count()

    def clear_chosen(self):
        self.chosen.clear()
        self.update_count()

    def update_count(self):
        self.count.setText(f"Добавлено монет: {self.chosen.count()}")

    def commit(self):
        self.result_symbols = [
            self.chosen.item(i).text() for i in range(self.chosen.count())
        ]
        if not self.result_symbols:
            self.notice.setText("Выберите хотя бы одну монету")
            return
        self.accept()
