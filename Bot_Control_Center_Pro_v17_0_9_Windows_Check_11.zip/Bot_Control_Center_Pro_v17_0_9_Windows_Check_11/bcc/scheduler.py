"""Bounded parallel public reads; accounting stays on the single worker thread."""

import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from dataclasses import dataclass

from .market import DataUnavailable
from .market_clock import market_now


@dataclass
class MarketTick:
    symbol: str
    bars: list
    book: dict | None
    rates: list
    funding_marks: dict
    history_error: str = ""
    quote_error: str = ""


class MarketScheduler:
    def __init__(self, source, cfg, history_size, *, workers=8, period=2):
        self.source = source
        self.cfg = cfg
        self.history_size = history_size
        self.period = period
        self.pool = ThreadPoolExecutor(
            max_workers=workers, thread_name_prefix="public-market"
        )
        self.capacity = workers
        self.jobs = {}
        self.due = {}
        self.cursor = 0
        self.priority_cursor = 0
        self.priority_limit = max(1, self.capacity - max(1, workers // 2))

    def _fetch(self, symbol, required, positions, manage=True):
        history_error = ""
        bars = []
        if manage:
            try:
                bars = self.source.candles(symbol, required)
            except (DataUnavailable, ValueError, KeyError, TypeError) as e:
                history_error = str(e)
        rates = []
        marks = {}
        if positions:
            try:
                rates = self.source.funding(symbol)
                earliest = min(positions)
                for rate in rates:
                    if earliest <= rate["at"] <= market_now():
                        marks[rate["at"]] = self.source.funding_mark(symbol, rate["at"])
            except (DataUnavailable, ValueError, KeyError, TypeError):
                pass
        if not manage:
            return MarketTick(symbol, bars, None, rates, marks)
        try:
            book = self.source.orderbook(symbol)
            return MarketTick(symbol, bars, book, rates, marks, history_error)
        except (DataUnavailable, ValueError, KeyError, TypeError) as e:
            return MarketTick(symbol, bars, None, rates, marks, history_error, str(e))

    def collect(self, state, timeout=0.2):
        symbols = list(
            dict.fromkeys(
                self.cfg["symbols"]
                + [p["symbol"] for p in state["positions"].values()]
                + [p["symbol"] for p in state.get("funding_archive", {}).values()]
            )
        )
        priority = list(
            dict.fromkeys(
                p["symbol"]
                for p in list(state["positions"].values())
                + list(state.get("pending", {}).values())
            )
        )
        priority_set = set(priority)
        scan = [s for s in symbols if s not in priority_set]
        now = time.monotonic()

        def submit(symbol):
            if symbol in self.jobs or self.due.get(symbol, 0) > now:
                return False
            opened = [
                p["opened"]
                for p in list(state["positions"].values())
                + list(state.get("funding_archive", {}).values())
                if p["symbol"] == symbol
            ]
            self.jobs[symbol] = self.pool.submit(
                self._fetch,
                symbol,
                self.history_size(self.cfg, symbol, state),
                opened,
                symbol in self.cfg["symbols"] or symbol in priority_set,
            )
            return True

        # Revisit positions and accepted grids before continuing a large scan.
        # Reserve some jobs for discovery so many open deals cannot starve it.
        active_jobs = sum(s in priority_set for s in self.jobs)
        for _ in range(len(priority)):
            if len(self.jobs) >= self.capacity or (
                scan and active_jobs >= self.priority_limit
            ):
                break
            symbol = priority[self.priority_cursor % len(priority)]
            self.priority_cursor = (self.priority_cursor + 1) % len(priority)
            active_jobs += int(submit(symbol))
        for _ in range(len(scan)):
            if len(self.jobs) >= self.capacity:
                break
            symbol = scan[self.cursor % len(scan)]
            self.cursor = (self.cursor + 1) % len(scan)
            submit(symbol)
        if self.jobs:
            wait(list(self.jobs.values()), timeout=timeout, return_when=FIRST_COMPLETED)
        else:
            time.sleep(min(timeout, self.period))
        completed = []
        for symbol, job in list(self.jobs.items()):
            if not job.done():
                continue
            del self.jobs[symbol]
            self.due[symbol] = time.monotonic() + self.period
            try:
                completed.append((symbol, job.result(), None))
            except Exception as e:
                completed.append((symbol, None, e))
        completed.sort(key=lambda row: (row[0] not in priority_set,))
        return completed

    def close(self):
        if hasattr(self.source, "stop_event"):
            self.source.stop_event.set()
        for job in self.jobs.values():
            job.cancel()
        self.pool.shutdown(wait=True, cancel_futures=True)
