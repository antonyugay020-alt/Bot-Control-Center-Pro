"""One exclusive bot process. Ctrl+C/Stop preserves all PAPER positions."""

import argparse
import hashlib
import json
import logging
import os
import signal
import time
from copy import deepcopy
from pathlib import Path

from . import VERSION
from .config import effective, merge, validate
from .control import arm_run, deal_closed
from .market import DataUnavailable, PolymarketData, PublicData, estimate_buy
from .market_clock import book_is_fresh, latest_now, market_now
from .storage import BotLock, Store, atomic_json
from .strategies import ENGINES, daily_ok
from .trading import equity, event


def required_bars(cfg, symbol, state=None):
    from .indicators import walk_conditions

    if cfg["strategy"] in ("GRID", "PUMP_DUMP"):
        return 150
    groups = []
    over = cfg["coin_overrides"].get(symbol, {})
    for s in cfg["sections"]:
        sec_over = over.get("sections", {}).get(s["id"], {})
        groups.extend(sec_over.get(k, over.get(k, s[k])) for k in ("entry", "exit"))
        settings = effective(cfg, symbol, s)
        groups.extend([settings["orders"]["signal"], settings["stop"]["signal"]])
    for p in (state or {}).get("positions", {}).values():
        if p["symbol"] == symbol and p.get("exit_signal"):
            groups.extend(
                [
                    p["exit_signal"],
                    p["settings"]["orders"]["signal"],
                    p["settings"]["stop"]["signal"],
                ]
            )
    from .indicators import EXTRA

    needs = []
    for g in groups:
        for c in walk_conditions(g):
            params = {**EXTRA.get(c["indicator"], {}), **c.get("params", {})}
            right = {
                **EXTRA.get(c.get("reference_indicator", c["indicator"]), {}),
                **c.get("reference_params", {}),
            }
            lengths = [max(c["period"], c.get("reference_period", 0)) * 3] + [
                int(p.get(k, 0))
                for p in (params, right)
                for k in ("rank", "slow", "signal", "kijun", "displacement", "streak")
            ]
            needs.append(
                (
                    max(lengths)
                    + max(c.get("shift", 0), c.get("reference_shift", 0))
                    + int(params.get("displacement", 0))
                    + int(right.get("displacement", 0))
                    + 30
                )
                * max(c["timeframe"], c.get("reference_timeframe", 1))
                + c["timeframe"]
            )
    return max([150] + needs)


def process_polymarket(cfg, state, events, source, now, should_stop=lambda: False):
    params = cfg["polymarket"]
    diagnostics = []
    # Settlement runs even after a coin/duration was disabled or its market ended.
    for key, p in list(state["positions"].items()):
        if should_stop():
            return
        if now < p["end"]:
            try:
                state["marks"][p["token"]] = source.outcome_quote(p["token"])
            except (DataUnavailable, ValueError, KeyError, TypeError):
                diagnostics.append(
                    {
                        "section": p["section"],
                        "reason": "Оценка позиции временно недоступна; исход ожидается официально",
                    }
                )
            continue
        try:
            value = source.payout(p["token"])
        except (DataUnavailable, ValueError, KeyError, TypeError):
            value = None
        if value is None:
            diagnostics.append(
                {"section": key, "reason": "Ожидание официального исхода"}
            )
            continue
        payout = p["shares"] * value
        net = payout - p["cost"] - p["fee"]
        state["cash"] += payout
        event(
            events,
            p["symbol"],
            p["section"],
            "SETTLE",
            price=value,
            qty=p["shares"],
            fee=0,
            cash_delta=payout,
            net_pnl=payout - p["cost"],
            cycle_net_pnl=net,
            reason="OFFICIAL_RESOLUTION",
            side=p["side"],
            slug=p["slug"],
        )
        stats = state["stats"].setdefault(
            p["section"], {"cycles": 0, "wins": 0, "net_pnl": 0}
        )
        stats["cycles"] += 1
        stats["wins"] += int(net > 0)
        stats["net_pnl"] += net
        if p.get("settings", effective(cfg, p["symbol"]))["stop_after_cycle"]:
            state["done"]["cycle:" + p["section"]] = True
        del state["positions"][key]
        deal_closed(state)
    for coin in cfg["symbols"]:
        if state["strategy"].get("draining"):
            break
        finance = effective(cfg, coin)
        if finance["disabled"]:
            continue
        coin_params = merge(
            params, cfg["coin_overrides"].get(coin, {}).get("parameters", {})
        )
        for duration in params["durations"]:
            if should_stop():
                return
            section = f"{coin}:{duration}"
            settings = merge(coin_params, params["overrides"].get(section, {}))
            if settings["disabled"]:
                continue
            if finance["stop_after_cycle"] and state["done"].get("cycle:" + section):
                diagnostics.append(
                    {
                        "section": section,
                        "reason": "Остановлено после завершения сделки",
                    }
                )
                continue
            if not daily_ok(cfg, state, coin, finance, int(now * 1000)):
                diagnostics.append(
                    {"section": section, "reason": "Достигнут дневной лимит убытка"}
                )
                continue
            try:
                market = source.discover(coin, duration, market_now(now))
                now = market_now(now)
                key = market["condition"]
                if state["done"].get(key):
                    why = "Уже торговали этот рынок"
                else:
                    left = market["end"] - now
                    if (
                        left < settings["min_seconds_left"]
                        or settings["timing"] == "before_close"
                        and left > settings["seconds_before_close"]
                    ):
                        why = "Ожидание окна входа"
                    else:
                        usd, pct = source.impulse(coin, market["start"], now)
                        impulse = usd if settings["impulse_mode"] == "usd" else pct
                        if abs(impulse) < settings["impulse"]:
                            why = "Импульс ниже порога"
                        else:
                            side = "UP" if impulse > 0 else "DOWN"
                            token = market["tokens"][side]
                            terms = source.execution_terms(
                                market, settings["fee_mode"] == "public"
                            )
                            schedule = terms["fee_schedule"]
                            asks, stamp = source.book(token)
                            best = min(
                                (
                                    float(x["price"])
                                    for x in asks
                                    if float(x["size"]) > 0
                                ),
                                default=2,
                            )
                            if not settings["ask_min"] <= best <= settings["ask_max"]:
                                why = "ASK вне коридора"
                            else:
                                base = (
                                    max(0, equity(state)[0])
                                    if cfg["reinvest"]
                                    else cfg["capital"]
                                )
                                budget = base * settings["stake_pct"] / 100
                                if budget > state["cash"] or budget <= 0:
                                    why = "Недостаточно свободных средств"
                                else:
                                    cost, shares, fee = estimate_buy(
                                        asks,
                                        budget,
                                        settings["ask_max"],
                                        settings["fee_rate"],
                                        fee_schedule=schedule,
                                    )
                                    if shares < terms["min_size"]:
                                        raise DataUnavailable(
                                            "Объём ниже минимума ордера этого рынка"
                                        )
                                    if not book_is_fresh(stamp):
                                        raise DataUnavailable(
                                            "Стакан устарел до PAPER-исполнения"
                                        )
                                    # Revalidate time after network reads to avoid crossing expiry.
                                    if should_stop():
                                        return
                                    if (
                                        latest_now()
                                        >= market["end"] - settings["min_seconds_left"]
                                    ):
                                        raise DataUnavailable(
                                            "Рынок завершился при сборе данных"
                                        )
                                    from .market_clock import book_age_bounds

                                    age_low, age_high = book_age_bounds(stamp)
                                    if age_low < -0.5 or age_high > 3:
                                        raise DataUnavailable(
                                            "Стакан устарел перед фиксацией PAPER-входа"
                                        )
                                    state["cash"] -= cost + fee
                                    state["done"][key] = True
                                    state["positions"][key] = dict(
                                        kind="POLYMARKET",
                                        symbol=coin,
                                        section=section,
                                        side=side,
                                        token=token,
                                        shares=shares,
                                        qty=shares,
                                        average=cost / shares,
                                        cost=cost,
                                        fee=fee,
                                        margin=0,
                                        opened=market_now(now),
                                        end=market["end"],
                                        slug=market["slug"],
                                        settings=deepcopy(finance),
                                    )
                                    event(
                                        events,
                                        coin,
                                        section,
                                        "OPEN",
                                        price=cost / shares,
                                        qty=shares,
                                        fee=fee,
                                        cash_delta=-cost - fee,
                                        net_pnl=-fee,
                                        side=side,
                                        slug=market["slug"],
                                        seconds_into_market=market_now()
                                        - market["start"],
                                        duration=duration,
                                        book_at=stamp,
                                        book_age_lower=age_low,
                                        book_age_upper=age_high,
                                        fee_model="public_schedule"
                                        if schedule is not None
                                        else "configured_estimate",
                                        fee_schedule=schedule,
                                    )
                                    why = "PAPER-вход " + side
                diagnostics.append({"section": section, "reason": why})
            except (DataUnavailable, KeyError, TypeError, ValueError) as e:
                diagnostics.append({"section": section, "reason": str(e)})
    state["diagnostics"]["POLYMARKET"] = diagnostics


def run(folder, token, *, once=False):
    folder = Path(folder).resolve()
    stop = False

    def request_stop(*args):
        nonlocal stop
        stop = True

    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)
    logging.info("INITIALIZE pid=%s parent=%s", os.getpid(), os.getppid())
    with BotLock(folder):
        raw = (folder / "config.json").read_bytes()
        cfg = validate(json.loads(raw))
        store = Store(folder, cfg["capital"])
        state = store.read(include_charts=False)
        store.audit()
        if state["initial"] != cfg["capital"]:
            raise ValueError("Начальный капитал не совпадает с PAPER-счётом")
        (folder / "finish.request").unlink(missing_ok=True)
        with store.transaction() as (state, events):
            arm_run(state, cfg)
        from .process_identity import current_creation_time

        started = current_creation_time()
        status = dict(
            app_version=VERSION,
            pid=os.getpid(),
            parent_pid=os.getppid(),
            created=started,
            token=token,
            config_hash=hashlib.sha256(raw).hexdigest(),
            active_config=cfg,
            status="RUNNING",
            heartbeat=time.time(),
            draining=state["strategy"].get("draining", False),
        )
        atomic_json(folder / "process.json", status)
        source = PolymarketData() if cfg["strategy"] == "POLYMARKET" else PublicData()
        engine = None if cfg["strategy"] == "POLYMARKET" else ENGINES[cfg["strategy"]]()
        from .runtime import run_loop

        def should_stop():
            from .control import stop_requested

            return stop or stop_requested(folder, token)

        logging.info("START %s %s", cfg["strategy"], cfg["name"])
        try:
            run_loop(
                folder,
                cfg,
                store,
                source,
                engine,
                status,
                should_stop,
                required_bars,
                process_polymarket,
                once,
            )
        except BaseException as exc:
            status.update(status="ERROR", last_error=str(exc))
            raise
        finally:
            if status["status"] != "ERROR":
                status["status"] = "STOPPED"
            status["heartbeat"] = time.time()
            atomic_json(folder / "process.json", status)
            (folder / "stop.request").unlink(missing_ok=True)
            if hasattr(source, "close"):
                source.close()
            else:
                source.session.close()
            logging.info("STOP %s %s", cfg["name"], status["status"])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--folder", required=True)
    parser.add_argument("--token", required=True)
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()
    folder = Path(args.folder)
    logging.basicConfig(
        filename=folder / "engine.log",
        encoding="utf-8",
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
    )
    try:
        run(folder, args.token, once=args.once)
    except Exception:
        logging.exception("Движок остановлен с ошибкой")
        raise


if __name__ == "__main__":
    main()
