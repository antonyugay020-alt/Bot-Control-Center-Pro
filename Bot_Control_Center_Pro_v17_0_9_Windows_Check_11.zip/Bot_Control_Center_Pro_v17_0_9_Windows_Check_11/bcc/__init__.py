"""Bot Control Center Pro: independent PAPER strategy workers and Modern Qt UI."""

VERSION = "17.0.9"
