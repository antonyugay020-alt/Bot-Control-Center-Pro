"""Capture and check the actual Qt interface in an isolated, empty bot workspace."""

import argparse
import os
import platform
import tempfile
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--offscreen",
        action="store_true",
        help="Development rendering; never native Windows acceptance",
    )
    args = parser.parse_args()
    if args.offscreen:
        os.environ["QT_QPA_PLATFORM"] = "offscreen"
    from PySide6.QtCore import QCoreApplication, QEvent, QTimer
    from PySide6.QtWidgets import QApplication

    from .coin_picker import CoinPicker
    from .config import STRATEGIES, defaults, validate
    from .storage import atomic_json
    from .ui import MainWindow, apply_style
    from .wizard import BotWizard

    args.output.mkdir(parents=True, exist_ok=True)
    app = QApplication([])
    apply_style(app, {"theme": "dark", "scale": 100})
    report = {
        "platform": platform.platform(),
        "qt_platform": app.platformName(),
        "native_windows": os.name == "nt" and app.platformName() == "windows",
        "checks": [],
        "test_data": "Isolated bot configurations; no fabricated market data or trades",
    }
    temp = tempfile.TemporaryDirectory(prefix="bcc-gui-check-")
    window = MainWindow(Path(temp.name))
    for kind in STRATEGIES:
        cfg = defaults(kind)
        cfg["name"] = "Проверка · " + kind
        window.repo.create(cfg)
    window.refresh()
    window.show()

    def capture():
        try:
            available = app.primaryScreen().availableGeometry()
            report["screen"] = {
                "width": available.width(),
                "height": available.height(),
            }
            if (
                window.width() > available.width()
                or window.height() > available.height()
            ):
                raise ValueError("Главное окно не помещается на экране")
            window.grab().save(str(args.output / "dashboard.png"))
            for kind in STRATEGIES:
                cfg = defaults(kind)
                cfg["name"] = "Проверка · " + kind
                wizard = BotWizard(cfg, window)
                try:
                    wizard.show()
                    for page in range(wizard.pages.count()):
                        wizard.steps.setCurrentRow(page)
                        app.processEvents()
                        validate(wizard.data())
                        if page == 1 and not wizard.finance_widget.isVisible():
                            raise ValueError(kind + ": скрыты финансовые настройки")
                        if (
                            page == 3
                            and kind
                            in ("VELES", "EMA", "MACD", "BOLLINGER", "EMA_RSI_VOLUME")
                            and not wizard.settings.orders.isVisible()
                        ):
                            raise ValueError(kind + ": скрыты параметры сетки")
                        if kind == "VELES" and page in (1, 3):
                            wizard.grab().save(
                                str(
                                    args.output
                                    / (
                                        "veles_finance.png"
                                        if page == 1
                                        else "veles_orders.png"
                                    )
                                )
                            )
                        if wizard.data() != cfg:
                            raise ValueError(
                                kind + ": редактор изменил незатронутые параметры"
                            )
                    wizard.steps.setCurrentRow(2)
                    app.processEvents()
                    if (
                        wizard.width() > available.width()
                        or wizard.height() > available.height()
                    ):
                        raise ValueError(kind + ": конструктор не помещается на экране")
                    wizard.grab().save(str(args.output / (kind.lower() + ".png")))
                    report["checks"].append(
                        {
                            "strategy": kind,
                            "pages": wizard.pages.count(),
                            "status": "PASS",
                        }
                    )
                finally:
                    wizard.close()
                    wizard.deleteLater()
            window.show_running_bots()
            window.running_monitor.include_stopped.setChecked(True)
            app.processEvents()
            window.running_monitor.grab().save(
                str(args.output / "all_bots_monitor.png")
            )
            report["all_bots_monitor"] = "PASS"
            window.running_monitor.close()
            report["coin_picker"] = []
            from PySide6.QtGui import QPalette

            def luminance(color):
                channels = [color.redF(), color.greenF(), color.blueF()]
                channels = [
                    x / 12.92 if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4
                    for x in channels
                ]
                return sum(
                    x * weight for x, weight in zip(channels, (0.2126, 0.7152, 0.0722))
                )

            for theme in ("dark", "light"):
                apply_style(app, {"theme": theme, "scale": 100})
                picker = CoinPicker("VELES", ["ETHUSDT", "BTCUSDT"], window)
                try:
                    picker.notice.setText(
                        "Проверка контраста: подписи монет; список биржи не загружался."
                    )
                    picker.available.addItems(["BTCUSDT", "ETHUSDT", "SOLUSDT"])
                    picker.available.setCurrentRow(0)
                    picker.chosen.setCurrentRow(0)
                    picker.show()
                    picker.available.setFocus()
                    app.processEvents()
                    minimum = 100.0
                    for view in (picker.available, picker.chosen):
                        palette = view.palette()
                        for group in (
                            QPalette.ColorGroup.Active,
                            QPalette.ColorGroup.Inactive,
                        ):
                            for foreground, background in (
                                (QPalette.ColorRole.Text, QPalette.ColorRole.Base),
                                (
                                    QPalette.ColorRole.HighlightedText,
                                    QPalette.ColorRole.Highlight,
                                ),
                            ):
                                a, b = sorted(
                                    (
                                        luminance(palette.color(group, foreground)),
                                        luminance(palette.color(group, background)),
                                    )
                                )
                                minimum = min(minimum, (b + 0.05) / (a + 0.05))
                    if minimum < 4.5:
                        raise ValueError(
                            f"Выбор монет, {theme}: недостаточный контраст {minimum:.2f}"
                        )
                    picker.grab().save(
                        str(args.output / ("coin_picker_" + theme + ".png"))
                    )
                    report["coin_picker"].append(
                        {
                            "theme": theme,
                            "minimum_contrast": round(minimum, 2),
                            "status": "PASS",
                        }
                    )
                finally:
                    picker.close()
                    picker.deleteLater()
            apply_style(app, {"theme": "dark", "scale": 100})
            report["status"] = "PASS"
        except Exception as e:
            report.update(status="FAIL", error=str(e))
        finally:
            atomic_json(args.output / "gui_report.json", report)
            window.close()
            window.deleteLater()
            QTimer.singleShot(0, app.quit)

    QTimer.singleShot(200, capture)
    app.exec()
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    temp.cleanup()
    print(
        "Qt:",
        report["qt_platform"],
        report.get("status"),
        report.get("error", ""),
        flush=True,
    )
    return 0 if report.get("status") == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
