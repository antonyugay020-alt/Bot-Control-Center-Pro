"""PAPER positions, capital reservations, fee accounting and order planning."""

import math
import uuid
from copy import deepcopy
from decimal import Decimal

from .control import deal_closed
from .execution import ExecutionRejected, PaperExecutor, floor_quantity
from .market_clock import market_now, quote_is_recent


def plan(orders, side, anchor):
    sign = -1 if side == "LONG" else 1
    if orders["mode"] == "custom":
        return [
            {
                "price": anchor * (1 + sign * r["offset_pct"] / 100),
                "weight": r["volume_pct"] / 100,
                "anchor": anchor,
            }
            for r in orders["custom"]
        ]
    n = orders["count"]
    ratio = 1 + orders["martingale_pct"] / 100
    weights = [ratio**i for i in range(n)]
    total = sum(weights)
    # A logarithmic curve >1 concentrates price levels near the first order.
    offsets = [
        orders["first_offset_pct"]
        + orders["coverage_pct"]
        * ((i / (n - 1)) ** orders["logarithmic"] if n > 1 else 0)
        for i in range(n)
    ]
    return [
        {
            "price": anchor * (1 + sign * offset / 100),
            "weight": w / total,
            "anchor": anchor,
        }
        for offset, w in zip(offsets, weights)
    ]


def reserved(state):
    return sum(
        p["margin"] + p.get("order_margin", 0) for p in state["positions"].values()
    ) + sum(p.get("margin", 0) for p in state["pending"].values())


def mark_pnl(p, price):
    return (price - p["average"]) * p["qty"] * (1 if p["side"] == "LONG" else -1)


def percent_stop_price(p):
    """Veles: coverage 15% + stop 5% means 20% from the grid anchor."""
    sign = 1 if p["side"] == "LONG" else -1
    orders = p["settings"]["orders"]
    offset = (
        orders["custom"][0]["offset_pct"]
        if orders["mode"] == "custom"
        else orders["first_offset_pct"]
    )
    anchor = p["orders"][0].get(
        "anchor", p["orders"][0]["price"] / (1 - sign * offset / 100)
    )
    last = p["last_fill"] if orders["mode"] == "signal" else p["orders"][-1]["price"]
    return last - sign * anchor * p["settings"]["stop"]["pct"] / 100


def available_margin(state):
    """Open losses reduce collateral even before a position has been closed."""
    return equity(state)[0] - reserved(state)


def update_equity_metrics(state):
    value, unknown = equity(state)
    if not unknown:
        peak = max(state.get("equity_peak", state["initial"]), value)
        state["equity_peak"] = peak
        state["max_drawdown"] = max(
            state.get("max_drawdown", 0), (peak - value) / peak * 100 if peak > 0 else 0
        )


def equity(state):
    total = state["cash"]
    unknown = False
    for p in state["positions"].values():
        if p.get("kind") == "POLYMARKET":
            # Pending official settlement is not realized profit. Value the
            # holding at its acquisition cost when no outcome bid is available.
            q = state["marks"].get(p["token"])
            if quote_is_recent(q):
                total += p["shares"] * q["bid"]
            else:
                total += p["cost"]
                unknown = True
            continue
        q = state["marks"].get(p["symbol"])
        if q:
            total += mark_pnl(p, q["bid"] if p["side"] == "LONG" else q["ask"])
            if not quote_is_recent(q):
                unknown = True
        else:
            unknown = True
    return total, unknown


def fill_price(side, leg, bid, ask, settings):
    if (
        not all(
            type(x) in (int, float) and math.isfinite(x) and x > 0 for x in (bid, ask)
        )
        or bid > ask
    ):
        raise ValueError("Повреждена котировка")
    buy = (side == "LONG") == (leg == "ENTRY")
    price = ask if buy else bid
    return price * (1 + settings["slippage_pct"] / 100 * (1 if buy else -1))


def event(events, symbol, section, action, **values):
    item = dict(
        id=uuid.uuid4().hex,
        at=market_now(),
        symbol=symbol,
        section=section,
        action=action,
        **values,
    )
    events.append(item)
    return item


def enter(
    state,
    events,
    key,
    symbol,
    side,
    settings,
    price,
    margin,
    orders,
    section,
    *,
    reinvest_pct=0.0,
    existing_grid=False,
    entry_limit=None,
):
    if state.get("_entry_blocked"):
        return False, state["_entry_blocked"]
    if state["strategy"].get("draining") and not existing_grid:
        return False, "Бот завершает текущие сделки; новые входы отключены"
    if key in state["positions"]:
        return False, "Позиция уже открыта"
    first = margin * settings["leverage"] * orders[0]["weight"]
    fee = first * settings["fee_rate"]
    if available_margin(state) < margin + fee:
        return False, "Недостаточно свободного капитала"
    if margin <= 0:
        return False, "Нулевая сумма секции"
    qty = first / price
    if symbol not in state.get("_books", {}):
        return False, "Нет свежего стакана для исполнения"
    if symbol in state.get("_books", {}):
        resting = (
            settings["orders"]["first_offset_pct"] > 0
            or settings["orders"]["mode"] == "custom"
            and settings["orders"]["custom"][0]["offset_pct"] > 0
        )
        try:
            fill = PaperExecutor(state["_books"][symbol]).estimate(
                side,
                "ENTRY",
                settings,
                notional=first,
                limit=entry_limit
                if entry_limit is not None
                else orders[0]["price"]
                if resting
                else None,
            )
        except ExecutionRejected as e:
            return False, str(e)
        price = fill.price
        qty = fill.quantity
        first = fill.notional
        fee = fill.fee
    state["cash"] -= fee
    p = dict(
        symbol=symbol,
        side=side,
        section=section,
        opened=market_now(),
        entry=price,
        last_fill=price,
        average=price,
        qty=qty,
        fees=fee,
        funding_total=0.0,
        reinvest_pct=reinvest_pct,
        margin=first / settings["leverage"],
        order_margin=margin * sum(o["weight"] for o in orders[1:])
        if len(orders) > 1
        else 0,
        budget=margin * settings["leverage"],
        spent=first,
        settings=deepcopy(settings),
        orders=deepcopy(orders),
        next_order=1,
        dca_fills=0,
        active_until=min(len(orders), 1 + settings["orders"]["partial_count"]),
        original_qty=qty,
        realized=0.0,
        targets_done=[],
        trail_peak=None,
        breakeven=False,
        quantity_timeline=[{"at": market_now(), "delta": qty}],
    )
    state["positions"][key] = p
    state["done"].pop(key, None)
    event(
        events,
        symbol,
        section,
        "OPEN",
        price=price,
        qty=p["qty"],
        fee=fee,
        cash_delta=-fee,
        net_pnl=-fee,
        side=side,
        fill_status="PARTIAL_IOC" if fill.partial else "FILLED",
        **fill.evidence(),
    )
    return True, "Открыто"


def add_order(state, events, key, price):
    if state.get("_entry_blocked"):
        return False
    p = state["positions"][key]
    index = p["next_order"]
    settings = p["settings"]
    if index >= len(p["orders"]):
        return False
    amount = p["budget"] * p["orders"][index]["weight"]
    fee = amount * settings["fee_rate"]
    if available_margin(state) < fee:
        return False
    qty = amount / price
    if p["symbol"] not in state.get("_books", {}):
        return False
    if p["symbol"] in state.get("_books", {}):
        limit = (
            p["orders"][index]["price"]
            if settings["orders"]["mode"] != "signal"
            else None
        )
        try:
            fill = PaperExecutor(state["_books"][p["symbol"]]).estimate(
                p["side"], "ENTRY", settings, notional=amount, limit=limit
            )
        except ExecutionRejected:
            return False
        price = fill.price
        qty = fill.quantity
        amount = fill.notional
        fee = fill.fee
    trail_price = None
    if p["trail_peak"] is not None:
        sign = 1 if p["side"] == "LONG" else -1
        trail_price = p["average"] * (1 + sign * p["trail_peak"] / 100)
    p["average"] = (p["average"] * p["qty"] + amount) / (p["qty"] + qty)
    if trail_price is not None:
        p["trail_peak"] = 100 * (trail_price / p["average"] - 1) * sign
    p["qty"] += qty
    p["original_qty"] += qty
    p["fees"] += fee
    p["spent"] += amount
    p["next_order"] += 1
    p["dca_fills"] = p.get("dca_fills", 0) + 1
    stats = state["stats"].setdefault(
        key, {"cycles": 0, "wins": 0, "net_pnl": 0, "max_dca": 0}
    )
    stats["max_dca"] = max(stats.get("max_dca", 0), p["dca_fills"])
    p["margin"] += amount / settings["leverage"]
    p["order_margin"] = (
        p["budget"]
        / settings["leverage"]
        * sum(o["weight"] for o in p["orders"][p["next_order"] :])
    )
    p["last_fill"] = price
    state["cash"] -= fee
    p.setdefault("quantity_timeline", []).append({"at": market_now(), "delta": qty})
    event(
        events,
        p["symbol"],
        p["section"],
        "DCA",
        price=price,
        qty=qty,
        fee=fee,
        cash_delta=-fee,
        net_pnl=-fee,
        index=index,
        side=p["side"],
        fill_status="PARTIAL_IOC" if fill.partial else "FILLED",
        **fill.evidence(),
    )
    return True


def exit_position(
    state, events, key, price, reason, ratio=1.0, *, limit=None, target_index=None
):
    p = state["positions"].get(key)
    if not p:
        return
    ratio = min(1.0, max(0.0, ratio))
    if ratio <= 0:
        return
    qty = p["qty"] * ratio
    requested_qty = qty
    pending = {
        "reason": reason,
        "ratio": ratio,
        "limit": limit,
        "target_index": target_index,
    }
    p.pop("tp_deferred", None)
    if p["symbol"] not in state.get("_books", {}):
        p["exit_pending"] = pending
        return False
    if p["symbol"] in state.get("_books", {}):
        book = state["_books"][p["symbol"]]
        if (
            reason == "MULTI_TP"
            and target_index is not None
            and target_index < len(p["settings"]["profit"]["targets"]) - 1
        ):
            aligned = floor_quantity(qty, Decimal(str(book["qty_step"])))
            if aligned <= 0 or aligned < book["min_qty"] - 1e-12:
                p.pop("exit_pending", None)
                p["tp_deferred"] = {
                    "target": target_index,
                    "reason": "Объём тейка ниже биржевого минимума; переносится на следующий тейк",
                }
                return False
        try:
            fill = PaperExecutor(state["_books"][p["symbol"]]).estimate(
                p["side"], "EXIT", p["settings"], quantity=qty, limit=limit
            )
        except ExecutionRejected:
            p["exit_pending"] = pending
            return False
        qty = fill.quantity
        price = fill.price
        requested_qty = fill.requested_quantity
        ratio = qty / p["qty"]
    unfilled = max(0, requested_qty - qty)
    request_complete = unfilled <= max(1e-12, requested_qty * 1e-10)
    p.pop("exit_pending", None)
    gross = (price - p["average"]) * qty * (1 if p["side"] == "LONG" else -1)
    fee = price * qty * p["settings"]["fee_rate"]
    entry_fee = p["fees"] * ratio
    delta = gross - fee
    net = delta - entry_fee
    state["cash"] += delta
    p["realized"] += net
    p["fees"] -= entry_fee
    p["qty"] -= qty
    if not request_complete and p["qty"] > 0:
        pending["ratio"] = min(1.0, unfilled / p["qty"])
        p["exit_pending"] = pending
    p["margin"] *= 1 - ratio
    p["order_margin"] = 0
    p.setdefault("quantity_timeline", []).append({"at": market_now(), "delta": -qty})
    p["next_order"] = len(
        p["orders"]
    )  # Taking profit cancels every remaining averaging order.
    if (
        request_complete
        and target_index is not None
        and target_index not in p["targets_done"]
    ):
        p["targets_done"].append(target_index)
        profit = p["settings"]["profit"]
        sign = 1 if p["side"] == "LONG" else -1
        if profit["breakeven"]:
            p["breakeven"] = True
            base = p["average"]
            if target_index > 0 and profit["breakeven_reference"] == "take_profit":
                base *= 1 + sign * profit["targets"][target_index - 1]["pct"] / 100
            p["breakeven_price"] = base * (
                1 + sign * profit["breakeven_offset_pct"] / 100
            )
    close_event = event(
        events,
        p["symbol"],
        p["section"],
        "CLOSE" if ratio >= 1 - 1e-10 else "PARTIAL",
        price=price,
        qty=qty,
        fee=fee,
        cash_delta=delta,
        net_pnl=delta,
        cycle_net_pnl=net,
        reason=reason,
        side=p["side"],
        fill_status="PARTIAL_IOC" if fill.partial else "FILLED",
        **fill.evidence(),
    )
    if ratio >= 1 - 1e-10:
        deal_closed(state)
        trading_net = p["realized"] + p.get("funding_total", 0)
        reinvested = max(0, trading_net) * p.get("reinvest_pct", 0) / 100
        if reinvested:
            state["strategy"]["veles_reinvested"] = (
                state["strategy"].get("veles_reinvested", 0) + reinvested
            )
        close_event.update(trading_net_pnl=trading_net, reinvested=reinvested)
        stats = state["stats"].setdefault(key, {"cycles": 0, "wins": 0, "net_pnl": 0})
        stats["cycles"] += 1
        stats["wins"] += int(p["realized"] > 0)
        stats["net_pnl"] += p["realized"]
        # The public funding rate may be published after this trade is closed.
        # Retain its exposure until a later funding timestamp confirms coverage.
        state.setdefault("funding_archive", {})[f"{key}:{p['opened']}"] = {
            "key": key,
            "symbol": p["symbol"],
            "section": p["section"],
            "side": p["side"],
            "opened": p["opened"],
            "closed": market_now(),
            "cycle_pnl": p["realized"],
            "quantity_timeline": deepcopy(p["quantity_timeline"]),
        }
        if p["settings"]["stop_after_cycle"]:
            state["done"][key] = True
        if p["settings"]["stop"].get("stop_after") and reason in (
            "STOP_LOSS",
            "SIGNAL_STOP",
        ):
            state["done"][key] = "STOP_LOSS"
        del state["positions"][key]
    return True


def protective_exit(state, events, key, bid, ask):
    p = state["positions"][key]
    s = p["settings"]
    sign = 1 if p["side"] == "LONG" else -1
    quote = bid if sign == 1 else ask
    gain = 100 * (quote / p["average"] - 1) * sign
    profit = s["profit"]
    stop = s["stop"]
    reason = None
    if p["breakeven"] and (quote - p.get("breakeven_price", p["average"])) * sign <= 0:
        reason = "BREAKEVEN"
    if stop["mode"] in ("percent", "both") and p["next_order"] >= len(p["orders"]):
        limit = percent_stop_price(p)
        if (quote - limit) * sign <= 0:
            reason = "STOP_LOSS"
    if profit["trailing"] and gain >= profit["activation_pct"]:
        p["trail_peak"] = max(
            gain, p["trail_peak"] if p["trail_peak"] is not None else gain
        )
    if p["trail_peak"] is not None and gain <= p["trail_peak"] - profit["distance_pct"]:
        reason = "TRAILING"
    if (
        reason is None
        and profit["mode"] == "simple"
        and gain >= profit["pct"]
        and not profit["trailing"]
    ):
        reason = "TAKE_PROFIT"
    if reason:
        exit_position(
            state,
            events,
            key,
            fill_price(p["side"], "EXIT", bid, ask, s),
            reason,
            limit=p["average"] * (1 + sign * profit["pct"] / 100)
            if reason == "TAKE_PROFIT"
            else None,
        )
        return True
    if p.get("exit_pending"):
        return False
    if profit["mode"] == "custom":
        for idx, target in enumerate(profit["targets"]):
            if idx in p["targets_done"] or gain < target["pct"]:
                continue
            # Individual partial targets round down to the lot step. The final
            # target closes the actual remainder, including accumulated dust.
            cumulative = (
                p["original_qty"]
                * sum(t["volume_pct"] for t in profit["targets"][: idx + 1])
                / 100
            )
            needed = cumulative - (p["original_qty"] - p["qty"])
            if needed <= 1e-12:
                continue
            fraction = (
                1 if idx == len(profit["targets"]) - 1 else min(1, needed / p["qty"])
            )
            completed = exit_position(
                state,
                events,
                key,
                fill_price(p["side"], "EXIT", bid, ask, s),
                "MULTI_TP",
                fraction,
                limit=p["average"] * (1 + sign * target["pct"] / 100),
                target_index=idx,
            )
            if not completed:
                if p.get("tp_deferred", {}).get("target") == idx:
                    continue
                return True
            if key not in state["positions"] or p.get("exit_pending"):
                return True
    return False


def liquidations(state, events, maintenance=0.005):
    cross = []
    for key, p in list(state["positions"].items()):
        if p.get("kind") == "POLYMARKET":
            continue
        q = state["marks"].get(p["symbol"])
        if not quote_is_recent(q):
            continue
        quote = q["bid"] if p["side"] == "LONG" else q["ask"]
        upnl = mark_pnl(p, quote)
        need = p["qty"] * quote * (maintenance + p["settings"]["fee_rate"])
        if p["settings"]["margin_mode"] == "ISOLATED":
            if p["margin"] + upnl <= need:
                exit_position(
                    state,
                    events,
                    key,
                    fill_price(p["side"], "EXIT", q["bid"], q["ask"], p["settings"]),
                    "PAPER_LIQUIDATION",
                )
        else:
            cross.append((key, p, upnl, need))
    isolated = sum(
        p["margin"]
        for p in state["positions"].values()
        if p.get("settings", {}).get("margin_mode") == "ISOLATED"
    )
    all_cross = [
        p
        for p in state["positions"].values()
        if p.get("settings", {}).get("margin_mode") == "CROSS"
    ]
    if (
        cross
        and len(cross) == len(all_cross)
        and state["cash"] - isolated + sum(x[2] for x in cross)
        <= sum(x[3] for x in cross)
    ):
        for key, p, _, _ in cross:
            q = state["marks"][p["symbol"]]
            exit_position(
                state,
                events,
                key,
                fill_price(p["side"], "EXIT", q["bid"], q["ask"], p["settings"]),
                "PAPER_CROSS_LIQUIDATION",
            )
