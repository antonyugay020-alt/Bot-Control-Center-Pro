"""Bot-wide finish policy, separate from immediate process Stop and deal exits."""

import logging

from .storage import load_json


def stop_requested(folder, token):
    path = folder / "stop.request"
    try:
        command = load_json(path)
    except FileNotFoundError:
        return False
    # Untagged commands remain readable for old packages; new controllers bind
    # STOP to one launch so a delayed request cannot stop the next run.
    return "token" not in command or command["token"] == token


def arm_run(state, cfg):
    control = state["strategy"]
    control["finish_on_close"] = cfg.get("stop_after_deals", False)
    control["draining"] = bool(
        (control.get("draining") or control["finish_on_close"])
        and (state["positions"] or state["pending"])
    )


def deal_closed(state):
    if state["strategy"].get("finish_on_close"):
        state["strategy"]["draining"] = True


def finish_requested(folder, store):
    path = folder / "finish.request"
    if not path.exists():
        return
    command = load_json(path)
    draining = command.get("draining", True)
    if type(draining) is not bool:
        raise ValueError("Неверный режим завершения сделок")
    with store.transaction() as (state, events):
        state["strategy"]["draining"] = draining
        if not draining:
            state["strategy"]["finish_on_close"] = False
        state["strategy"]["finish_command"] = command["id"]
    path.unlink(missing_ok=True)
    logging.info("FINISH policy: draining=%s", draining)


def finished(state):
    return bool(
        state["strategy"].get("draining")
        and not state["positions"]
        and not state["pending"]
    )
