"""Sole user interface: Modern Qt Dashboard."""

import csv
import math
import time
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QSizePolicy,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QToolBar,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from . import VERSION
from .chart import CandleChart
from .config import STRATEGIES, STRATEGY_NAMES, defaults
from .lifecycle import Lifecycle
from .market_clock import quote_is_recent
from .storage import Repository, Store, atomic_json, load_json
from .trading import available_margin, equity, mark_pnl
from .widgets import Fields, button, combo, confirm_dialog, label
from .wizard import BotWizard

STYLE = """
QWidget {color:#e5edf8;font-family:"Segoe UI","DejaVu Sans";font-size:13px;}
QMainWindow,QDialog,QWidget#root,QWidget[scrollContent="true"] {background:#101722;}
QFrame#topbar,QWidget#aside {background:#142130;border:1px solid #2a3b50;border-radius:8px;}
QLabel#headline {font-size:23px;font-weight:700;color:#f1f7ff;}
QLabel#title {font-size:17px;font-weight:600;color:#e6f4ff;}
QLabel#muted {color:#9eb1c9;}
QLabel#error {color:#f4b178;}
QLabel#pill {color:#39deca;border:1px solid #287f7a;padding:5px 14px;border-radius:6px;}
QPushButton {background:#1b2b40;border:1px solid #32465e;padding:9px 15px;border-radius:6px;}
QPushButton:hover {background:#263e55;border-color:#40baa9;}
QPushButton#primary {background:#079e96;color:#fff;font-weight:700;border-color:#25c9b9;}
QPushButton:disabled {color:#657489;background:#17212d;}
QLineEdit,QComboBox,QSpinBox,QDoubleSpinBox {background:#172637;border:1px solid #35475c;border-radius:5px;padding:7px;min-height:18px;}
QLineEdit:focus,QComboBox:focus,QDoubleSpinBox:focus {border-color:#2bd4c0;}
QComboBox QAbstractItemView {background:#1b2b40;selection-background-color:#215d66;}
QListWidget {background:#142130;color:#e5edf8;border:1px solid #293b50;selection-background-color:#1a535c;selection-color:#ffffff;}
QListWidget::item {padding:6px;}
QListWidget::item:hover {background:#1b2d40;}
QListWidget::item:selected,QListWidget::item:selected:!active {background:#1a535c;color:#ffffff;}
QTableWidget {background:#142130;alternate-background-color:#172738;gridline-color:#24364b;border:1px solid #293b50;selection-background-color:#1a535c;}
QHeaderView::section {background:#1b2d40;color:#a9c1d9;border:0;padding:10px;font-weight:600;}
QHeaderView,QTableCornerButton::section {background:#1b2d40;border:0;}
QTableWidget::item {padding:7px;}
QTabWidget::pane {border:1px solid #2b4057;border-radius:6px;}
QTabBar::tab {background:#162435;padding:11px 16px;color:#a7bdd3;}
QTabBar::tab:selected {background:#1b3c49;color:#46dfcc;border-bottom:2px solid #23cfba;}
QListWidget#steps {background:#101d2c;border:0;outline:0;}
QListWidget#steps::item {padding:17px 12px;border-radius:5px;color:#aebfd4;}
QListWidget#steps::item:selected {background:#18424c;color:#45dfce;}
QFrame#condition {background:#17283a;border:1px solid #304257;border-radius:7px;}
QScrollArea {background:transparent;border:0;}
QScrollBar:vertical {background:#122030;width:11px;}
QScrollBar::handle:vertical {background:#36526a;min-height:28px;border-radius:4px;}
QPlainTextEdit {background:#111e2d;border:1px solid #2d4258;padding:8px;}
QMenu {background:#1b2d40;border:1px solid #40566c;}
QMenu::item {padding:9px 24px;} QMenu::item:selected {background:#245560;}
QCheckBox {spacing:9px;padding:5px;}
QTreeWidget#botsTree {background:#122031;border:1px solid #293e53;}
QTreeWidget#botsTree::item {padding:9px 5px;min-height:24px;}
QTreeWidget#botsTree::item:selected {background:#1c535e;color:#4bdeca;}
"""


class SortItem(QTableWidgetItem):
    def __lt__(self, other):
        def key(text):
            try:
                value = float(text.replace(" ", ""))
                if math.isfinite(value):
                    return (0, value)
            except ValueError:
                pass
            return (1, text.casefold())

        return key(self.text()) < key(other.text())


def table(headers):
    t = QTableWidget(0, len(headers))
    t.setHorizontalHeaderLabels(headers)
    t.setAlternatingRowColors(True)
    t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
    t.verticalHeader().hide()
    t.verticalHeader().setDefaultSectionSize(38)
    t.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
    t.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
    t.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
    t.setSortingEnabled(True)
    t.sortByColumn(0, Qt.SortOrder.AscendingOrder)
    return t


def populate(t, rows, keys=None):
    item = t.item(t.currentRow(), 0)
    selected_key = item.data(Qt.ItemDataRole.UserRole) if item else None
    sorting = t.isSortingEnabled()
    t.setSortingEnabled(False)
    t.clearSelection()
    t.setCurrentCell(-1, -1)
    t.clearContents()
    t.setRowCount(len(rows))
    for i, row in enumerate(rows):
        for j, value in enumerate(row):
            item = SortItem(str(value))
            if keys is not None:
                item.setData(Qt.ItemDataRole.UserRole, keys[i])
            t.setItem(i, j, item)
    t.setSortingEnabled(sorting)
    if selected_key is not None:
        for i in range(t.rowCount()):
            if t.item(i, 0).data(Qt.ItemDataRole.UserRole) == selected_key:
                t.selectRow(i)
                break


class MainWindow(QMainWindow):
    def __init__(self, root):
        super().__init__()
        self.repo = Repository(root)
        self.life = Lifecycle(self.repo)
        self.current = None
        self.rows = []
        self.monitor_state = None
        self.running_monitor = None
        self.setWindowTitle("Bot Control Center Pro " + VERSION)
        screen = QApplication.primaryScreen().availableGeometry()
        self.resize(min(1500, screen.width() - 40), min(960, screen.height() - 60))
        self.preferences_path = self.repo.root / "preferences.json"
        try:
            self.preferences = load_json(self.preferences_path)
        except (OSError, ValueError):
            self.preferences = {"scale": 100, "refresh_ms": 2000, "theme": "dark"}
        central = QWidget()
        central.setObjectName("root")
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(20, 14, 20, 14)
        layout.setSpacing(14)
        top = QFrame()
        top.setObjectName("topbar")
        bar = QHBoxLayout(top)
        brand = label("BOT CONTROL CENTER PRO", "title")
        brand.setWordWrap(False)
        bar.addWidget(brand)
        navigation = QToolBar()
        navigation.setMovable(False)
        navigation.setMinimumWidth(0)
        navigation.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred
        )
        bar.addWidget(navigation, 1)
        for key, title in [
            ("VELES", "VELES"),
            ("POLYMARKET", "Polymarket"),
            ("PUMP_DUMP", "PUMP&DUMP"),
            ("GRID", "GRID"),
        ]:
            navigation.addWidget(
                button(title, lambda _, s=key: self.select_strategy(s))
            )
        self.other = combo(
            [("Другие стратегии", None)]
            + [(STRATEGY_NAMES[s], s) for s in STRATEGIES[4:]]
        )
        self.other.activated.connect(
            lambda _: (
                self.select_strategy(self.other.currentData())
                if self.other.currentData()
                else None
            )
        )
        navigation.addWidget(self.other)
        bar.addWidget(button("⚙ Интерфейс", self.app_settings))
        layout.addWidget(top)
        header = QHBoxLayout()
        self.title = label("Все боты", "headline")
        header.addWidget(self.title)
        header.addStretch()
        self.filter = combo(
            [("Все стратегии", None)] + [(STRATEGY_NAMES[s], s) for s in STRATEGIES]
        )
        self.filter.currentIndexChanged.connect(self.refresh)
        header.addWidget(self.filter)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Поиск бота или монеты")
        self.search.textChanged.connect(self.refresh)
        header.addWidget(self.search)
        header.addWidget(button("+ Новый бот", self.create_bot, "primary"))
        layout.addLayout(header)
        actions = QToolBar()
        actions.setMovable(False)
        monitor_button = button("Монитор всех ботов", self.show_running_bots, "primary")
        monitor_button.setObjectName("openRunningBots")
        actions.addWidget(monitor_button)
        report_button = button("Сохранить отчёт", self.save_current_report)
        report_button.setObjectName("saveCurrentBotsReport")
        actions.addWidget(report_button)
        for title, fn in [
            ("▶ Запуск", self.start),
            ("■ Стоп", self.stop),
            ("После сделок", self.finish),
            ("Принудительно", self.force),
            ("Редактировать", self.edit),
            ("Просмотр параметров", self.view_settings),
            ("Копия", self.copy_bot),
            ("Удалить", self.delete),
            ("Перенос", self.transfer_menu),
        ]:
            actions.addWidget(button(title, fn))
        layout.addWidget(actions)
        self.metrics = label("", "title")
        layout.addWidget(self.metrics)
        splitter = QSplitter(Qt.Orientation.Vertical)
        splitter.setObjectName("botDetailsSplitter")
        splitter.setChildrenCollapsible(False)
        self.bots_table = table(
            [
                "Бот",
                "Стратегия",
                "Монеты",
                "Процесс",
                "Баланс PAPER",
                "Позиции",
                "Результат",
            ]
        )
        self.bots_table.itemSelectionChanged.connect(self.selection)
        self.bots_table.doubleClicked.connect(self.view_settings)
        self.bots_table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.bots_table.customContextMenuRequested.connect(self.context_menu)
        self.bots_table.setMinimumHeight(100)
        splitter.addWidget(self.bots_table)
        self.tabs = QTabWidget()
        self.positions = table(
            [
                "Монета",
                "Секция",
                "Сторона",
                "Количество",
                "Средняя цена",
                "Маржа",
                "Нереализ. PnL",
                "DCA сейчас",
                "Открыта",
            ]
        )
        self.orders = table(
            ["Монета", "Секция", "Ордер", "Цена", "Доля, %", "Состояние"]
        )
        self.history = table(
            [
                "Время UTC",
                "Монета",
                "Секция",
                "Действие",
                "Цена",
                "Количество",
                "Net PnL",
                "Причина",
            ]
        )
        self.diagnostics = table(
            ["Монета", "Секция", "Фильтр", "Значения", "Причина ожидания / действие"]
        )
        self.sections = table(
            ["Монета", "Секция", "Циклы", "Выигрышные", "Net PnL", "Макс. DCA"]
        )
        self.logs = QPlainTextEdit()
        self.logs.setReadOnly(True)
        for widget, title in [
            (self.positions, "Позиции"),
            (self.orders, "Ордера"),
            (self.history, "История"),
            (self.diagnostics, "Сигналы"),
            (self.sections, "Статистика секций"),
            (self.logs, "Журнал"),
        ]:
            self.tabs.addTab(widget, title)
        chart_page = QWidget()
        chart_layout = QVBoxLayout(chart_page)
        self.chart_symbol = QComboBox()
        chart_layout.addWidget(self.chart_symbol)
        self.chart = CandleChart()
        chart_layout.addWidget(self.chart, 1)
        self.chart_symbol.currentTextChanged.connect(self.refresh_chart)
        self.tabs.addTab(chart_page, "График")
        self.tabs.setMinimumHeight(160)
        splitter.addWidget(self.tabs)
        splitter.setSizes([320, 440])
        workspace = QSplitter(Qt.Orientation.Horizontal)
        self.bot_tree = QTreeWidget()
        self.bot_tree.setObjectName("botsTree")
        self.bot_tree.setHeaderLabel("MY BOTS")
        self.bot_tree.setMinimumWidth(180)
        self.bot_tree.setMaximumWidth(380)
        self.bot_tree.itemSelectionChanged.connect(self.tree_selected)
        self.bot_tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.bot_tree.customContextMenuRequested.connect(self.tree_context_menu)
        workspace.addWidget(self.bot_tree)
        workspace.addWidget(splitter)
        workspace.setStretchFactor(0, 0)
        workspace.setStretchFactor(1, 1)
        workspace.setSizes([230, 1200])
        layout.addWidget(workspace, 1)
        footer = QHBoxLayout()
        self.notice = label("", "muted")
        self.notice.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Maximum
        )
        self.notice.setMaximumHeight(90)
        footer.addWidget(self.notice, 1)
        self.close_positions_button = button(
            "Закрыть PAPER-позиции", self.close_positions
        )
        footer.addWidget(self.close_positions_button)
        footer.addWidget(button("Экспорт истории CSV", self.export_history))
        layout.addLayout(footer)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(self.preferences.get("refresh_ms", 2000))
        self.refresh()

    def select_strategy(self, s):
        if s:
            self.filter.setCurrentIndex(self.filter.findData(s))

    def show_running_bots(self):
        from .monitoring import RunningBotsWindow

        if self.running_monitor is None:
            self.running_monitor = RunningBotsWindow(
                self.repo, self.life, self, self.preferences.get("refresh_ms", 2000)
            )
            self.running_monitor.open_bot.connect(self.open_from_monitor)
        self.running_monitor.show()
        self.running_monitor.raise_()
        self.running_monitor.activateWindow()

    def open_from_monitor(self, path):
        folder = self.repo.resolve(path)
        self.search.clear()
        self.filter.setCurrentIndex(0)
        self.current = folder
        self.refresh()
        if self.isMinimized():
            self.showNormal()
        else:
            self.show()
        self.raise_()
        self.activateWindow()

    def selected(self):
        if self.current is None:
            raise ValueError("Выберите бота")
        return self.repo.resolve(self.current)

    def execute(self, fn):
        try:
            fn()
            self.refresh()
        except Exception as e:
            QMessageBox.warning(self, "Действие не выполнено", str(e))

    def refresh(self, *args):
        current = self.current
        selected = self.filter.currentData()
        query = self.search.text().casefold()
        rows = []
        self.rows = []
        total_cash = 0
        count = 0
        self.title.setText(STRATEGY_NAMES.get(selected, "Все боты"))
        inventory = self.repo.list()
        for folder, cfg in inventory:
            if selected and cfg["strategy"] != selected:
                continue
            if (
                query
                and query
                not in (cfg["name"] + " " + ",".join(cfg.get("symbols", []))).casefold()
            ):
                continue
            try:
                status = self.life.status(folder)
                if status == "Остановлен":
                    last_error = self.life.last_error(folder)
                    if last_error:
                        status = "Остановлен с ошибкой: " + last_error
                if cfg.get("invalid"):
                    raise ValueError(cfg["invalid"])
                state = (
                    Store(folder).read(include_charts=False)
                    if (folder / "paper.sqlite").exists()
                    else None
                )
                cash = state["cash"] if state else cfg["capital"]
                positions = len(state["positions"]) if state else 0
                pnl = state.get("realized", 0) if state else 0
                total_cash += cash
                count += positions
                row = [
                    cfg["name"],
                    STRATEGY_NAMES[cfg["strategy"]],
                    ", ".join(cfg["symbols"]),
                    status,
                    f"{cash:.2f}",
                    positions,
                    f"{pnl:+.2f}",
                ]
            except Exception as e:
                row = [
                    cfg["name"],
                    cfg["strategy"],
                    "—",
                    "Ошибка: " + str(e),
                    "—",
                    "—",
                    "—",
                ]
            self.rows.append((folder, cfg))
            rows.append(row)
        self.bots_table.blockSignals(True)
        populate(self.bots_table, rows, [str(folder) for folder, _ in self.rows])
        for i in range(self.bots_table.rowCount()):
            if self.bots_table.item(i, 0).data(Qt.ItemDataRole.UserRole) == str(
                current
            ):
                self.bots_table.selectRow(i)
        self.bots_table.blockSignals(False)
        if current and not any(folder == current for folder, _ in self.rows):
            self.current = None
        self.render_tree(inventory)
        self.metrics.setText(
            f"Ботов: {len(rows)}     Открытых позиций: {count}     Денежный баланс: {total_cash:,.2f} USDT"
        )
        self.refresh_details()

    def selection(self):
        row = self.bots_table.currentRow()
        if row >= 0:
            item = self.bots_table.item(row, 0)
            path = item.data(Qt.ItemDataRole.UserRole) if item else None
            self.current = Path(path) if path else None
        self.refresh_details()

    def render_tree(self, inventory):
        expanded = {
            self.bot_tree.topLevelItem(i).data(
                0, Qt.ItemDataRole.UserRole + 1
            ): self.bot_tree.topLevelItem(i).isExpanded()
            for i in range(self.bot_tree.topLevelItemCount())
        }
        self.bot_tree.blockSignals(True)
        self.bot_tree.clear()
        query = self.search.text().casefold()
        groups = {}
        for folder, cfg in inventory:
            if (
                query
                and query
                not in (cfg["name"] + " " + ",".join(cfg.get("symbols", []))).casefold()
            ):
                continue
            groups.setdefault(cfg["strategy"], []).append((folder, cfg))
        for strategy, records in sorted(groups.items()):
            parent = QTreeWidgetItem(
                [f"{STRATEGY_NAMES.get(strategy, strategy)} ({len(records)})"]
            )
            parent.setData(0, Qt.ItemDataRole.UserRole + 1, strategy)
            self.bot_tree.addTopLevelItem(parent)
            parent.setExpanded(expanded.get(strategy, True))
            for folder, cfg in sorted(
                records, key=lambda row: row[1]["name"].casefold()
            ):
                item = QTreeWidgetItem([cfg["name"]])
                item.setData(0, Qt.ItemDataRole.UserRole, str(folder))
                item.setData(0, Qt.ItemDataRole.UserRole + 1, strategy)
                parent.addChild(item)
                if folder == self.current:
                    self.bot_tree.setCurrentItem(item)
        self.bot_tree.blockSignals(False)

    def tree_selected(self):
        item = self.bot_tree.currentItem()
        if item is None:
            return
        path = item.data(0, Qt.ItemDataRole.UserRole)
        strategy = item.data(0, Qt.ItemDataRole.UserRole + 1)
        self.current = Path(path) if path else None
        index = self.filter.findData(strategy)
        if index != self.filter.currentIndex():
            self.filter.setCurrentIndex(index)
        else:
            self.refresh()

    def tree_context_menu(self, point):
        item = self.bot_tree.itemAt(point)
        if item is None or not item.data(0, Qt.ItemDataRole.UserRole):
            return
        self.bot_tree.setCurrentItem(item)
        self._show_bot_menu(self.bot_tree.viewport().mapToGlobal(point))

    def refresh_details(self):
        tables = (
            self.positions,
            self.orders,
            self.history,
            self.diagnostics,
            self.sections,
        )
        if self.current != getattr(self, "_details_folder", None) or not self.current:
            for t in tables:
                t.setRowCount(0)
            self.logs.clear()
        self._details_folder = self.current
        self.history_events = []
        self.monitor_state = None
        self.chart.set_data("", [])
        self.close_positions_button.setEnabled(self.current is not None)
        if not self.current:
            self.notice.setText(
                "Выберите бота для просмотра позиций, сигналов и истории."
            )
            return
        try:
            folder = self.selected()
            cfg, _ = self.repo.load(folder)
            self.close_positions_button.setVisible(cfg["strategy"] != "POLYMARKET")
            if not (folder / "paper.sqlite").exists():
                for t in tables:
                    t.setRowCount(0)
                self.logs.clear()
                self.notice.setText(
                    "Бот создан. PAPER-счёт будет открыт при первом запуске."
                )
                return
            store = Store(folder)
            state = store.read(include_charts=False)
            self.monitor_state = state
            chosen = self.chart_symbol.currentText()
            symbols = store.chart_symbols()
            self.chart_symbol.blockSignals(True)
            self.chart_symbol.clear()
            self.chart_symbol.addItems(symbols)
            if chosen in symbols:
                self.chart_symbol.setCurrentText(chosen)
            self.chart_symbol.blockSignals(False)
            self.refresh_chart()
            now = time.time()
            pos = []
            pos_keys = []
            orders = []
            order_keys = []
            for key, p in state["positions"].items():
                q = state["marks"].get(p.get("token", p["symbol"]))
                upnl = "— (нет свежей оценки)"
                if q and now - q["at"] <= 15:
                    value = (
                        p["shares"] * q["bid"] - p["cost"]
                        if p.get("kind") == "POLYMARKET"
                        else mark_pnl(p, q["bid"] if p["side"] == "LONG" else q["ask"])
                    )
                    upnl = f"{value:+.4f}"
                pos.append(
                    [
                        p["symbol"],
                        p["section"],
                        p["side"],
                        f"{p['qty']:.8g}",
                        f"{p['average']:.8g}",
                        f"{p['margin']:.2f}",
                        upnl,
                        p.get("dca_fills", 0),
                        time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(p["opened"])),
                    ]
                )
                pos_keys.append(key)
                if p.get("kind") == "POLYMARKET":
                    continue
                partial = p["settings"]["orders"]["partial_count"]
                for i, order in enumerate(
                    p["orders"][p["next_order"] :], p["next_order"]
                ):
                    orders.append(
                        [
                            p["symbol"],
                            p["section"],
                            i + 1,
                            f"{order['price']:.8g}",
                            f"{order['weight'] * 100:.3g}",
                            "Активен"
                            if i < p["next_order"] + partial
                            else "Ожидает очереди",
                        ]
                    )
                    order_keys.append(f"{key}:{i}")
            for key, p in state["pending"].items():
                orders.append(
                    [
                        p["symbol"],
                        key,
                        1,
                        f"{p['orders'][0]['price']:.8g}",
                        "—",
                        "Ожидание первого исполнения",
                    ]
                )
                order_keys.append(key + ":pending")
            populate(self.positions, pos, pos_keys)
            populate(self.orders, orders, order_keys)
            events = store.history()
            self.history_events = events
            populate(
                self.history,
                [
                    [
                        time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(e["at"])),
                        e["symbol"],
                        e["section"],
                        e["action"],
                        f"{e.get('price', 0):.8g}",
                        f"{e.get('qty', 0):.8g}",
                        f"{e.get('net_pnl', 0):+.4f}",
                        e.get("reason", ""),
                    ]
                    for e in events
                ],
                [e["id"] for e in events],
            )
            diagnostic_rows = []
            for sym, ds in state["diagnostics"].items():
                for d in ds:
                    diagnostic_rows.append(
                        [sym, d.get("section", ""), "—", "—", d["reason"]]
                    )
                    for c in d.get("conditions", []):
                        values = (
                            f"{c['value']:.6g} {c.get('comparison', '')} {c.get('reference', 0):.6g}"
                            if c.get("available")
                            else "—"
                        )
                        diagnostic_rows.append(
                            [
                                sym,
                                d.get("section", ""),
                                f"{c['indicator']} / {c['timeframe']}m",
                                values,
                                "Выполнено"
                                if c["matched"]
                                else "Ожидание"
                                if c.get("available")
                                else "Недостаточно данных",
                            ]
                        )
            populate(self.diagnostics, diagnostic_rows)
            populate(
                self.sections,
                [
                    [
                        key.split(":")[0],
                        ":".join(key.split(":")[1:]),
                        v["cycles"],
                        v["wins"],
                        f"{v['net_pnl']:+.4f}",
                        v.get("max_dca", 0),
                    ]
                    for key, v in state["stats"].items()
                ],
                list(state["stats"]),
            )
            log_parts = []
            for name in ("engine.log", "console.log"):
                log = folder / name
                if log.exists():
                    with log.open("rb") as stream:
                        stream.seek(max(0, log.stat().st_size - 64000))
                        part = stream.read().decode("utf-8", errors="replace")
                    if part:
                        log_parts.append(name + "\n" + part)
            text = "\n\n".join(log_parts) or "Журнал пуст"
            if text != self.logs.toPlainText():
                bar = self.logs.verticalScrollBar()
                old_position = bar.value()
                at_end = old_position >= bar.maximum()
                self.logs.setPlainText(text)
                bar.setValue(bar.maximum() if at_end else old_position)
            stale = [
                s for s, q in state["marks"].items() if not quote_is_recent(q, now=now)
            ]
            self.notice.setText(
                f"{cfg['name']} · свободная маржа {available_margin(state):.2f} USDT · сохранено позиций {len(pos)}"
                + f" · капитал {'—' if equity(state)[1] else format(equity(state)[0], '.2f')} · макс. DD {state.get('max_drawdown', 0):.2f}%"
                + (
                    f" · реинвестировано {state['strategy'].get('veles_reinvested', 0):.2f} USDT"
                    if cfg["strategy"] == "VELES"
                    else ""
                )
                + (
                    f" · устаревших котировок: {len(stale)}; подробности — «Сигналы»"
                    if stale
                    else ""
                )
            )
        except Exception as e:
            for t in tables:
                t.setRowCount(0)
            self.monitor_state = None
            self.logs.clear()
            self.notice.setText("Ошибка чтения состояния: " + str(e))

    def refresh_chart(self, *args):
        symbol = self.chart_symbol.currentText()
        bars = []
        if symbol and self.current:
            try:
                bars = Store(self.selected()).chart(symbol)
            except (ValueError, OSError, RuntimeError) as exc:
                self.notice.setText("Ошибка чтения графика: " + str(exc))
        self.chart.set_data(symbol, bars)

    def create_bot(self):
        selected = self.filter.currentData()
        if selected is None:
            from PySide6.QtWidgets import QInputDialog

            selected, ok = QInputDialog.getItem(
                self, "Новый бот", "Стратегия", list(STRATEGIES), editable=False
            )
            if not ok:
                return
        cfg = defaults(selected)
        draft = self.repo.root / ("draft_" + selected + ".json")
        if (
            draft.exists()
            and QMessageBox.question(
                self, "Черновик", "Продолжить сохранённый черновик?"
            )
            == QMessageBox.StandardButton.Yes
        ):
            try:
                cfg = load_json(draft)
            except (ValueError, OSError):
                pass
        wizard = BotWizard(cfg, self, draft_path=draft)
        if wizard.exec() == QDialog.DialogCode.Accepted:
            self.execute(lambda: self._created(wizard.result_config))
            draft.unlink(missing_ok=True)

    def _created(self, cfg):
        self.current = self.repo.create(cfg)

    def edit(self, *args):
        def action():
            path = self.selected()
            if self.life.status(path) != "Остановлен":
                raise ValueError("Остановите бота перед редактированием")
            cfg, digest = self.repo.load(path)
            wizard = BotWizard(cfg, self)
            if wizard.exec() == QDialog.DialogCode.Accepted:
                from .inspection import changes

                diff = changes(cfg, wizard.result_config)
                if not diff:
                    return
                report = QPlainTextEdit()
                report.setReadOnly(True)
                report.setPlainText("\n\n".join(diff))
                if confirm_dialog(report, "Изменения перед сохранением", self):
                    self.repo.save(path, wizard.result_config, digest)

        self.execute(action)

    def view_settings(self, *args):
        def action():
            from .inspection import inspect_settings

            path = self.selected()
            documents, source = self.settings_documents(path)
            inspect_settings(
                self, documents, source, refresh=lambda: self.settings_documents(path)
            )

        self.execute(action)

    def settings_documents(self, path):
        path = self.repo.resolve(path)
        cfg, digest = self.repo.load(path)
        source = "Конфигурация на диске"
        documents = {"На диске": cfg}
        process = self.life.active_snapshot(path)
        if process:
            documents["Действует в процессе"] = process["active_config"]
            source = "Действующие настройки подтверждённого процесса"
            if process["config_hash"] != digest:
                source += " · файл на диске отличается"
        elif (path / "process.json").exists():
            documents["Последний запуск"] = load_json(path / "process.json")[
                "active_config"
            ]
            source += " · действующего процесса нет"
        if (path / "paper.sqlite").exists():
            state = Store(path).read(include_charts=False)
            documents["Управление выполнением"] = {
                "draining": state["strategy"].get("draining", False),
                "finish_on_close": state["strategy"].get("finish_on_close", False),
            }
            documents["Открытые позиции"] = {
                key: {
                    "settings": p.get("settings", {}),
                    "strategy_parameters": p.get("strategy_params", {}),
                    "exit": p.get("exit_signal", {}),
                    "reinvest_pct": p.get("reinvest_pct", 0),
                }
                for key, p in state["positions"].items()
            }
            documents["Ожидающие сетки"] = state["pending"]
            if cfg["strategy"] == "VELES":
                documents["Реинвестирование счёта"] = {
                    "capital": cfg["capital"],
                    "veles_reinvested": state["strategy"].get("veles_reinvested", 0),
                    "cash": state["cash"],
                }
        return documents, source

    def start(self):
        self.execute(lambda: self.life.start(self.selected()))

    def stop(self):
        self.execute(lambda: self.life.stop(self.selected()))

    def finish(self):
        self.execute(lambda: self.life.finish(self.selected()))

    def cancel_finish(self):
        self.execute(lambda: self.life.cancel_finish(self.selected()))

    def force(self):
        if (
            QMessageBox.question(
                self,
                "Принудительная остановка",
                "Завершить процесс выбранного бота? Последняя завершённая транзакция и позиции сохранятся.",
            )
            == QMessageBox.StandardButton.Yes
        ):
            self.execute(lambda: self.life.stop(self.selected(), True))

    def close_positions(self):
        if (
            QMessageBox.question(
                self,
                "Закрытие PAPER",
                "Закрыть все позиции выбранного бота по свежим котировкам и отменить ожидающие сетки?",
            )
            == QMessageBox.StandardButton.Yes
        ):
            self.execute(lambda: self.life.close_positions(self.selected()))

    def copy_bot(self):
        answer = QMessageBox.question(
            self,
            "Копирование",
            "Перенести историю, баланс и открытые PAPER-позиции в независимую копию?",
            QMessageBox.StandardButton.Yes
            | QMessageBox.StandardButton.No
            | QMessageBox.StandardButton.Cancel,
        )
        if answer == QMessageBox.StandardButton.Cancel:
            return
        self.execute(
            lambda: setattr(
                self,
                "current",
                self.repo.copy(
                    self.selected(), history=answer == QMessageBox.StandardButton.Yes
                ),
            )
        )

    def delete(self):
        if (
            self.current
            and QMessageBox.question(
                self,
                "Удаление бота",
                "Удалить выбранного бота вместе с историей и файлами? Это действие необратимо.",
            )
            == QMessageBox.StandardButton.Yes
        ):
            self.execute(lambda: self.repo.delete(self.selected()))

    def context_menu(self, point):
        index = self.bots_table.indexAt(point)
        if not index.isValid():
            return
        self.bots_table.selectRow(index.row())
        self._show_bot_menu(self.bots_table.viewport().mapToGlobal(point))

    def _show_bot_menu(self, global_point):
        menu = QMenu(self)
        for title, fn in [
            ("Запуск", self.start),
            ("Стоп", self.stop),
            ("Завершить после текущих сделок", self.finish),
            ("Отменить завершение", self.cancel_finish),
            ("Принудительная остановка", self.force),
            ("Просмотреть настройки", self.view_settings),
            ("Редактировать", self.edit),
            ("Копировать", self.copy_bot),
            ("Удалить", self.delete),
        ]:
            menu.addAction(title, fn)
        menu.exec(global_point)

    def save_current_report(self, *, choose_root=False):
        root = self.repo.root
        if choose_root or not self.repo.list():
            selected = QFileDialog.getExistingDirectory(
                self,
                "Папка программы с MY_BOTS — отчёт без остановки",
                str(root.parent),
            )
            if not selected:
                return
            root = Path(selected).resolve()
        filename = (
            "BCC_CURRENT_REPORT_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".zip"
        )
        path, _ = QFileDialog.getSaveFileName(
            self, "Отчёт текущих ботов без остановки", filename, "ZIP (*.zip)"
        )
        if not path:
            return

        def action():
            from .support import export_current_report

            summary = export_current_report(
                root, path, life=self.life if root == self.repo.root else None
            )
            QMessageBox.information(
                self,
                "Отчёт сохранён",
                f"Ботов в отчёте: {summary['bot_count']}. Работа процессов не изменена.\n{path}",
            )

        self.execute(action)

    def transfer_menu(self):
        menu = QMenu(self)
        menu.addAction("Экспорт выбранного бота", lambda: self.export_bots(False))
        menu.addAction("Экспорт всех ботов", lambda: self.export_bots(True))
        menu.addAction("Импорт независимых копий", self.import_bots)
        menu.addAction("Открыть черновик бота", self.open_draft)
        menu.addAction("Отчёт текущих ботов без остановки", self.save_current_report)
        menu.addAction(
            "Отчёт другой папки без остановки",
            lambda: self.save_current_report(choose_root=True),
        )
        menu.exec(self.cursor().pos())

    def open_draft(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Открыть черновик", "", "JSON (*.json)"
        )
        if not path:
            return

        def action():
            from .config import reject_private_data

            cfg = load_json(path)
            reject_private_data(cfg)
            wizard = BotWizard(cfg, self, draft_path=Path(path))
            if wizard.exec() == QDialog.DialogCode.Accepted:
                self._created(wizard.result_config)

        self.execute(action)

    def export_bots(self, all_bots):
        history = self.transfer_history("Состав экспорта")
        if history is None:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Перенос ботов", "Bots_Backup.zip", "ZIP (*.zip)"
        )
        if path:
            from .transfer import export_bots

            self.execute(
                lambda: export_bots(
                    self.repo,
                    [p for p, c in self.repo.list()] if all_bots else [self.selected()],
                    path,
                    history=history,
                )
            )

    def import_bots(self):
        path, _ = QFileDialog.getOpenFileName(self, "Импорт ботов", "", "ZIP (*.zip)")
        if path:
            from .transfer import import_bots

            history = self.transfer_history("Состав импорта")
            if history is not None:
                self.execute(lambda: import_bots(self.repo, path, history=history))

    def transfer_history(self, title):
        options = [
            "Настройки, баланс, позиции, статистика и журналы",
            "Только настройки — начать с новым PAPER-счётом",
        ]
        value, ok = QInputDialog.getItem(
            self, title, "Что переносить", options, editable=False
        )
        return value == options[0] if ok else None

    def export_history(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "История", "trades.csv", "CSV (*.csv)"
        )
        if path:

            def save():
                events = Store(self.selected()).history(1_000_000)
                keys = sorted({k for e in events for k in e})
                with open(path, "w", encoding="utf-8-sig", newline="") as stream:
                    writer = csv.DictWriter(stream, fieldnames=keys)
                    writer.writeheader()
                    writer.writerows(events)

            self.execute(save)

    def app_settings(self):
        editor = Fields(
            self.preferences,
            [
                ("scale", "Масштаб интерфейса, %", "int", (75, 150)),
                ("refresh_ms", "Обновление мониторинга, мс", "int", (500, 30000)),
                ("theme", "Тема", "choice", [("Тёмная", "dark"), ("Светлая", "light")]),
            ],
        )
        if confirm_dialog(editor, "Настройки приложения", self):
            self.preferences = editor.value_data()
            atomic_json(self.preferences_path, self.preferences)
            self.timer.setInterval(self.preferences["refresh_ms"])
            apply_style(QApplication.instance(), self.preferences)

    def closeEvent(self, event):
        running = any(
            self.life.status(p)
            in ("Работает", "Запуск", "Остановка", "Завершает сделки")
            for p, c in self.repo.list()
        )
        if running:
            answer = QMessageBox.question(
                self,
                "Работающие боты",
                "Закрыть оболочку, оставив ботов работать? После открытия управление восстановится.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
            )
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
        event.accept()
        self.timer.stop()
        if self.running_monitor is not None:
            self.running_monitor.close()
        for view in self.findChildren(QTableWidget):
            view.setSortingEnabled(False)


def apply_style(app, preferences):
    style = STYLE
    if preferences.get("theme") == "light":
        for a, b in [
            ("#101722", "#eef3f8"),
            ("#101d2c", "#e9f0f7"),
            ("#142130", "#ffffff"),
            ("#172637", "#f5f8fb"),
            ("#17283a", "#f4f7fa"),
            ("#1b2b40", "#e6edf4"),
            ("#1b2d40", "#e8eff6"),
            ("#172738", "#f2f6fa"),
            ("#e5edf8", "#1e2d40"),
            ("#f1f7ff", "#10253a"),
            ("#e6f4ff", "#173c58"),
            ("#9eb1c9", "#4e6680"),
            ("#a9c1d9", "#37526d"),
            ("#a7bdd3", "#36516c"),
        ]:
            style = style.replace(a, b)
    scale = preferences.get("scale", 100)
    style = style.replace("font-size:13px", f"font-size:{13 * scale / 100:.1f}px")
    app.setStyleSheet(style)
