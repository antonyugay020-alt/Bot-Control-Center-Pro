"""Portable copies of stopped bots with optional consistent PAPER history."""

import json
import os
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

from .storage import BotLock, Store

LOG_FILES = ("engine.log", "console.log")


def export_bots(repo, folders, target, history=True):
    target = Path(target).resolve()
    if target.suffix.lower() != ".zip" or target.is_relative_to(repo.bots):
        raise ValueError("Сохраните ZIP переноса вне папки MY_BOTS")
    # Build beside the destination, then replace it only after every bot has
    # passed its lock and accounting checks. A failed export keeps the old ZIP.
    with tempfile.TemporaryDirectory(prefix=".bcc-export-", dir=target.parent) as temp:
        temp = Path(temp)
        pending = temp / "export.zip"
        manifest = []
        with zipfile.ZipFile(pending, "w", zipfile.ZIP_DEFLATED) as archive:
            for i, folder in enumerate(folders):
                folder = repo.resolve(folder)
                with BotLock(folder):
                    cfg, _ = repo.load(folder)
                    prefix = f"bot_{i:04d}"
                    archive.writestr(
                        prefix + "/config.json",
                        json.dumps(cfg, ensure_ascii=False, allow_nan=False),
                    )
                    if history and (folder / "paper.sqlite").exists():
                        backup = temp / (prefix + ".sqlite")
                        store = Store(folder)
                        store.audit()
                        store.backup(backup)
                        archive.write(backup, prefix + "/paper.sqlite")
                    if history:
                        for name in LOG_FILES:
                            if (folder / name).is_file():
                                archive.write(folder / name, prefix + "/" + name)
                    manifest.append({"prefix": prefix, "source_path": str(folder)})
            archive.writestr(
                "manifest.json", json.dumps({"format": 1, "bots": manifest})
            )
        os.replace(pending, target)


def import_bots(repo, source, history=True):
    created = []
    try:
        with zipfile.ZipFile(source) as archive:
            if (
                len(archive.infolist()) > 5001
                or sum(i.file_size for i in archive.infolist()) > 500_000_000
            ):
                raise ValueError("Слишком большой архив переноса")
            for item in archive.infolist():
                p = PurePosixPath(item.filename)
                if p.is_absolute() or ".." in p.parts or "\\" in item.filename:
                    raise ValueError("Небезопасный путь в архиве")
            if len(archive.namelist()) != len(set(archive.namelist())):
                raise ValueError("Повторяющиеся файлы в архиве")
            manifest = json.loads(archive.read("manifest.json"))
            if manifest.get("format") != 1:
                raise ValueError("Неизвестный формат переноса")
            for entry in manifest["bots"]:
                prefix = entry["prefix"]
                if not prefix or len(PurePosixPath(prefix).parts) != 1 or prefix == ".":
                    raise ValueError("Неверный каталог бота")
                origin = Path(entry.get("source_path", ""))
                if origin.is_dir() and (origin / "engine.lock").exists():
                    with BotLock(origin):
                        pass
                cfg = json.loads(archive.read(prefix + "/config.json"))
                suffix = " — импорт"
                cfg["name"] = cfg["name"][: 80 - len(suffix)] + suffix
                target = repo.create(cfg)
                created.append(target)
                if history and prefix + "/paper.sqlite" in archive.namelist():
                    content = archive.read(prefix + "/paper.sqlite")
                    if not content.startswith(b"SQLite format 3\0"):
                        raise ValueError("Некорректная история PAPER")
                    (target / "paper.sqlite").write_bytes(content)
                    store = Store(target)
                    store.audit()
                    state = store.read()
                    if state["initial"] != cfg["capital"]:
                        raise ValueError("Депозит истории не совпадает с настройками")
                if history:
                    for name in LOG_FILES:
                        member = prefix + "/" + name
                        if member in archive.namelist():
                            (target / name).write_bytes(archive.read(member))
        return created
    except BaseException:
        import shutil

        for path in created:
            shutil.rmtree(path)
        raise
