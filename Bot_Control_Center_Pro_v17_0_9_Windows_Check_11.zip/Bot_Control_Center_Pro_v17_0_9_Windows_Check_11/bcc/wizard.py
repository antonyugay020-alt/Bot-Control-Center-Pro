"""The same complete constructor is used to create, edit, and inspect bots."""

from copy import deepcopy

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLineEdit,
    QListWidget,
    QSpinBox,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .config import (
    STRATEGY_NAMES,
    coin_section,
    defaults,
    difference,
    effective,
    merge,
    normalize_config,
    validate,
)
from .storage import atomic_json
from .trading import percent_stop_price, plan
from .widgets import (
    Fields,
    SectionEditor,
    SectionsEditor,
    SettingsEditor,
    button,
    combo,
    confirm_dialog,
    dialog_size,
    label,
    scroll,
    spin,
)


class BotWizard(QDialog):
    def __init__(self, cfg, parent=None, *, read_only=False, draft_path=None):
        super().__init__(parent)
        cfg = normalize_config(cfg)
        self.cfg = deepcopy(cfg)
        self.read_only = read_only
        self.draft_path = draft_path
        self.result_config = None
        self.setWindowTitle(
            ("Параметры бота" if read_only else "Конструктор бота")
            + " · "
            + STRATEGY_NAMES[cfg["strategy"]]
        )
        from PySide6.QtWidgets import QApplication

        screen = QApplication.primaryScreen().availableGeometry()
        self.resize(min(1440, screen.width() - 40), min(920, screen.height() - 60))
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        header = QHBoxLayout()
        header.addWidget(
            label(
                ("Настройки · " if read_only else "Конструктор · ")
                + STRATEGY_NAMES[cfg["strategy"]],
                "headline",
            )
        )
        header.addStretch()
        header.addWidget(label("PAPER", "pill"))
        root.addLayout(header)
        body = QHBoxLayout()
        root.addLayout(body, 1)
        self.steps = QListWidget()
        self.steps.setObjectName("steps")
        self.steps.setFixedWidth(205)
        self.steps.setWordWrap(True)
        self.pages = QStackedWidget()
        body.addWidget(self.steps)
        body.addWidget(self.pages, 1)
        aside = QWidget()
        self.aside = aside
        aside.setObjectName("aside")
        aside.setFixedWidth(260)
        rail = QVBoxLayout(aside)
        rail.addWidget(label("Сводка бота", "title"))
        self.summary = label("")
        rail.addWidget(self.summary)
        rail.addStretch()
        rail.addWidget(
            label(
                "Условия входа и выхода вычисляются независимо для каждой секции.",
                "muted",
            )
        )
        body.addWidget(aside)
        aside.setVisible(self.width() >= 1250)
        self.settings = SettingsEditor(cfg["settings"], self, strategy=cfg["strategy"])
        self.settings.hide()
        self.settings_pages = [self.settings.widget(i) for i in range(4)]
        # Transfer complete scroll pages. Moving their content directly leaves
        # QScrollArea with a dangling owned widget in the native Qt object tree.
        while self.settings.count():
            self.settings.removeTab(0)
        for page in self.settings_pages:
            page.setParent(self)
            page.hide()
        self.sections = SectionsEditor(
            cfg["sections"],
            lambda: self.settings.value_data(),
            strategy=cfg["strategy"],
        )
        self._basic()
        self._coins()
        self._signals()
        self._orders()
        self._exits()
        self._review()
        self.steps.currentRowChanged.connect(self.pages.setCurrentIndex)
        self.steps.currentRowChanged.connect(self.update_summary)
        self.steps.setCurrentRow(0)
        footer = QHBoxLayout()
        self.error = label("", "error")
        root.addWidget(self.error)
        footer.addWidget(button("Закрыть" if read_only else "Отмена", self.reject))
        if not read_only:
            footer.addWidget(button("Сохранить черновик", self.save_draft))
        footer.addStretch()
        footer.addWidget(
            button(
                "Назад",
                lambda: self.steps.setCurrentRow(max(0, self.steps.currentRow() - 1)),
            )
        )
        footer.addWidget(
            button(
                "Далее",
                lambda: self.steps.setCurrentRow(min(5, self.steps.currentRow() + 1)),
            )
        )
        self.save = button("Сохранить бота", self.commit, "primary")
        self.save.setVisible(not read_only)
        footer.addWidget(self.save)
        root.addLayout(footer)
        if read_only:
            for i in range(self.pages.count()):
                self.pages.widget(i).setEnabled(False)
        self.summary_timer = QTimer(self)
        self.summary_timer.setSingleShot(True)
        self.summary_timer.setInterval(120)
        self.summary_timer.timeout.connect(self.update_summary)
        self.finished.connect(self.summary_timer.stop)
        for kind, signal_name in (
            (QLineEdit, "textChanged"),
            (QComboBox, "currentIndexChanged"),
            (QSpinBox, "valueChanged"),
            (QDoubleSpinBox, "valueChanged"),
            (QCheckBox, "toggled"),
        ):
            for widget in self.findChildren(kind):
                getattr(widget, signal_name).connect(self.queue_summary)

    def queue_summary(self, *args):
        self.summary_timer.start()

    def closeEvent(self, event):
        self.summary_timer.stop()
        super().closeEvent(event)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "aside"):
            self.aside.setVisible(self.width() >= 1250)

    def page(self, title):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setSpacing(16)
        layout.addWidget(label(title, "title"))
        self.steps.addItem(f"{self.steps.count() + 1}   {title}")
        self.pages.addWidget(scroll(page))
        return layout

    def _basic(self):
        layout = self.page("Основное")
        w = QWidget()
        form = QFormLayout(w)
        self.name = QLineEdit(self.cfg["name"])
        self.name.setObjectName("botName")
        form.addRow("Название бота", self.name)
        form.addRow("Режим", label("PAPER · виртуальные сделки на публичных данных"))
        form.addRow(
            "Биржа / источник",
            label(
                "Polymarket UP/DOWN + Binance spot для импульса"
                if self.cfg["strategy"] == "POLYMARKET"
                else "Bybit · USDT Futures"
            ),
        )
        self.reinvest = QCheckBox(
            "Реинвестировать часть чистой прибыли"
            if self.cfg["strategy"] == "VELES"
            else "Размер ставки от текущего капитала"
            if self.cfg["strategy"] == "POLYMARKET"
            else "Размер позиций от текущего капитала",
            w,
        )
        self.reinvest.setChecked(self.cfg["reinvest"])
        if self.cfg["strategy"] in ("GRID", "PUMP_DUMP"):
            self.reinvest.hide()
        else:
            form.addRow("Реинвестирование", self.reinvest)
        self.stop_after_deals = QCheckBox("Завершить работу после сделок")
        self.stop_after_deals.setChecked(self.cfg["stop_after_deals"])
        form.addRow("Завершение работы", self.stop_after_deals)
        layout.addWidget(w)
        layout.addWidget(
            label(
                "После первого завершения сделки бот отключит новые входы, дождётся остальных позиций и ожидающих сеток и остановится. При запуске с уже открытыми сделками новые входы отключаются сразу.",
                "muted",
            )
        )
        layout.addWidget(
            label(
                "Остановка сохраняет открытые PAPER-позиции, баланс и историю. После запуска бот продолжает работу с сохранённого состояния.",
                "muted",
            )
        )
        layout.addStretch()

    def _coins(self):
        layout = self.page("Монеты и депозит")
        form = QFormLayout()
        self.symbols = QLineEdit(", ".join(self.cfg["symbols"]))
        self.symbols.setObjectName("symbols")
        self.capital = spin(self.cfg["capital"], 0.01, 1e9)
        self.capital.setObjectName("capital")
        form.addRow("Монеты через запятую", self.symbols)
        form.addRow("Общий депозит бота, USDT", self.capital)
        layout.addLayout(form)
        layout.addWidget(
            button("Выбрать / добавить монеты", self.choose_coins, "secondary")
        )
        layout.addWidget(
            button(
                "Индивидуальные настройки монеты / секции", self.edit_coin, "secondary"
            )
        )
        layout.addWidget(
            label(
                "Общие настройки наследуются всеми монетами. Индивидуальные настройки можно сбросить к общим.",
                "muted",
            )
        )
        self.coin_overrides = deepcopy(self.cfg["coin_overrides"])
        self.finance_widget = self.settings.finance
        layout.addWidget(self.settings_pages[0], 1)
        self.settings_pages[0].show()

    def choose_coins(self):
        from .coin_picker import CoinPicker

        symbols = [
            s.strip().upper() for s in self.symbols.text().split(",") if s.strip()
        ]
        dialog = CoinPicker(self.cfg["strategy"], symbols, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.symbols.setText(", ".join(dialog.result_symbols))
            self.update_summary()

    def _signals(self):
        layout = self.page("Условия и секции")
        strategy = self.cfg["strategy"]
        if strategy in ("VELES", "EMA", "MACD", "BOLLINGER", "EMA_RSI_VOLUME"):
            layout.addWidget(self.sections)
        elif strategy == "GRID":
            self.grid = Fields(
                self.cfg["grid"],
                [
                    (
                        "side",
                        "Направление",
                        "choice",
                        [("LONG", "LONG"), ("SHORT", "SHORT")],
                    ),
                    ("levels", "Количество уровней", "int", (1, 100)),
                    ("spacing_pct", "Шаг уровней, %", "float", (0.001, 20)),
                    ("order_usdt", "Номинал ордера, USDT", "float", (0.01, 1e9)),
                    (
                        "take_profit_pct",
                        "Прибыль каждого уровня, %",
                        "float",
                        (0.001, 100),
                    ),
                    ("stop_loss_pct", "Стоп каждого уровня, %", "float", (0.001, 90)),
                ],
            )
            layout.addWidget(self.grid)
            layout.addStretch()
        elif strategy == "PUMP_DUMP":
            p = self.cfg["pump"]
            self.pump = Fields(
                p,
                [
                    ("window_minutes", "Окно импульса, минут", "int", (1, 30)),
                    ("move_pct", "Движение цены от, %", "float", (0.01, 100)),
                    ("volume_ratio", "Относительный объём от, ×", "float", (1, 1000)),
                    ("stake_usdt", "Номинал позиции, USDT", "float", (0.01, 1e9)),
                    (
                        "cooldown_seconds",
                        "Пауза после выхода, секунд",
                        "float",
                        (0, 86400),
                    ),
                ],
            )
            layout.addWidget(self.pump)
            self.pump_modes = {}
            self.pump_sides = {}
            row = QHBoxLayout()
            for key, title in [
                ("fast", "Быстрый отскок"),
                ("confirmed", "Подтверждённый отскок"),
            ]:
                c = QCheckBox(title)
                c.setChecked(key in p["modes"])
                row.addWidget(c)
                self.pump_modes[key] = c
            layout.addLayout(row)
            row = QHBoxLayout()
            for side in ("LONG", "SHORT"):
                c = QCheckBox(side)
                c.setChecked(side in p["sides"])
                row.addWidget(c)
                self.pump_sides[side] = c
            layout.addLayout(row)
            layout.addStretch()
        else:
            p = self.cfg["polymarket"]
            self.poly = Fields(
                p,
                [
                    (
                        "impulse_mode",
                        "Единица импульса",
                        "choice",
                        [("Процент", "percent"), ("Изменение цены в USD", "usd")],
                    ),
                    ("impulse", "Порог импульса", "float", (0.000001, 1e9)),
                    (
                        "timing",
                        "Когда входить",
                        "choice",
                        [
                            ("В любое время", "anytime"),
                            ("Перед завершением", "before_close"),
                        ],
                    ),
                    (
                        "seconds_before_close",
                        "Окно до конца рынка, секунд",
                        "float",
                        (1, 3600),
                    ),
                    (
                        "min_seconds_left",
                        "Не входить ближе к концу, секунд",
                        "float",
                        (0, 3600),
                    ),
                    ("ask_min", "ASK от", "float", (0.0001, 0.9999)),
                    ("ask_max", "ASK до", "float", (0.0001, 0.9999)),
                    ("stake_pct", "Ставка от депозита, %", "float", (0.001, 100)),
                    (
                        "fee_mode",
                        "Комиссия",
                        "choice",
                        [
                            ("По публичной формуле рынка", "public"),
                            ("Своя оценка", "estimate"),
                        ],
                    ),
                    ("fee_rate", "Своя оценка: доля от стоимости", "float", (0, 1)),
                ],
            )
            layout.addWidget(scroll(self.poly))
            self.durations = {}
            row = QHBoxLayout()
            for value, title in [(300, "5 минут"), (900, "15 минут"), (3600, "1 час")]:
                c = QCheckBox(title)
                c.setChecked(value in p["durations"])
                row.addWidget(c)
                self.durations[value] = c
            layout.addLayout(row)
            self.poly_overrides = deepcopy(p["overrides"])
            layout.addWidget(
                button("Настройки монеты × длительности рынка", self.edit_poly_market)
            )
            layout.addWidget(
                label(
                    "В списке выбираются длительности. Бот входит в найденный активный рынок. Итог и схема комиссии берутся из публичных данных; оценка комиссии применяется только при её явном выборе.",
                    "muted",
                )
            )

    def _orders(self):
        layout = self.page("Ордера и DCA")
        if self.cfg["strategy"] in (
            "VELES",
            "EMA",
            "MACD",
            "BOLLINGER",
            "EMA_RSI_VOLUME",
        ):
            widget = self.settings_pages[1]
            layout.addWidget(widget)
            widget.show()
        else:
            layout.addWidget(
                label(
                    "Параметры ордеров этой стратегии находятся в разделе «Условия и секции»."
                )
            )
            layout.addStretch()

    def _exits(self):
        layout = self.page("Выход и защита")
        strategy = self.cfg["strategy"]
        if strategy in ("VELES", "EMA", "MACD", "BOLLINGER", "EMA_RSI_VOLUME"):
            tabs = QTabWidget()
            tabs.addTab(self.settings_pages[2], "Тейк-профит")
            tabs.addTab(self.settings_pages[3], "Стоп-лосс")
            layout.addWidget(tabs)
        elif strategy == "PUMP_DUMP":
            tabs = QTabWidget()
            self.pump_exit = {}
            for key, title in [
                ("fast", "Быстрый отскок"),
                ("confirmed", "Подтверждённый отскок"),
            ]:
                editor = Fields(
                    self.cfg["pump"][key],
                    [
                        (
                            "rebound_pct",
                            "Подтверждающий отскок, %",
                            "float",
                            (0.001, 100),
                        ),
                        ("tp_pct", "Тейк-профит, %", "float", (0.001, 10000)),
                        ("sl_pct", "Стоп-лосс, %", "float", (0.001, 90)),
                        (
                            "max_hold_seconds",
                            "Максимальное время позиции, секунд",
                            "float",
                            (1, 1e6),
                        ),
                    ],
                )
                self.pump_exit[key] = editor
                tabs.addTab(editor, title)
            layout.addWidget(tabs)
        elif strategy == "POLYMARKET":
            layout.addWidget(
                label(
                    "Позиция удерживается до официального расчёта исхода. Истечение времени само по себе не определяет победителя. Повторный вход в тот же рынок блокируется."
                )
            )
            layout.addStretch()
        else:
            layout.addWidget(
                label("Тейк-профит и стоп каждого уровня указаны в настройках GRID.")
            )
            layout.addStretch()

    def _review(self):
        layout = self.page("Проверка")
        self.review = label("")
        layout.addWidget(self.review)
        self.preview_selectors = QWidget()
        selection = QHBoxLayout(self.preview_selectors)
        self.preview_coin = combo([(s, s) for s in self.cfg["symbols"]])
        self.preview_section = combo(
            [(s["label"], s["id"]) for s in self.cfg["sections"]]
        )
        for selector in (self.preview_coin, self.preview_section):
            selector.setSizeAdjustPolicy(
                QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
            )
            selector.setMinimumContentsLength(5)
        selection.addWidget(label("Монета"))
        selection.addWidget(self.preview_coin, 1)
        selection.addWidget(label("Секция"))
        selection.addWidget(self.preview_section, 1)
        layout.addWidget(self.preview_selectors)
        self.preview = QTableWidget(0, 4)
        self.preview.setHorizontalHeaderLabels(
            ["Ордер", "Условная цена", "Объём, %", "Номинал, USDT"]
        )
        self.preview.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        layout.addWidget(self.preview)
        self.preview_note = label(
            "Расчёт сетки показан относительно условной цены 100. Исполнение PAPER использует текущие котировки, заданное проскальзывание и комиссии.",
            "muted",
        )
        layout.addWidget(self.preview_note)
        self.preview_coin.currentIndexChanged.connect(self.update_summary)
        self.preview_section.currentIndexChanged.connect(self.update_summary)

    def data(self):
        cfg = deepcopy(self.cfg)
        cfg.update(
            name=self.name.text().strip(),
            symbols=[
                s.strip().upper() for s in self.symbols.text().split(",") if s.strip()
            ],
            capital=self.capital.value(),
            reinvest=self.reinvest.isChecked(),
            stop_after_deals=self.stop_after_deals.isChecked(),
            settings=self.settings.value_data(),
            sections=self.sections.value_data(),
            coin_overrides=deepcopy(self.coin_overrides),
        )
        if hasattr(self, "grid"):
            cfg["grid"] = self.grid.value_data()
        if hasattr(self, "pump"):
            cfg["pump"] = self.pump.value_data()
            cfg["pump"]["modes"] = [
                k for k, c in self.pump_modes.items() if c.isChecked()
            ]
            cfg["pump"]["sides"] = [
                k for k, c in self.pump_sides.items() if c.isChecked()
            ]
            for k, v in self.pump_exit.items():
                cfg["pump"][k] = v.value_data()
        if hasattr(self, "poly"):
            cfg["polymarket"] = self.poly.value_data()
            cfg["polymarket"]["durations"] = [
                k for k, c in self.durations.items() if c.isChecked()
            ]
            cfg["polymarket"]["overrides"] = deepcopy(self.poly_overrides)
        return cfg

    def update_summary(self, *args):
        try:
            c = self.data()
            s = c["settings"]
            symbols = ", ".join(c["symbols"][:6])
            if len(c["symbols"]) > 6:
                symbols += f" и ещё {len(c['symbols']) - 6}"
            summary = f"{c['name'] or 'Новый бот'}\n\n{STRATEGY_NAMES[c['strategy']]} · PAPER\n\nМонет: {len(c['symbols'])}\n{symbols}\n\nДепозит: {c['capital']:g} USDT"
            kind = c["strategy"]
            has_grid = kind not in ("POLYMARKET", "GRID", "PUMP_DUMP")
            if kind == "POLYMARKET":
                p = c["polymarket"]
                durations = ", ".join(f"{m // 60} мин" for m in p["durations"])
                summary += f"\n\nРынки: {durations}\nСтавка: {p['stake_pct']:g}%\nASK: {p['ask_min']:g}–{p['ask_max']:g}\nОфициальный исход"
            elif kind == "GRID":
                g = c["grid"]
                summary += f"\n\n{g['side']} · уровней {g['levels']}\nШаг: {g['spacing_pct']:g}%\nОрдер: {g['order_usdt']:g} USDT\nTP: {g['take_profit_pct']:g}%\nSL: {g['stop_loss_pct']:g}%"
            elif kind == "PUMP_DUMP":
                p = c["pump"]
                summary += f"\n\nИмпульс: {p['move_pct']:g}% / {p['window_minutes']} мин\nОбъём: {p['volume_ratio']:g}×\nОрдер: {p['stake_usdt']:g} USDT\nСтороны: {', '.join(p['sides'])}\nРежимов отскока: {len(p['modes'])}"
            else:
                mode = {"simple": "Простая", "custom": "Своя", "signal": "По сигналу"}[
                    s["orders"]["mode"]
                ]
                summary += f"\n\nМаржа: {s['margin_mode']}\nПлечо: {s['leverage']:g}×\nСекций: {len(c['sections'])}\nСетка: {mode}\nПерекрытие: {s['orders']['coverage_pct']:g}%"
            self.summary.setText(summary)
            self.preview_selectors.setVisible(has_grid)
            self.preview.setVisible(has_grid)
            self.preview_note.setVisible(has_grid)
            self.review.setText(
                "Проверьте параметры и сохраните бота. Он появится в MY BOTS и будет готов к отдельному запуску."
            )
            if has_grid:
                self.update_grid_preview(c)
        except (ValueError, KeyError, TypeError) as e:
            self.summary.setText(str(e))

    def update_grid_preview(self, cfg):
        def choices(selector, items):
            if items == [
                (selector.itemText(i), selector.itemData(i))
                for i in range(selector.count())
            ]:
                return
            previous = selector.currentData()
            blocked = selector.blockSignals(True)
            selector.clear()
            for title, data in items:
                selector.addItem(title, data)
            index = selector.findData(previous)
            selector.setCurrentIndex(index if index >= 0 else 0)
            selector.blockSignals(blocked)

        choices(self.preview_coin, [(s, s) for s in cfg["symbols"]])
        choices(self.preview_section, [(s["label"], s["id"]) for s in cfg["sections"]])
        symbol = self.preview_coin.currentData()
        original = next(
            (
                s
                for s in cfg["sections"]
                if s["id"] == self.preview_section.currentData()
            ),
            None,
        )
        if not symbol or original is None:
            self.preview.setRowCount(0)
            self.review.setText("Выберите монету и добавьте секцию для расчёта сетки")
            return
        section = coin_section(cfg, symbol, original)
        settings = effective(cfg, symbol, original)
        rows = plan(settings["orders"], section["side"], 100)
        margin = cfg["capital"] * settings["allocation_pct"] / 100
        budget = margin * settings["leverage"]
        self.preview.setRowCount(len(rows))
        for i, row in enumerate(rows):
            for j, value in enumerate(
                (
                    str(i + 1),
                    f"{row['price']:.8g}",
                    f"{row['weight'] * 100:.5g}",
                    f"{budget * row['weight']:.4f}",
                )
            ):
                self.preview.setItem(i, j, QTableWidgetItem(value))
        text = f"{symbol} · {section['label']} · {section['side']}\nМаржа из исходного депозита: {margin:g} USDT; номинал сетки с плечом: {budget:g} USDT."
        if settings["stop"]["mode"] in ("percent", "both"):
            if settings["orders"]["mode"] == "signal":
                text += "\nSL рассчитывается после фактического последнего усреднения."
            else:
                stop = percent_stop_price(
                    {"settings": settings, "side": section["side"], "orders": rows}
                )
                text += f"\nУсловный SL: {stop:.8g} после исполнения сетки."
        if not section["enabled"] or settings["disabled"]:
            text += "\nНовые входы этой секции отключены."
        self.review.setText(text)

    def edit_coin(self):
        symbols = [
            s.strip().upper() for s in self.symbols.text().split(",") if s.strip()
        ]
        if not symbols:
            return
        chooser = QDialog(self)
        chooser.setWindowTitle("Индивидуальные настройки")
        dialog_size(chooser, 1100, 800)
        layout = QVBoxLayout(chooser)
        coin = combo([(s, s) for s in symbols])
        coin.setObjectName("coinChoice")
        layout.addWidget(coin)
        tabs = QTabWidget()
        tabs.setObjectName("coinSettingsTabs")
        layout.addWidget(tabs)
        state = {"symbol": None}
        draft = deepcopy(self.coin_overrides)

        def save_current():
            if state["symbol"] is None:
                return
            if individual.isChecked():
                values = deepcopy(draft.get(state["symbol"], {}))
                values.update(
                    {
                        "settings": difference(
                            self.settings.value_data(), editor.value_data()
                        ),
                        "sections": deepcopy(state.get("section_overrides", {})),
                    }
                )
                if state.get("parameters_editor"):
                    params = state["parameters_editor"].value_data()
                    for key, child in state.get("exit_editors", {}).items():
                        params[key] = child.value_data()
                    values["parameters"] = difference(state["base_parameters"], params)
                draft[state["symbol"]] = values
            else:
                draft.pop(state["symbol"], None)

        individual = QCheckBox("Индивидуальные параметры монеты")
        individual.setObjectName("coinIndividual")
        layout.addWidget(individual)
        editor = None

        def load():
            nonlocal editor
            save_current()
            sym = coin.currentData()
            state["symbol"] = sym
            over = draft.get(sym, {})
            while tabs.count():
                old = tabs.widget(0)
                tabs.removeTab(0)
                old.deleteLater()
            editor = SettingsEditor(
                merge(self.settings.value_data(), over.get("settings", {})),
                strategy=self.cfg["strategy"],
            )
            tabs.addTab(editor, "Настройки монеты")
            individual.setChecked(bool(over))
            tabs.setEnabled(individual.isChecked())
            state["section_overrides"] = deepcopy(over.get("sections", {}))
            state["parameters_editor"] = None
            state["exit_editors"] = {}
            block = {"GRID": "grid", "PUMP_DUMP": "pump", "POLYMARKET": "poly"}.get(
                self.cfg["strategy"]
            )
            if block:
                main = getattr(self, block)
                params = main.value_data()
                state["base_parameters"] = deepcopy(params)
                values = merge(params, over.get("parameters", {}))
                local = Fields(values, main.specs)
                state["parameters_editor"] = local
                tabs.addTab(scroll(local), "Параметры стратегии")
                for key, source in getattr(self, "pump_exit", {}).items():
                    child = Fields(values[key], source.specs)
                    state["exit_editors"][key] = child
                    tabs.addTab(scroll(child), key)
            section_page = QWidget()
            v = QVBoxLayout(section_page)
            selection = combo(
                [(s["label"], s["id"]) for s in self.sections.value_data()]
            )
            selection.setObjectName("coinSectionChoice")
            v.addWidget(selection)

            def change_section():
                sec = next(
                    s
                    for s in self.sections.value_data()
                    if s["id"] == selection.currentData()
                )
                patch = state["section_overrides"].get(sec["id"], {})
                current_coin = deepcopy(draft.get(sym, {}))
                current_coin["sections"] = state["section_overrides"]
                local = coin_section({"coin_overrides": {sym: current_coin}}, sym, sec)
                local["overrides"] = patch.get("settings", {})
                child = SectionEditor(
                    local,
                    merge(editor.value_data(), sec.get("overrides", {})),
                    strategy=self.cfg["strategy"],
                )
                if confirm_dialog(
                    child, "Настройки " + sym + " / " + sec["label"], chooser
                ):
                    changed = child.value_data()
                    changes = {}
                    if changed["overrides"]:
                        changes["settings"] = changed["overrides"]
                    for key in ("entry", "exit", "side", "enabled", "label"):
                        inherited = (
                            current_coin.get(key, sec[key])
                            if key in ("entry", "exit")
                            else sec[key]
                        )
                        if changed[key] != inherited:
                            changes[key] = changed[key]
                    if changes:
                        state["section_overrides"][sec["id"]] = changes
                    else:
                        state["section_overrides"].pop(sec["id"], None)
                    individual.setChecked(True)

            edit_section = button("Настроить секцию этой монеты", change_section)
            edit_section.setObjectName("editCoinSection")
            v.addWidget(edit_section)
            v.addWidget(
                button(
                    "Сбросить секции к общим",
                    lambda: state.update(section_overrides={}),
                )
            )
            v.addStretch()
            if self.cfg["strategy"] not in ("POLYMARKET", "GRID", "PUMP_DUMP"):
                tabs.addTab(section_page, "Диапазоны и сигналы")
            else:
                section_page.deleteLater()

        coin.currentIndexChanged.connect(load)
        individual.toggled.connect(tabs.setEnabled)
        load()

        def apply_to(targets):
            save_current()
            for target in targets:
                if state["symbol"] in draft:
                    draft[target] = deepcopy(draft[state["symbol"]])
                else:
                    draft.pop(target, None)

        def apply_selected():
            selection = QListWidget()
            selection.addItems(symbols)
            selection.setSelectionMode(QAbstractItemView.SelectionMode.MultiSelection)
            if confirm_dialog(
                selection, "Применить параметры к выбранным монетам", chooser
            ):
                apply_to([item.text() for item in selection.selectedItems()])

        layout.addWidget(
            button("Применить текущие параметры к выбранным монетам", apply_selected)
        )
        layout.addWidget(
            button(
                "Применить текущие параметры ко всем монетам", lambda: apply_to(symbols)
            )
        )
        controls = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save
            | QDialogButtonBox.StandardButton.Cancel
        )
        layout.addWidget(controls)
        controls.accepted.connect(chooser.accept)
        controls.rejected.connect(chooser.reject)
        if chooser.exec() == QDialog.DialogCode.Accepted:
            save_current()
            self.coin_overrides = draft
            self.update_summary()
        chooser.deleteLater()

    def edit_poly_market(self):
        cfg = self.data()
        choices = [
            f"{s}:{d}" for s in cfg["symbols"] for d in cfg["polymarket"]["durations"]
        ]
        if not choices:
            return
        from PySide6.QtWidgets import QInputDialog

        selected, ok = QInputDialog.getItem(
            self, "Рынок", "Монета:длительность в секундах", choices, editable=False
        )
        if not ok:
            return
        symbol, duration = selected.split(":")
        base = merge(
            self.poly.value_data(),
            self.coin_overrides.get(symbol, {}).get("parameters", {}),
        )
        specs = [("disabled", "Отключить эту комбинацию", "bool", None)] + list(
            self.poly.specs
        )
        fields = Fields(merge(base, self.poly_overrides.get(selected, {})), specs)
        fields.layout().addRow(
            button(
                "Сбросить комбинацию к параметрам монеты",
                lambda: fields.set_values({k: base[k] for k, *_ in specs}),
            )
        )

        def validate_market():
            candidate = defaults("POLYMARKET")
            candidate.update(name="Проверка параметров рынка", symbols=[symbol])
            candidate["polymarket"] = fields.value_data()
            candidate["polymarket"].update(durations=[int(duration)], overrides={})
            validate(candidate)

        if confirm_dialog(
            fields, "Настройки " + selected, self, validator=validate_market
        ):
            patch = difference(base, fields.value_data())
            if patch:
                self.poly_overrides[selected] = patch
            else:
                self.poly_overrides.pop(selected, None)

    def save_draft(self):
        if self.draft_path:
            try:
                atomic_json(self.draft_path, self.data())
                self.error.setText("Черновик сохранён")
            except (OSError, ValueError) as e:
                self.error.setText(str(e))

    def commit(self):
        try:
            self.result_config = validate(self.data())
        except (ValueError, KeyError, TypeError) as e:
            self.error.setText(str(e))
            return
        self.accept()
