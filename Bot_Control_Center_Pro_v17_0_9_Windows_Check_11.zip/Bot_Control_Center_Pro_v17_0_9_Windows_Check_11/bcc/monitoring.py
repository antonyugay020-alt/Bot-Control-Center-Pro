"""Read-only modeless monitoring across all strategy folders."""

import time
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QDialog,
    QHBoxLayout,
    QHeaderView,
    QLineEdit,
    QTabWidget,
    QToolBar,
    QVBoxLayout,
)

from .config import STRATEGY_NAMES
from .market_clock import quote_is_recent
from .storage import Store
from .trading import available_margin, equity, mark_pnl
from .widgets import button, dialog_size, label

ACTIVE = {"Работает", "Запуск", "Остановка", "Завершает сделки"}


def snapshot_all(repo, life, include_stopped=False):
    records = []
    for folder, cfg in repo.list():
        row = dict(path=str(folder), config=cfg, state=None, process=None, error="")
        try:
            row["status"] = life.status(folder)
            row["process"] = life.active_snapshot(folder)
            if cfg.get("invalid"):
                raise ValueError(cfg["invalid"])
            if (folder / "paper.sqlite").exists():
                row["state"] = Store(folder).read(include_charts=False)
            if row["status"] == "Остановлен":
                row["error"] = life.last_error(folder)
                if row["error"]:
                    row["status"] = "Остановлен с ошибкой"
                state = row["state"] or {}
                if (
                    not include_stopped
                    and not row["error"]
                    and not state.get("positions")
                    and not state.get("pending")
                ):
                    continue
        except Exception as exc:
            row.setdefault("status", "Ошибка")
            row["error"] = str(exc)
        records.append(row)
    return records


def position_pnl(state, position, now):
    quote = state["marks"].get(position.get("token", position["symbol"]))
    if not quote_is_recent(quote, now=now):
        return None
    if position.get("kind") == "POLYMARKET":
        return position["shares"] * quote["bid"] - position["cost"]
    return mark_pnl(
        position, quote["bid"] if position["side"] == "LONG" else quote["ask"]
    )


def number(value, signed=False):
    return "—" if value is None else format(value, "+.4f" if signed else ".4f")


class RunningBotsWindow(QDialog):
    open_bot = Signal(str)

    def __init__(self, repo, life, parent=None, refresh_ms=2000):
        super().__init__(parent)
        from .ui import table

        self.repo, self.life = repo, life
        self.records = []
        self.setObjectName("runningBotsMonitor")
        self.setWindowTitle("Монитор всех ботов · PAPER")
        self.setModal(False)
        dialog_size(self, 1500, 950)
        layout = QVBoxLayout(self)
        layout.addWidget(label("Работающие боты и открытые позиции", "headline"))
        layout.addWidget(
            label(
                "Счета PAPER независимы. Просмотр не меняет настройки и торговлю.",
                "muted",
            )
        )
        filters = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Бот, стратегия или монета")
        filters.addWidget(self.search, 1)
        self.include_stopped = QCheckBox("Также остановленные без позиций")
        filters.addWidget(self.include_stopped)
        layout.addLayout(filters)
        self.summary = label("", "title")
        layout.addWidget(self.summary)
        self.alert = label("", "title")
        self.alert.setWordWrap(True)
        self.alert.hide()
        layout.addWidget(self.alert)
        self.bots = table(
            [
                "Бот",
                "Стратегия",
                "Монеты",
                "Процесс",
                "Heartbeat, с",
                "Баланс",
                "Капитал",
                "Своб. маржа",
                "Позиции",
                "Ожид. сетки",
                "Realized PnL",
                "Unrealized PnL",
                "Макс. DD, %",
                "Сигналы / ошибки",
            ]
        )
        layout.addWidget(self.bots, 1)
        self.tabs = QTabWidget()
        self.positions = table(
            [
                "Бот",
                "Стратегия",
                "Монета",
                "Секция",
                "Сторона",
                "Количество",
                "Средняя",
                "Unrealized PnL",
                "DCA сейчас",
                "Состояние",
                "Открыта (местн.)",
            ]
        )
        self.signals = table(
            ["Бот", "Монета", "Секция", "Индикатор / TF", "Значения", "Причина"]
        )
        self.history = table(
            [
                "Время (местн.)",
                "Бот",
                "Монета",
                "Секция",
                "Действие",
                "Net PnL",
                "Причина",
            ]
        )
        for widget, title in [
            (self.positions, "Все позиции"),
            (self.signals, "Все сигналы"),
            (self.history, "Последние исполнения"),
        ]:
            self.tabs.addTab(widget, title)
        layout.addWidget(self.tabs, 1)
        for widget in [self.bots, self.positions, self.signals, self.history]:
            widget.horizontalHeader().setSectionResizeMode(
                QHeaderView.ResizeMode.ResizeToContents
            )
            widget.horizontalHeader().setStretchLastSection(True)
        actions = QToolBar()
        actions.setMovable(False)
        actions.addWidget(
            button("Открыть выбранного бота", self.open_selected, "primary")
        )
        actions.addWidget(button("Обновить", self.refresh))
        actions.addWidget(button("Закрыть монитор", self.close))
        layout.addWidget(actions)
        self.updated = label("", "muted")
        layout.addWidget(self.updated)
        self.bots.doubleClicked.connect(self.open_selected)
        self.search.textChanged.connect(self.refresh)
        self.include_stopped.toggled.connect(self.refresh)
        self.tabs.currentChanged.connect(self.refresh)
        self.timer = QTimer(self)
        self.timer.setInterval(refresh_ms)
        self.timer.timeout.connect(self.refresh)

    def showEvent(self, event):
        self.refresh()
        self.timer.start()
        super().showEvent(event)

    def closeEvent(self, event):
        self.timer.stop()
        super().closeEvent(event)

    def open_selected(self, *args):
        item = self.bots.item(self.bots.currentRow(), 0)
        if item is not None:
            self.open_bot.emit(item.data(Qt.ItemDataRole.UserRole))

    def refresh(self, *args):
        from .ui import populate

        now = time.time()
        records = snapshot_all(self.repo, self.life, self.include_stopped.isChecked())
        query = self.search.text().casefold().strip()
        self.records = [
            r
            for r in records
            if not query
            or query
            in (
                r["config"].get("name", "")
                + " "
                + r["config"].get("strategy", "")
                + " "
                + " ".join(r["config"].get("symbols", []))
            ).casefold()
        ]
        rows, keys, positions, position_keys, signals, executions = (
            [],
            [],
            [],
            [],
            [],
            [],
        )
        active = sum(r["status"] in ACTIVE for r in records)
        open_count = sum(len(r["state"]["positions"]) for r in records if r["state"])
        errors = 0
        issues = []
        for record in self.records:
            cfg, state = record["config"], record["state"]
            name, strategy = cfg.get("name", "?"), cfg.get("strategy", "?")
            process = record["process"] or {}
            age = (
                max(0, now - process["heartbeat"]) if process.get("heartbeat") else None
            )
            value, unknown = equity(state) if state else (None, True)
            upnl = None
            if state and not unknown:
                upnl = sum(
                    position_pnl(state, p, now) or 0
                    for p in state["positions"].values()
                )
            reasons = [
                d.get("reason", "")
                for ds in (state or {}).get("diagnostics", {}).values()
                for d in ds
            ]
            issue = record["error"] or (
                "Нет свежего heartbeat" if age is not None and age > 15 else ""
            )
            errors += bool(issue)
            if issue:
                issues.append(name + ": " + issue)
            rows.append(
                [
                    name,
                    STRATEGY_NAMES.get(strategy, strategy),
                    ", ".join(cfg.get("symbols", [])[:3])
                    + (
                        f" · ещё {len(cfg['symbols']) - 3}"
                        if len(cfg.get("symbols", [])) > 3
                        else ""
                    ),
                    record["status"],
                    number(age),
                    number(state["cash"] if state else None),
                    number(None if unknown else value),
                    number(available_margin(state) if state and not unknown else None),
                    len(state["positions"]) if state else 0,
                    len(state["pending"]) if state else 0,
                    number(state.get("realized", 0) if state else None, True),
                    number(upnl, True),
                    number(state.get("max_drawdown", 0) if state else None),
                    issue or " · ".join(dict.fromkeys(reasons)),
                ]
            )
            keys.append(record["path"])
            for key, p in (state or {}).get("positions", {}).items():
                positions.append(
                    [
                        name,
                        STRATEGY_NAMES.get(strategy, strategy),
                        p["symbol"],
                        p["section"],
                        p["side"],
                        f"{p['qty']:.8g}",
                        f"{p['average']:.8g}",
                        number(position_pnl(state, p, now), True),
                        p.get("dca_fills", 0),
                        (
                            "Сопровождение приостановлено"
                            if record["status"] not in ACTIVE
                            else p.get("exit_pending", {}).get("reason", "Открыта")
                        ),
                        datetime.fromtimestamp(p["opened"])
                        .astimezone()
                        .strftime("%Y-%m-%d %H:%M:%S"),
                    ]
                )
                position_keys.append(record["path"] + ":" + key)
            for sym, ds in (state or {}).get("diagnostics", {}).items():
                for d in ds:
                    conditions = d.get("conditions") or [None]
                    for c in conditions:
                        values = (
                            f"{c['value']:.6g} {c.get('comparison', '')} {c.get('reference', 0):.6g}"
                            if c and c.get("available")
                            else "—"
                        )
                        signals.append(
                            [
                                name,
                                sym,
                                d.get("section", ""),
                                f"{c['indicator']} / {c['timeframe']}m" if c else "—",
                                values,
                                d.get("reason", ""),
                            ]
                        )
            if state and self.tabs.currentWidget() is self.history:
                try:
                    executions.extend(
                        (e, name) for e in Store(Path(record["path"])).history(100)
                    )
                except Exception as exc:
                    signals.append([name, "—", "История", "—", "—", str(exc)])
        populate(self.bots, rows, keys)
        self.alert.setText("Причины ошибок: " + " · ".join(issues[:3]))
        self.alert.setVisible(bool(issues))
        symbols_by_path = {
            r["path"]: r["config"].get("symbols", []) for r in self.records
        }
        for i in range(self.bots.rowCount()):
            path = self.bots.item(i, 0).data(Qt.ItemDataRole.UserRole)
            self.bots.item(i, 2).setToolTip(", ".join(symbols_by_path.get(path, [])))
        populate(self.positions, positions, position_keys)
        populate(self.signals, signals)
        executions.sort(key=lambda row: row[0]["at"], reverse=True)
        populate(
            self.history,
            [
                [
                    datetime.fromtimestamp(e["at"])
                    .astimezone()
                    .strftime("%Y-%m-%d %H:%M:%S"),
                    name,
                    e["symbol"],
                    e["section"],
                    e["action"],
                    number(e.get("net_pnl", 0), True),
                    e.get("reason", ""),
                ]
                for e, name in executions[:1000]
            ],
            [e["id"] for e, _ in executions[:1000]],
        )
        self.summary.setText(
            f"Работающих: {active} · Позиций: {open_count} · Показано ботов: {len(rows)} · Ошибок / heartbeat: {errors}"
        )
        self.updated.setText(
            "Обновлено: "
            + datetime.now().astimezone().strftime("%H:%M:%S")
            + " · «—» означает отсутствие свежей оценки"
        )
