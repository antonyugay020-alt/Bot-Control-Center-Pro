"""Consoleless Windows launch with a visible, recoverable error report."""

import sys
import traceback
from pathlib import Path

try:
    from app import main

    sys.exit(main())
except Exception:
    path = Path(__file__).resolve().parent / "startup.log"
    path.write_text(traceback.format_exc(), encoding="utf-8")
    if sys.platform == "win32":
        import ctypes

        ctypes.windll.user32.MessageBoxW(
            None,
            "Не удалось открыть программу. Подробности: "
            + str(path)
            + "\n\nУстановите зависимости через INSTALL.bat.",
            "Bot Control Center Pro",
            0x10,
        )
    else:
        raise
