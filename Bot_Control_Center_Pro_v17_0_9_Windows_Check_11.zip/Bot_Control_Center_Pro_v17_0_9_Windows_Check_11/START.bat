@echo off
cd /d "%~dp0"
if exist "%~dp0.check_venv\Scripts\pythonw.exe" (
    start "" "%~dp0.check_venv\Scripts\pythonw.exe" "%~dp0launch.pyw"
    exit /b 0
)
start "" pyw -3 "%~dp0launch.pyw"
