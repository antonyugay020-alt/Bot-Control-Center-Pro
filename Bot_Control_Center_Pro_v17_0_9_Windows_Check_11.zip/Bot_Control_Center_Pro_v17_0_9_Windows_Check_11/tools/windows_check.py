"""One Windows check: isolated dependencies, native checks, app, report ZIP."""

import argparse
import json
import os
import platform
import subprocess
import sys
import time
import traceback
import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def run_step(name, command, output, *, timeout=None):
    print(name + "...", flush=True)
    started = time.monotonic()
    with (output / (name + ".log")).open("w", encoding="utf-8") as stream:
        try:
            result = subprocess.run(
                command,
                cwd=ROOT,
                stdout=stream,
                stderr=subprocess.STDOUT,
                timeout=timeout,
                check=False,
            )
            return dict(
                step=name,
                exit_code=result.returncode,
                seconds=round(time.monotonic() - started, 3),
            )
        except subprocess.TimeoutExpired:
            return dict(step=name, exit_code=None, error="Timeout")


def report_archive(output, destination):
    # Explicit inputs: never sweep the installation, old bots, venv or credentials.
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(output.rglob("*")):
            if path.is_file() and not path.is_symlink():
                archive.write(
                    path, output.name + "/" + path.relative_to(output).as_posix()
                )
    return destination


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--automated-only", action="store_true")
    args = parser.parse_args(argv)
    stamp = datetime.now().astimezone().strftime("%Y%m%d_%H%M%S_%f")
    output = ROOT / "verification_reports" / ("check_" + stamp)
    output.mkdir(parents=True)
    archive = ROOT / ("BCC_VALIDATION_RESULTS_" + stamp + ".zip")
    workspace = ROOT / "check_workspaces" / stamp
    report = dict(
        started=datetime.now().astimezone().isoformat(),
        platform=platform.platform(),
        python=sys.version,
        steps=[],
        release_ready=False,
        manual_acceptance="NOT_CONFIRMED",
        workspace=str(workspace),
    )
    exit_code = 1
    python = None
    app_started = False
    try:
        if os.name != "nt":
            report.update(status="BLOCKED", error="Native Windows is required")
            return 2
        if sys.version_info < (3, 10):
            raise RuntimeError("Python 3.10+ is required; Python 3.12 is recommended")
        os.environ["QT_QPA_PLATFORM"] = "windows"
        venv = ROOT / ".check_venv"
        step = run_step(
            "environment",
            [sys.executable, "-m", "venv", str(venv)],
            output,
            timeout=120,
        )
        report["steps"].append(step)
        if step["exit_code"] != 0:
            raise RuntimeError(
                "Cannot create isolated Python environment; see environment.log"
            )
        python = venv / "Scripts" / "python.exe"
        step = run_step(
            "dependencies",
            [
                str(python),
                "-m",
                "pip",
                "install",
                "-r",
                str(ROOT / "requirements-dev.txt"),
            ],
            output,
            timeout=900,
        )
        report["steps"].append(step)
        if step["exit_code"] != 0:
            raise RuntimeError("Dependency installation failed; see dependencies.log")
        step = run_step(
            "automated",
            [
                str(python),
                "tools/verify_windows.py",
                "--output",
                str(output / "automated"),
            ],
            output,
            timeout=600,
        )
        report["steps"].append(step)
        print(
            "Automated checks: "
            + (
                "PASS"
                if step["exit_code"] == 0
                else "FAILED; logs are included in the report"
            ),
            flush=True,
        )
        if not args.automated_only:
            print(
                "\nOpening PAPER app in an EMPTY, separate check workspace.", flush=True
            )
            print(
                "Follow WINDOWS_CHECK_RU.md. Close the app to collect the report.",
                flush=True,
            )
            print(
                "Bots of this check will then be stopped; their state is preserved.",
                flush=True,
            )
            (output / "OBSERVATIONS.txt").write_text(
                "Опишите, что проверили и что не сработало. Этот файл можно дополнить перед отправкой отчёта.\n",
                encoding="utf-8",
            )
            app_started = True
            step = run_step(
                "application",
                [str(python), "app.py", "--data-root", str(workspace)],
                output,
            )
            report["steps"].append(step)
        report["status"] = (
            "CHECKS_COMPLETE"
            if all(s["exit_code"] == 0 for s in report["steps"])
            else "CHECKS_FAILED"
        )
        exit_code = 0 if report["status"] == "CHECKS_COMPLETE" else 1
    except BaseException as exc:
        report.update(status="ERROR", error=str(exc))
        (output / "checker_error.log").write_text(
            traceback.format_exc(), encoding="utf-8"
        )
        print(str(exc), flush=True)
    finally:
        if app_started and python is not None:
            try:
                step = run_step(
                    "collect_bots",
                    [
                        str(python),
                        "-m",
                        "bcc.support",
                        "--root",
                        str(workspace),
                        "--output",
                        str(output / "paper_bots"),
                    ],
                    output,
                    timeout=90,
                )
                report["steps"].append(step)
                if step["exit_code"] != 0:
                    report["status"] = "BOT_OR_COLLECTION_ERRORS"
                    exit_code = 1
            except BaseException:
                report["collection_error"] = traceback.format_exc()
                exit_code = 1
        report["finished"] = datetime.now().astimezone().isoformat()
        write_json(output / "check_summary.json", report)
        report_archive(output, archive)
        print("\nREPORT: " + str(archive), flush=True)
        print("Send this ZIP back. This check does not certify a release.", flush=True)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
