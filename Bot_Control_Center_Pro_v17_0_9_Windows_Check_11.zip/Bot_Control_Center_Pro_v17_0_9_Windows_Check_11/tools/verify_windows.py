"""Run native Windows checks and produce an evidence report, never a release claim."""

import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from bcc import VERSION
from bcc.storage import atomic_json


def source_fingerprint():
    digest = hashlib.sha256()
    for folder in (ROOT / "bcc", ROOT / "tests", ROOT / "tools"):
        for path in sorted(folder.rglob("*.py")):
            digest.update(path.relative_to(ROOT).as_posix().encode())
            digest.update(path.read_bytes())
    for name in (
        "app.py",
        "launch.pyw",
        "requirements.txt",
        "requirements-dev.txt",
        "START.bat",
        "INSTALL.bat",
        "VALIDATE_WINDOWS.bat",
        "CHECK_WINDOWS.bat",
        "tools/start_windows_check.ps1",
    ):
        digest.update(name.encode())
        digest.update((ROOT / name).read_bytes())
    return digest.hexdigest()


def run_step(name, arguments, output, timeout):
    print(name + "…", flush=True)
    log = output / (name + ".log")
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    if name == "tests":
        env["BCC_TEST_ARTIFACTS"] = str(output / "process_checks")
    with log.open("w", encoding="utf-8") as stream:
        try:
            result = subprocess.run(
                [sys.executable, *arguments],
                cwd=ROOT,
                stdout=stream,
                stderr=subprocess.STDOUT,
                timeout=timeout,
                env=env,
                check=False,
            )
            return {
                "step": name,
                "status": "PASS" if result.returncode == 0 else "FAIL",
                "exit_code": result.returncode,
                "log": log.name,
            }
        except subprocess.TimeoutExpired:
            return {"step": name, "status": "FAIL", "error": "Timeout", "log": log.name}


def main():
    parser = argparse.ArgumentParser(description="Нативная проверка Windows Qt и PAPER")
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT
        / "verification_reports"
        / datetime.now().strftime("%Y%m%d_%H%M%S"),
    )
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    report = {
        "app_version": VERSION,
        "at": datetime.now(timezone.utc).isoformat(),
        "platform": platform.platform(),
        "python": sys.version,
        "source_sha256": source_fingerprint(),
        "steps": [],
        "release_ready": False,
        "manual_acceptance": "PENDING: follow ACCEPTANCE_WINDOWS_RU.md; automated tests do not replace it",
    }
    target = output / "windows_report.json"
    if os.name != "nt" or os.environ.get("QT_QPA_PLATFORM", "windows") != "windows":
        report.update(
            status="BLOCKED",
            error="Требуется настоящий Windows Qt; offscreen не считается нативной проверкой",
        )
        atomic_json(target, report)
        print(report["error"], flush=True)
        return 2
    steps = [
        (
            "tests",
            [
                "-X",
                "faulthandler",
                "-m",
                "pytest",
                "-q",
                "tests",
                "--junitxml=" + str(output / "tests.xml"),
            ],
            300,
        ),
        ("gui", ["-m", "bcc.gui_check", "--output", str(output / "screenshots")], 120),
        (
            "public_sources",
            ["-m", "bcc.health", "--output", str(output / "public_sources.json")],
            90,
        ),
    ]
    for name, arguments, timeout in steps:
        report["steps"].append(run_step(name, arguments, output, timeout))
        atomic_json(target, report)
    junit = output / "tests.xml"
    if junit.exists():
        tree = ET.parse(junit).getroot()
        suites = [tree] if tree.tag == "testsuite" else tree.findall("testsuite")
        report["test_totals"] = {
            key: sum(int(s.get(key, 0)) for s in suites)
            for key in ("tests", "failures", "errors", "skipped")
        }
        if report["test_totals"]["skipped"]:
            report["steps"].append(
                {"step": "no_skipped_native_checks", "status": "FAIL"}
            )
    gui_report = output / "screenshots" / "gui_report.json"
    if (
        gui_report.exists()
        and not json.loads(gui_report.read_text(encoding="utf-8"))["native_windows"]
    ):
        report["steps"].append({"step": "native_windows", "status": "FAIL"})
    report["status"] = (
        "AUTOMATED_CHECKS_PASS"
        if all(s["status"] == "PASS" for s in report["steps"])
        else "FAIL"
    )
    atomic_json(target, report)
    print("Report:", target, flush=True)
    print(
        "Manual PAPER acceptance is still required. No release readiness is inferred.",
        flush=True,
    )
    return 0 if report["status"] == "AUTOMATED_CHECKS_PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
