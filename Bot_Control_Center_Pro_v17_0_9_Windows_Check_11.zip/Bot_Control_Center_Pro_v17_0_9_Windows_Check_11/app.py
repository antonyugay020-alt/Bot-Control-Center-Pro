"""Modern Qt application entry point."""

import argparse
import sys
from pathlib import Path

from PySide6.QtCore import QCoreApplication, QEvent
from PySide6.QtWidgets import QApplication

from bcc.ui import MainWindow, apply_style


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--data-root", type=Path, default=Path(__file__).resolve().parent
    )
    args = parser.parse_args()
    app = QApplication(sys.argv)
    app.setApplicationName("Bot Control Center Pro")
    window = MainWindow(args.data_root)
    apply_style(app, window.preferences)
    window.show()
    result = app.exec()
    window.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    return result


if __name__ == "__main__":
    sys.exit(main())
