@echo off
cd /d "%~dp0"
py -3 -m pip install -r requirements-dev.txt
if errorlevel 1 goto failed
py -3 tools\verify_windows.py
if errorlevel 1 goto failed
echo Automated checks passed. Manual PAPER acceptance is still required.
pause
exit /b 0
:failed
echo Verification did not pass. See verification_reports and the console output.
pause
exit /b 1
